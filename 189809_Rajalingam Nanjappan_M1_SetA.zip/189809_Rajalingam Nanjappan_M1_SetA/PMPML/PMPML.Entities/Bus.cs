﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMPMLEntities
{
    [Serializable]
    public class Bus    
    {
        
        private int routeId;

        public int RouteId
        {
            get
            {
                return routeId;
            }
            set
            {
                routeId = value;
            }
        }
        private string routeFrom;

        public string RouteFrom
        {
            get
            {
                return routeFrom;

            }
            set
            {
                routeFrom = value;
            }
        }
        private string routeTo;

        public string RouteTo
        {
            get
            {
                return routeTo;
            }
            set
            {
                routeTo = value;
            }
        }
        private string busNo;

        public string BusNo
        {
            get
            {
                return busNo;
            }
            set
            {
                busNo = value;

            }
                
        }
        private string busType;

        public string BusType
        {
            get
            {
                return busType;
            }
                 set
            {
                busType = value;
            }
        }
        private int capacity;

        public int Capacity
        {
            get
            {
                return capacity;
            }
                set
            {
                capacity = value;

            }
        }
        private int fare;

        public int Fare
        {
            get
            {
                return fare;
            }
            set
            {
                fare = value;

            }

        }



    }
}
