﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPMLDataAccessLayer;
using PMPMLEntities;
using PMPMLExceptions;

namespace PMPMLBusinessLayer
{
    public class BusBL
    {
        public static bool Validation(Bus objBusRoute)
        {
            bool valid = true;
            try
            {
                if (objBusRoute.RouteId > 10 || objBusRoute.RouteId <= 999)
                {
                    valid = false;
                    throw new BusEXPL("The value of RouteId should be greater than 2 digits and less than 3 digits");

                }
            }
            catch (BusEXPL e)
            {
                Console.WriteLine("Error: " + e.Message);

            }
            try
            {
                if (objBusRoute.BusNo == (string)("{^{A-Z}{2}([-]){2}{A-Z}{2}([-]){4}"))
                {
                    valid = false;
                    throw new BusEXPL("Bus Number can't be empty");
                }

            }
            catch (BusEXPL e)
            {

                Console.WriteLine("Error: " + e.Message);
            }
            /*try
            {
                if(objBusRoute.BusType !=Ac || objBusRoute.BusType != Non-Ac)
                {
                    valid = false;
                    throw new BusEXPL("BusType Should be AC or Non-AC");

                }

            }
            catch (BusEXPL e)
            {

                Console.Write("Error: " + e.Message);
            }*/
           
            return valid;

            }

        public static bool AddRoute(Bus AddRoute)
        {
            bool busRouteadded = false;


            bool valid = Validation(AddRoute);
            try
            {
                if (valid == true)
                {
                    busRouteadded = BusDAL.AddRoute(AddRoute);
                }
                return busRouteadded;
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }
        public static List<Bus> ListallBuses()
        {
            List<Bus> BusList = new List<Bus>();
            BusList = BusDAL.Listallbuses();
            return BusList;
        }

        public static Bus SearchBusRoute(int SearchBusRouteId)
        {
            try
            {
                Bus SearchBusRoute = BusDAL.SearchBusRoute(SearchBusRouteId);

                return SearchBusRoute;
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }

        public static bool UpdateBusRoute(Bus UpdateBusRoute)
        {
            try
            {
                bool BusRouteUpdated = BusDAL.UpdateBusRoute(UpdateBusRoute);

                return BusRouteUpdated;
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }

        public static bool DeleteBusRoute(int UpdateBusRouteId)
        {
            bool busRouteDeleted = false;
            try
            {
                busRouteDeleted = BusDAL.DeleteBusRoute(UpdateBusRouteId);
                return busRouteDeleted;
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }

        public static void SerializeBusRoute()
        {
           BusDAL.SerializeBusRoute();
        }

        public static void DeSerializeBusRoute()
        {
            BusDAL.DeSerializeBusRoute();
        }


    }
}

