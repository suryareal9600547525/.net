﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPMLEntities;
using PMPMLExceptions;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace PMPMLDataAccessLayer
{
    public class BusDAL
    {
        public static List<Bus> busList = new List<Bus>();

        public static bool AddRoute(Bus AddRoute)
        {
            bool busAdded = false;
            try
            {
                busList.Add(AddRoute);
                busAdded = true;
                return busAdded;

            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }
        public static List<Bus> Listallbuses()
        {
            return busList;
        }
            public static Bus SearchBusRoute(int SearchRouteId)
            {
                Bus SearchBusRoute = new Bus();
                try
                {
                    SearchBusRoute = busList.Find(bus => bus.RouteId == SearchRouteId);
                }
                catch (SystemException ex)
                {

                    throw new BusEXPL(ex.Message);
                }
                catch (BusEXPL e)
                {
                    throw e;
                }
                return SearchBusRoute;
            }

            public static bool UpdateBusRoute(Bus UpdateBusRoute)
            {
                bool RouteUpdated = false;
                try
                {
                   Bus Bus = busList.Find(bus => bus.RouteId == UpdateBusRoute.RouteId);
                    Bus.RouteFrom = UpdateBusRoute.RouteFrom;
                    Bus.RouteTo = UpdateBusRoute.RouteTo;
                    Bus.BusNo = UpdateBusRoute.BusNo;
                    Bus.BusType = UpdateBusRoute.BusType;
                    RouteUpdated = true;
                }
                catch (SystemException ex)
                {

                    throw new BusEXPL(ex.Message);
                }
                catch (BusEXPL e)
                {
                    throw e;
                }
                return RouteUpdated;
            }

            public static bool DeleteBusRoute(int UpdateBusRouteId)
            {
                bool BusRouteRemoved = false;
                try
                {
                    Bus UpdateBusRoute = busList.Find(Bus => Bus.RouteId == UpdateBusRouteId);
                    if (UpdateBusRoute != null)
                    {
                        busList.Remove(UpdateBusRoute);
                        BusRouteRemoved = true;
                    }
                }
                catch (SystemException ex)
                {

                    throw new BusEXPL(ex.Message);
                }
                catch (BusEXPL e)
                {
                    throw e;
                }
                return BusRouteRemoved;
            }

            public static void SerializeBusRoute()
            {
                try
                {
                    FileStream objFS = new FileStream(@"D:\serializationBusRoute.dat", FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
                    BinaryFormatter objBinF = new BinaryFormatter();
                    objBinF.Serialize(objFS, busList);
                    objFS.Close();
                    Console.WriteLine("Serialization Completed");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            public static void DeSerializeBusRoute()
            {

                try
                {


                    FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Open, FileAccess.Read);
                    BinaryFormatter objBINF = new BinaryFormatter();
                    List<Bus> busL = objBINF.Deserialize(objFS) as List<Bus>;
                    objFS.Close();
                    foreach (Bus bus in busL)
                    {
                        Console.WriteLine(bus.RouteId + "\t" + bus.RouteFrom + "\t" + bus.RouteTo + "\t" + bus.BusNo + "\t" + bus.BusType + "\t" + bus.Capacity + "\t" + bus.Fare);
                    }
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
            }
        }

    }

