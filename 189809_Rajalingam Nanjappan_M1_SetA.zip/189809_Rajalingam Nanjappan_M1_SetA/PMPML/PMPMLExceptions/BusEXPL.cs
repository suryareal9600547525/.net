﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMPMLExceptions
{
    
    public class BusEXPL:ApplicationException
    {
       
        public BusEXPL() : base() { }
       
        public BusEXPL(string message) : base(message) { }
       
        public BusEXPL(string message, Exception InnerException) : base(message,InnerException)
        {

        }


    }
}
