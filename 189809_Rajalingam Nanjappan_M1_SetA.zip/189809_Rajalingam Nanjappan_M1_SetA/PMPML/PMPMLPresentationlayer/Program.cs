﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMPMLBusinessLayer;
using PMPMLEntities;
using PMPMLExceptions;

namespace PMPMLPresentationlayer
{
    class Program
    {
        public static int option;
        static void Main(string[] args)
        {
            do
            {
                menu();
                OpAction(option);
            } while (option < 8);

        }

        static void menu()
        {
            List<string> liMenu = new List<string>() { "1-Add BusRoute", "2-Delete BusRoute", "3-Update BusRoute", "4-Search BusRoute", "5-List All Guest", "6-Serialize", "7-Deserialize", "8-Exit" };
            Console.WriteLine("--------------------------");
            Console.WriteLine("_____PMPML_____\n");

            try
            {
                foreach (var menu in liMenu)
                {
                    Console.Write("" + menu + "\n");
                }
                Console.Write("Enter The Option:");
                option = int.Parse(Console.ReadLine());
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
        }

        public static void OpAction(int option)
        {
            switch (option)
            {
                case 1:
                    Console.Clear();
                    AddBusRoute();

                    break;
                case 2:
                    Console.Clear();
                    DeleteBusRoute();

                    break;
                case 3:
                    Console.Clear();
                    UpdateBusRoute();

                    break;
                case 4:
                    Console.Clear();
                    SearchBusRoute();

                    break;
                case 5:
                    Console.Clear();
                    //ListAllGuest();
                    break;
                case 6:
                    Console.Clear();
                    SerializeBusRoute();
                    break;
                case 7:
                    Console.Clear();
                    DeSerializeBusRoute();
                    break;
                case 8:
                    return;



            }

        }

        public static void AddBusRoute()
        {
            bool busRouteadded = false;
            Bus AddBusRoute = new Bus();
            Console.WriteLine("----------------");
            Console.WriteLine("Add a New Bus Route");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Route ID:");
            AddBusRoute.RouteId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a RouteFrom:");
            AddBusRoute.RouteFrom = Console.ReadLine();
            Console.WriteLine("Enter a RouteTo:");
            AddBusRoute.RouteTo = Console.ReadLine();
            Console.WriteLine("Enter a BusNo:");
            AddBusRoute.BusNo = Console.ReadLine();
            Console.WriteLine("Enter a BusType(AC/Non-Ac):");
            AddBusRoute.BusType = Console.ReadLine();
            Console.WriteLine("Enter a capacity:");
            AddBusRoute.Capacity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Fare:");
            AddBusRoute.Fare = int.Parse(Console.ReadLine());
            try
            {
                busRouteadded = Convert.ToBoolean(BusBL.AddRoute(AddBusRoute));
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }


            if (busRouteadded == true)
                Console.WriteLine("Route Added");
            else
                Console.WriteLine("Could not Add Route !!");
        }

        static void UpdateBusRoute()
        {
            bool BusRouteUpdated;
            Bus UpdateBusRoute = new Bus();
            Console.WriteLine("----------------");
            Console.WriteLine("Updete the Details of a Existing Guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter The BusRoute Id:");
            UpdateBusRoute.RouteId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a BusRouteFrom:");
            UpdateBusRoute.RouteFrom = Console.ReadLine();
            Console.WriteLine("Enter a BusRouteTO:");
            UpdateBusRoute.RouteTo = Console.ReadLine();
            Console.WriteLine("Enter a BusRouteTO:");
            UpdateBusRoute.BusNo = Console.ReadLine();
            Console.WriteLine("Enter a BusType:");
            UpdateBusRoute.BusType = Console.ReadLine();
            Console.WriteLine("Enter a capacity:");
            UpdateBusRoute.Capacity = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Fare:");
            UpdateBusRoute.Fare = int.Parse(Console.ReadLine());
            try
            {
                BusRouteUpdated = BusBL.UpdateBusRoute(UpdateBusRoute);
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }


            if (BusRouteUpdated == true)
                Console.WriteLine("Bus Route Details Updated");
            else
                Console.WriteLine("Could Not Updated the Details of BusRoute !!");

        }

        static void SearchBusRoute()
        {
            Bus SearchBusRoute;
            Console.WriteLine("----------------");
            Console.WriteLine("Search BusRoute");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter the Guest Id:");
            int SearchBusRouteId = int.Parse(Console.ReadLine());
            try
            {
                SearchBusRoute = BusBL.SearchBusRoute(SearchBusRouteId);
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
            Console.WriteLine("Id: " + SearchBusRoute.RouteId);
            Console.WriteLine("Name: " + SearchBusRoute.RouteFrom);
            Console.WriteLine("Phone Number : " + SearchBusRoute.RouteTo);

        }

        static void DeleteBusRoute()
        {
            bool busrouteDeleted;

            Console.WriteLine("----------------");
            Console.WriteLine("Deleting Guest");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter the Id: ");
            int deleteBusRouteId = int.Parse(Console.ReadLine());
            try
            {
                busrouteDeleted = BusBL.DeleteBusRoute(deleteBusRouteId);
            }
            catch (SystemException ex)
            {

                throw new BusEXPL(ex.Message);
            }
            catch (BusEXPL e)
            {
                throw e;
            }
            if (busrouteDeleted == true)
                Console.WriteLine("busRoute Deleteed");
            else
                Console.WriteLine("Could not Delete BusRoute");
        }

    
        static void SerializeBusRoute()
        {
            BusBL.SerializeBusRoute();
        }

        static void DeSerializeBusRoute()
        {
           BusBL.DeSerializeBusRoute();
        }
    }
}

