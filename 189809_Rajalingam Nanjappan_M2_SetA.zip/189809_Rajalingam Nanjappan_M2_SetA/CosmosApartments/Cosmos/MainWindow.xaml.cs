﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Cosmos_BAL; //Reference of Business Layer
using Cosmos_Entities; //Reference of Entities
using Cosmos_Exceptions; //Reference of Exceptions

namespace Cosmos
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        CosmosBAL bal = null;
        public MainWindow()
        {
            InitializeComponent();
            bal = new CosmosBAL();
           
        }

        private bool ValidateUI() //Validation
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txtflatno.Text == null | txtflatno.Text == string.Empty | txtflatno.Text.Length  > 3) //validation for Flat No
            {
                isValid = false;
                sb.Append("Flat No is Empty!" + Environment.NewLine);
            }
            if (cbblock.Text == null | cbblock.Text == string.Empty) //validation for Block
            {
                isValid = false;
                sb.Append("Block No is Empty!" + Environment.NewLine);
            }
            if (txtresidentname.Text == null | txtresidentname.Text == string.Empty | txtresidentname.Text == @"[^a-zA-Z]") //validation for Resident Name
            {
                isValid = false;
                sb.Append("Resident Name is Empty!" + Environment.NewLine);
            }
          

            if (txtidate.Text == null | txtidate.Text == string.Empty | txtidate.Text == System.DateTime.Today.ToString("ddmmyy"))
            {
                isValid = false;
                sb.Append("Incident Date is Empty!" + Environment.NewLine);
            }
            if (txtcontactno.Text == null | txtcontactno.Text == string.Empty | txtcontactno.Text.Length < 1) //Validation for Contact No
            {
                isValid = false;
                sb.Append("Contact-No is Empty!" + Environment.NewLine);
            }
            
            txtdescription.SelectAll();
            if (txtdescription.Selection.Text.Length <= 2) //validation for Description
            {
                isValid = false;
                sb.Append("Address is Empty!" + Environment.NewLine);
            }

            if (!isValid)
            {
                throw new CosmosException(sb.ToString());
            }

            return isValid;
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e) // Adding the Detials after Clicking Submit button
        {
            try
            {

                txtdescription.SelectAll();

                if (ValidateUI())
                {
                    Apartments apartments = new Apartments
                    {
                        FlatNo = Convert.ToInt32(txtflatno.Text),
                        ResidentName = Convert.ToString(txtresidentname.Text),
                        IncidentDate = (DateTime)txtidate.SelectedDate,
                        ContactNo = txtcontactno.Text,
                        IssueType =((ComboBoxItem)cbissuetype.SelectedItem).Content.ToString(),
                        Block = ((ComboBoxItem)cbblock.SelectedItem).Content.ToString()
                    };

                    apartments.Description = txtdescription.Selection.Text;


                    int incidentId = bal.Add(apartments);
                    MessageBox.Show("Incident ID !" + incidentId);

                }
                else
                {
                    MessageBox.Show("validation Error!");
                }
            }
            catch (CosmosException ex1)
            {

                MessageBox.Show(ex1.Message);
            }
            catch(Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }
    }
}
