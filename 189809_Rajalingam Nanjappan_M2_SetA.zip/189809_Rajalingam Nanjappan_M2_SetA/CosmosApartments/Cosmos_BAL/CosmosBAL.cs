﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmos_DAL; // Reference of Data Access Layer
using Cosmos_Entities; //Reference of Entities
using Cosmos_Exceptions; //Reference of Exceptions

namespace Cosmos_BAL
{
    public class CosmosBAL
    {
        CosmosDAL dal = new CosmosDAL();

        public int Add(Apartments apartments)
        {
            int incidentId;
            try
            {
                incidentId = dal.Insert(apartments);
            }
            catch (Exception)
            {
                throw;
            }
            return incidentId;
        }

    }
}
