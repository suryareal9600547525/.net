﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient; // Reference for SqlCommands
using System.Configuration; //Reference for SqlConfiguration
using Cosmos_Entities; // Reference for Entities


namespace Cosmos_DAL
{
    public class CosmosDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public CosmosDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);     //Connection String    
        }

        public int Insert(Apartments apartments)
        {
            int incidentId;
            try
            {
                cmd = new SqlCommand("[189809].[USP_InsertCosmos]", cn);    //  Reference  of Stored Procedure                        
                SqlParameter IId = new SqlParameter("@incidentid", System.Data.SqlDbType.Int);
                IId.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(IId);

                cmd.Parameters.AddWithValue("@flatno", apartments.FlatNo);
                cmd.Parameters.AddWithValue("@block", apartments.Block);
                cmd.Parameters.AddWithValue("@residentname",apartments.ResidentName);
                cmd.Parameters.AddWithValue("@idate", apartments.IncidentDate);
                cmd.Parameters.AddWithValue("@contactno", apartments.ContactNo);
                cmd.Parameters.AddWithValue("@issuetype", apartments.IssueType);
                cmd.Parameters.AddWithValue("@des", apartments.Description);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                cmd.ExecuteNonQuery();
                incidentId = Convert.ToInt32(cmd.Parameters["@incidentid"].Value);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return incidentId;
        }


    }
}
