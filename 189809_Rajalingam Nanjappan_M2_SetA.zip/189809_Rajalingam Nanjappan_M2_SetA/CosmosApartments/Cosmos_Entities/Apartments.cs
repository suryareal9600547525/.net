﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_Entities
{
    public class Apartments
    {
        public int IncidentId { get; set; }

        public int FlatNo { get; set; }

        public string Block { get; set; }

        public string ResidentName { get; set; }

        public DateTime IncidentDate { get; set; }

        public string ContactNo { get; set; }

        public string IssueType { get; set; }

        public string Description { get; set; }
    }
}
