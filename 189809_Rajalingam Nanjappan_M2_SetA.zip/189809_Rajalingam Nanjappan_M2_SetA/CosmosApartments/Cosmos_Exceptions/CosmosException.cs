﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmos_Exceptions
{
    public class CosmosException : Exception
    {
        public CosmosException(string errorMessage) : base(errorMessage)
    {

    }
}
}
