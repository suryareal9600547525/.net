﻿create table [189809].Cosmos
(IncidentId int primary key identity(100,1),
FlatNo int,
Block varchar(10),
ResidentName varchar(30),
IncidentDate date,
ContactNo varchar(20),
IssueType varchar(10),
Description varchar(50)
)

drop table [189809].Cosmos