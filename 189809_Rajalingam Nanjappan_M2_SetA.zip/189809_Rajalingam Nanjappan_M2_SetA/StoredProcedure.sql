﻿CREATE PROCEDURE [189809].[USP_InsertCosmos]
	@incidentid int out,
	@flatno int,
	@block varchar(10),
	@residentname varchar(30),
	@idate date,
	@contactno varchar(20),
	@issuetype varchar(10),
	@des varchar(50)
AS
BEGIN
insert into [189809].Cosmos values(@flatno,@block,@residentname,@idate,@contactno,@issuetype,@des)
set @incidentid=SCOPE_IDENTITY()
END

