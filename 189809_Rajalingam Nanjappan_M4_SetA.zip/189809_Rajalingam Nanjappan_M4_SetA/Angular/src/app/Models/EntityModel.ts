export interface IStudent{
    RollNumber: number;
    Name:string;
    Gender:string;
    Class:number


}