import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name:'filter'
})
export class StudentPipe implements PipeTransform{
    transform(details:any[], gender:string):any[]{
        if(!details){
            return[];
        }
        if(!gender){
            return details;
        }
        return details.filter(dt=>{return dt.Gender==gender;})
    }
}