import { OnInit, Component } from '@angular/core';
import { IStudent } from '../Models/EntityModel';
import { StudentService } from '../Services/studentService';
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
    selector:'student-details',
    templateUrl:'search.component.html'
})
export class SearchComponent implements OnInit{
    details:IStudent[];
    submitted:boolean=false;
    ngOnInit(): void {
    }
    constructor(private studentService:StudentService,private formBuilder:FormBuilder){
    }
    onSubmit(){
        this.submitted=true;
        this.studentService.getDetails().subscribe(data=>{
            this.details=data;
        })
    }
}