import {Injectable, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {IStudent} from '../Models/EntityModel';

@Injectable()
export class StudentService implements OnInit{
    url:string="http://localhost:50267/Api/Student/StudentList"
    ngOnInit():void{
        this.getDetails();
    }
    constructor(private _http:HttpClient){

    }
    getDetails(){
        return this._http.get<IStudent[]>(this.url);
    }
}