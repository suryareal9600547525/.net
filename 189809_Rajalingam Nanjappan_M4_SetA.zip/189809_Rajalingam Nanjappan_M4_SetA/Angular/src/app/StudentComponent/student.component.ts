import { OnInit, Component } from '@angular/core';
import { StudentService } from '../Services/studentService';
import { IStudent } from '../Models/EntityModel';

@Component({
    selector:"app-student",
    templateUrl:'student.component.html'
})
export class StudentComponent implements OnInit{
    details:IStudent[];
    ngOnInit(): void {
        this.getAll();
    }
    constructor(private studentService:StudentService){
    }
    getAll(){
    this.studentService.getDetails().subscribe(data=>{
    this.details=data;
        });
    }
}