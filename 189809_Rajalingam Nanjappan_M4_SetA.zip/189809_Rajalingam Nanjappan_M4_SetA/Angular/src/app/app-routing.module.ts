import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponent } from './StudentComponent/student.component';
import { SearchComponent } from './SearchComponent/search.component';


const routes: Routes = [
  {path:'',component:StudentComponent},
  {path:'getAll',component:StudentComponent},
  {path:'getFilter',component:SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
