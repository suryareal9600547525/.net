﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace EmployeeTestForm
{
    [TestClass]
    public class TestForm
    {
        [TestMethod]
        public void BadRegisterValues()
        {
            IWebDriver driver = new ChromeDriver();
            string baseUrl = @"http://localhost:60862/default.aspx";


            driver.Navigate().GoToUrl(baseUrl);
            Console.WriteLine("Opening url");

            IWebElement fname = driver.FindElement(By.Id("txtFN"));
            IWebElement lname = driver.FindElement(By.Id("txtLN"));
            IWebElement age = driver.FindElement(By.Id("txtAge"));
            IWebElement option1 = driver.FindElement(By.Id("chkCSharp"));
           

            // This will Toggle the Check box 		
            option1.Click();
           
            IWebElement category = driver.FindElement(By.Id("ddlPlatform"));

            fname.SendKeys("Raja");
            lname.SendKeys("");
            age.SendKeys("10");
            option1.SendKeys("");
            category.SendKeys("");

            IWebElement submit = driver.FindElement(By.Id("Button1"));
            submit.Click();
            Console.WriteLine("Form Submitted");



            IWebElement element1 = driver.FindElement(By.Id("RequiredFieldValidator1"));
            IWebElement element2 = driver.FindElement(By.Id("RequiredFieldValidator2"));
            IWebElement element3 = driver.FindElement(By.Id("RangeValidator1"));

           

            Assert.AreEqual("", element1.Text);
            Assert.AreEqual("", element2.Text);
            Assert.AreEqual("", element3.Text);
            
           

            Console.WriteLine("Test Passed");
            driver.Close();
            Console.WriteLine("Browser Closed");
        }

        [TestMethod]
        public void CorrectValuesTest()
        {
            IWebDriver driver = new ChromeDriver();
            string baseUrl = @"http://localhost:60862/default.aspx";


            driver.Navigate().GoToUrl(baseUrl);
            Console.WriteLine("Opening url");

            IWebElement fname = driver.FindElement(By.Id("txtFN"));
            IWebElement lname = driver.FindElement(By.Id("txtLN"));
            IWebElement age = driver.FindElement(By.Id("txtAge"));
            IWebElement option1 = driver.FindElement(By.Id("chkCSharp"));
           

            // This will Toggle the Check box 		
            option1.Click();
            

            IWebElement category = driver.FindElement(By.Id("ddlPlatform"));

            fname.SendKeys("Raja");
            lname.SendKeys("Rj");
            age.SendKeys("22");
            option1.SendKeys("");
           
            category.SendKeys("Java");

            IWebElement submit = driver.FindElement(By.Id("Button1"));
            submit.Click();
            Console.WriteLine("Form Submitted");


            IWebElement element1 = driver.FindElement(By.Id("RequiredFieldValidator1"));
            IWebElement element2 = driver.FindElement(By.Id("RequiredFieldValidator2"));
            IWebElement element3 = driver.FindElement(By.Id("RangeValidator1"));



            Assert.AreEqual("", element1.Text);
            Assert.AreEqual("", element2.Text);
            Assert.AreEqual("", element3.Text);



            Console.WriteLine("Test Passed");
            driver.Close();
            Console.WriteLine("Browser Closed");
        }
    }
}
