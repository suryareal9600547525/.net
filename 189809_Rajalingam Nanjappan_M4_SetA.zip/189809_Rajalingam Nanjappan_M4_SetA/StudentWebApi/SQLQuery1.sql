﻿create table [r189809].Student (
RollNumber int primary key,
Name varchar(20),
Gender varchar(10),
Class int
)


select * from [r189809].Student
insert into [r189809].Student values(5,'Kiran','Female',3);