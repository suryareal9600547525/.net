﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using StudentWebApi.Models;


namespace StudentWebApi.Controllers
{
    [RoutePrefix("Api/Student")]
    public class StudentController : ApiController
    {
        Training_18Jul19_PuneEntities1 entities = new Training_18Jul19_PuneEntities1();

        [Route("StudentList")]

        public IQueryable<Student> Get()
        {
            return entities.Students;
        }
    }
}
