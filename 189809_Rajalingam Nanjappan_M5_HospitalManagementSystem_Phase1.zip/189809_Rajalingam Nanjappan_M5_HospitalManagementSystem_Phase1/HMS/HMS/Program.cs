﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_BAL;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddPatient();
                        break;
                    case 2:
                        UpdatePatient();
                        break;
                    case 3:
                        PatientAppointment();
                        break;
                    case 4:
                        Search();
                        break;
                    case 5:
                        View();
                        break;
                    case 6:
                        LabReport();
                        break;
                    case 7:
                        BillReport();
                        break;
                    case 8:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);



            //AddPatient();
            //UpdatePatient();
            //PatientAppointment();
            //Search();
            //View();
        }
        
        public static void AddPatient()
        {
            bool patientadded = false;
            Patient AddPatients = new Patient();
            Console.WriteLine("----------------");
            Console.WriteLine("Add a New Patient");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Id:");
            AddPatients.PatientID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Name:");
            AddPatients.Name = Console.ReadLine();
            Console.WriteLine("Enter a Gender:");
            AddPatients.Gender = Console.ReadLine();
            Console.WriteLine("Enter a Age:");
            AddPatients.Age = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Address:");
            AddPatients.Address = Console.ReadLine();
            Console.WriteLine("Enter a Phone number:");
            AddPatients.PhoneNo = Console.ReadLine();
            Console.WriteLine("Enter a Weight:");
            AddPatients.Weight = Console.ReadLine();
            try
            {
                patientadded = Convert.ToBoolean(HMSBAL.AddPatient(AddPatients));
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                Console.WriteLine(e.Message);
            }


            if (patientadded == true)
                Console.WriteLine("Patient Added");
            else
                Console.WriteLine("Could not Add Patient !!");
        }


        public static void AddInPatient()
        {
            
            bool Inpatientadded = false;
            InPatient AddInPatient = new InPatient();
            //Inpatientadded.INOUTPID = 1; 
            Console.WriteLine("----------------");
            Console.WriteLine("Add a New InPatient");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Appointment Id:");
            AddInPatient.AppointmentID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a PatientId:");
            AddInPatient.PatientID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a DoctorName:");
            AddInPatient.DoctorName = Console.ReadLine();
            Console.WriteLine("Enter a RoomNo:");
            AddInPatient.RoomNo = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a AdmissionDate:");
            AddInPatient.AdmissionDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter a DischargeDate:");
            AddInPatient.DisChargeDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter a Remarks:");
            AddInPatient.ReMarks = Console.ReadLine();
            try
            {
                Inpatientadded = Convert.ToBoolean(HMSBAL.AddInPatient(AddInPatient));
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                Console.WriteLine(e.Message);
            }


            if (Inpatientadded == true)
                Console.WriteLine("InPatient Added");
            else
                Console.WriteLine("Could not Add InPatient !!");
        }


        public static void AddOutPatient()
        {
            bool Outpatientadded = false;
            OutPatient AddOutPatient = new OutPatient();
            Console.WriteLine("----------------");
            Console.WriteLine("Add a New OutPatient");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Appointment Id:");
            AddOutPatient.AppointmentID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a PatientId:");
            AddOutPatient.PatientID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a DoctorName:");
            AddOutPatient.DoctorName = Console.ReadLine();
            Console.WriteLine("Enter a DateOfVisit:");
            AddOutPatient.DateOfVisit = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter a Remarks:");
            AddOutPatient.Remarks = Console.ReadLine();
            try
            {
                Outpatientadded = Convert.ToBoolean(HMSBAL.AddOutPatient(AddOutPatient));
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }


            if (Outpatientadded == true)
                Console.WriteLine("OutPatient Added");
            else
                Console.WriteLine("Could not Add OutPatient !!");
        }

        private static void PatientAppointment()
        {
            Console.WriteLine("1-Add InPatient");
            Console.WriteLine("2-Add OutPatient");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    AddInPatient();
                    break;
                case 2:
                    AddOutPatient();
                    break;

            }
        }




        private static void UpdatePatient()
        {
            try
            {
                int updatePatientID;
                Console.WriteLine("Enter PatientID to Update Details:");
                updatePatientID = Convert.ToInt32(Console.ReadLine());
                Patient updatedPatient = HMSBAL.SearchPatientBL(updatePatientID);
                //Console.WriteLine("Patient Name : {0}",updatedPatient.Name);
               
                Console.WriteLine("Welcome,{0}",updatedPatient.Name);
                Console.WriteLine("*****************************");
                if (updatedPatient != null)
                {
                    Console.WriteLine("Update Patient Address :");
                    updatedPatient.Address = Console.ReadLine();
                    Console.WriteLine("Update Patient PhoneNumber :");
                    updatedPatient.PhoneNo = Console.ReadLine();
                    Console.WriteLine("Update Patient Weight :");
                    updatedPatient.Weight = Console.ReadLine();
                    bool patientUpdated = HMSBAL.UpdatePatientBL(updatedPatient);
                    if (patientUpdated)
                        Console.WriteLine("Patient Details Updated");
                    else
                        Console.WriteLine("Patient Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }


            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Search()
        {
            Console.WriteLine("1-InPatient");
            Console.WriteLine("2-OutPatient");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    SearchByInPatient();
                    break;
                case 2:
                    SearchByOutPatient();
                    break;
                

            }
        }

        //private static void SearchByLabReport()
        //{
        //    Console.WriteLine("1-InPatient");
        //    Console.WriteLine("2-OutPatient");
           
        //    int choice;
        //    choice = Convert.ToInt32(Console.ReadLine());
        //    switch (choice)
        //    {
        //        case 1:
        //            SearchByLabReportInPatient();
        //            break;
        //        case 2:
        //            SearchByLabReportOutPatient();
        //            break;
               

        //    }
        //}

        //private static void SearchByLabReportInPatient()
        //{
        //    Patient objPat = new Patient();
        //    try
        //    {
        //        int searchPatientID;
        //        Console.WriteLine("Enter PatientID to Search:");
        //        searchPatientID = Convert.ToInt32(Console.ReadLine());
        //        LabReport searchInPatient = HMSBAL.SearchInPatientLabreportBL(searchPatientID);
        //        Patient searchpatient = HMSBAL.SearchPatientBL(searchPatientID);
        //        if (searchInPatient != null)
        //        {
        //            Console.WriteLine("******************************************************************************");
        //            Console.WriteLine("ReportID\t\tPatientName\t\tPatientType\t\tTestDate\t\tTestType\tReMarks");
        //            Console.WriteLine("******************************************************************************");
        //            Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", searchInPatient.ReportID,searchpatient.Name, searchInPatient.PatientType, searchInPatient.TestDate.ToShortDateString(), searchInPatient.TestType, searchInPatient.Remarks);
        //            Console.WriteLine("******************************************************************************");
        //        }
        //        else
        //        {
        //            Console.WriteLine("No InPatient Details Available");
        //        }

        //    }
        //    catch (HMSExceptions ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }
        //}

        //private static void SearchByLabReportOutPatient()
        //{

        //}

        private static void SearchByOutPatient()
        {
            Console.WriteLine("1-SearchByPatientID");
            Console.WriteLine("2-SearchByDateOfVisit");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    SearchByPatientID();
                    break;
                case 2:
                    SearchByDateOfVisit();
                    break;

            }
        }

        private static void SearchByInPatient()
        {

            Console.WriteLine("1-SearchByPatientID");
            Console.WriteLine("2-SearchByAdmissionDate");
            Console.WriteLine("3-SearchByDischargeDate");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    SearchPatientID();
                    break;
                case 2:
                    SearchByAdmissionDate();
                    break;

                case 3:
                    SearchByDischargeDate();
                    break;

            }

        }

        private static void SearchByPatientID()
        {
           
            try
            {
                int searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Convert.ToInt32(Console.ReadLine());
                OutPatient searchOutPatient = HMSBAL.SearchOutPatientBL(searchPatientID);
                Patient searchpatient = HMSBAL.SearchPatientBL(searchPatientID);
                if (searchOutPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientName\t\tDoctorName\t\tDateOfVisit\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchpatient.Name,searchOutPatient.DoctorName, searchOutPatient.DateOfVisit, searchOutPatient.Remarks);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No OutPatient Details Available");
                }

            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchByDateOfVisit()
        {
            try
            {
                DateTime searchDateOfvisit;
                Console.WriteLine("Enter DateOfVisit to Search:");
                searchDateOfvisit = Convert.ToDateTime(Console.ReadLine());
                OutPatient searchOutPatient = HMSBAL.SearchOutPatientDOVBL(searchDateOfvisit);
                if (searchOutPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tDoctorName\t\tDateOfVisit\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchOutPatient.PatientID, searchOutPatient.DoctorName, searchOutPatient.DateOfVisit, searchOutPatient.Remarks);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No OutPatient Details Available");
                }

            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchPatientID()
        {
            Patient objPat = new Patient();
            try
            {
                int searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Convert.ToInt32(Console.ReadLine());
                InPatient searchInPatient = HMSBAL.SearchInPatientBL(searchPatientID);
                Patient searchpatient = HMSBAL.SearchPatientBL(searchPatientID);
                if (searchInPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientName\t\tRoomNo\t\tAdmissionDate\t\tDisChargeDate\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchpatient.Name,searchInPatient.RoomNo, searchInPatient.AdmissionDate.ToShortDateString(), searchInPatient.DisChargeDate.ToShortDateString(), searchInPatient.ReMarks);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No InPatient Details Available");
                }

            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void SearchByAdmissionDate()
        {
            try
            {
               
                DateTime SearchAdmissionDate;
                Console.WriteLine("Enter AdmissionDate to Search:");
                SearchAdmissionDate = Convert.ToDateTime(Console.ReadLine());
                InPatient searchInPatient = HMSBAL.SearchInPatientAdateBL(SearchAdmissionDate);
                
                if (searchInPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tDoctorName\t\tRoomNo\tDisChargeDate\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchInPatient.PatientID, searchInPatient.DoctorName, searchInPatient.RoomNo, searchInPatient.DisChargeDate.ToShortDateString(), searchInPatient.ReMarks);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No InPatient Details Available");
                }

            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void SearchByDischargeDate()
        {
            try
            {
                DateTime SearchDischargeDate;
                Console.WriteLine("Enter DischargeDate to Search:");
                SearchDischargeDate = Convert.ToDateTime(Console.ReadLine());
                InPatient searchInPatient = HMSBAL.SearchInPatientDdateBL(SearchDischargeDate);
                if (searchInPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tDoctorName\t\tRoomNo\tAdmissionDate\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchInPatient.PatientID, searchInPatient.DoctorName, searchInPatient.RoomNo, searchInPatient.AdmissionDate.ToShortDateString(), searchInPatient.ReMarks);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No InPatient Details Available");
                }

            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void View()
        {
            Console.WriteLine("1-InPatient");
            Console.WriteLine("2-OutPatient");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    ViewInPatient();
                    break;
                case 2:
                    ViewOutPatient();
                    break;

            }
        }

        private static void ViewInPatient()
        {
            try
            {
                List<InPatient> InpatientList = HMSBAL.ViewInPatientBL();
                if (InpatientList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tDoctorName\t\tRoomNo\t\tAdmissionDate\t\tDisChargeDate\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    foreach (InPatient Inpatient in InpatientList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", Inpatient.PatientID, Inpatient.DoctorName, Inpatient.RoomNo, Inpatient.AdmissionDate, Inpatient.DisChargeDate, Inpatient.ReMarks);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No InPatient Details Available");
                }
            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }


        }

        private static void ViewOutPatient()
        {
            try
            {
                List<OutPatient> OutpatientList = HMSBAL.ViewOutPatientBL();
                if (OutpatientList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tDoctorName\t\tDateOfVisit\t\tReMarks");
                    Console.WriteLine("******************************************************************************");
                    foreach (OutPatient Outpatient in OutpatientList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", Outpatient.PatientID, Outpatient.DoctorName,Outpatient.DateOfVisit,Outpatient.Remarks);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No OutPatient Details Available");
                }
            }
            catch (HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void LabReport()
        {
            Console.WriteLine("1-InPatient");
            Console.WriteLine("2-OutPatient");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    LabReportInPatient();
                    break;
                case 2:
                    LabReportOutPatient();
                    break;

            }
        }

        private static void LabReportInPatient()
        {
            
            bool labreportadded = true;
            
            LabReport Addlabreport = new LabReport();
            Patient searchpatient = new Patient();
            InPatient searchInpatients = new InPatient();


            Console.WriteLine("----------------");
            Console.WriteLine("Add a New Lab Report");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Report ID:");
            Addlabreport.ReportID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Patient ID:");
            searchpatient.PatientID = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter a TestDate:");
            Addlabreport.TestDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter the PatientType:");
            Addlabreport.PatientType = Console.ReadLine();
            Console.WriteLine("Enter the TestType:");
            Addlabreport.TestType = Console.ReadLine();
            Console.WriteLine("Enter the LabAmount:");
            Addlabreport.LabAmount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Remarks:");
            Addlabreport.Remarks = Console.ReadLine();

            if (labreportadded == true)
                Console.WriteLine("LabReport Added");
            else
                Console.WriteLine("Could not Add labReport !!");

            
            try
            {
                
                labreportadded = Convert.ToBoolean(HMSBAL.LabReportPatientBL(Addlabreport));
                Patient searchpatien = HMSBAL.SearchPatientBL(searchpatient.PatientID);
                Console.WriteLine("Report ID:" + Addlabreport.ReportID);
                Console.WriteLine("Patient Name:" + searchpatien.Name);
                InPatient searchpatients = HMSBAL.SearchInPatientBL(searchpatient.PatientID);
                Console.WriteLine("Doctor Name:" + searchpatients.DoctorName);
                Console.WriteLine("TestDate:" + Addlabreport.TestDate);
                Console.WriteLine("PatientType:" + Addlabreport.PatientType);
                Console.WriteLine("LabAmount:" + Addlabreport.LabAmount);
                Console.WriteLine("TestType:" + Addlabreport.TestType);
                Console.WriteLine("Remarks:" + Addlabreport.Remarks);
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }


            
        }



        private static void LabReportOutPatient()
        {

            bool labreportadded = true;

            LabReport Addlabreport = new LabReport();
            Patient searchpatient = new Patient();
            InPatient searchInpatients = new InPatient();


            Console.WriteLine("----------------");
            Console.WriteLine("Add a New Lab Report");
            Console.WriteLine("----------------");
            Console.WriteLine("Enter a Report ID:");
            Addlabreport.ReportID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a Patient ID:");
            searchpatient.PatientID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter a TestDate:");
            Addlabreport.TestDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter the PatientType:");
            Addlabreport.PatientType = Console.ReadLine();
            Console.WriteLine("Enter the TestType:");
            Addlabreport.TestType = Console.ReadLine();
            Console.WriteLine("Enter the LabAmount:");
            Addlabreport.LabAmount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Remarks:");
            Addlabreport.Remarks = Console.ReadLine();

            if (labreportadded == true)
                Console.WriteLine("LabReport Added");
            else
                Console.WriteLine("Could not Add labReport !!");


            try
            {

                labreportadded = Convert.ToBoolean(HMSBAL.LabReportPatientBL(Addlabreport));
                Patient searchpatien = HMSBAL.SearchPatientBL(searchpatient.PatientID);
                Console.WriteLine("Report ID:" + Addlabreport.ReportID);
                Console.WriteLine("Patient Name:" + searchpatien.Name);
                OutPatient searchPatient = HMSBAL.SearchOutPatientBL(searchpatient.PatientID);
                Console.WriteLine("Doctor Name:" + searchPatient.DoctorName);
                 Console.WriteLine("TestDate:" + Addlabreport.TestDate);
                Console.WriteLine("PatientType:" + Addlabreport.PatientType);
                Console.WriteLine("LabAmount:" + Addlabreport.LabAmount);
                Console.WriteLine("TestType:" + Addlabreport.TestType);
                Console.WriteLine("Remarks:" + Addlabreport.Remarks);
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }



        }

        private static void BillReport()
        {
            Console.WriteLine("1-InPatient");
            Console.WriteLine("2-OutPatient");
            int choice;
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                   BillInPatient();
                    break;
                case 2:
                    BillOutPatient();
                    break;

            }
        }

        private static void BillInPatient()
        {
            bool billreportadded = true;
            BillInformation billreport = new BillInformation();
            Patient searchpatient = new Patient();
            LabReport searchlab = new LabReport();



            Console.WriteLine("Enter bill ID:");
            billreport.BillID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Patient ID:");
            searchpatient.PatientID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter The OperationTheatre Amount:");
            billreport.OperationTheatreAmount = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Medical Bill:");
            billreport.MedicalBill = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Lab Report ID:");
            searchlab.ReportID = Convert.ToInt32(Console.ReadLine());

            billreportadded = HMSBAL.BillReportInPatientBL(billreport);

            if (billreportadded == true)
                Console.WriteLine("BillReport Added");
            else
                Console.WriteLine("Could not Add BillReport !!");



            try
            {
                billreportadded = Convert.ToBoolean(HMSBAL.BillReportInPatientBL(billreport));
                Patient searchpatien = HMSBAL.SearchPatientBL(searchpatient.PatientID);
                Console.WriteLine("Bill ID:" + billreport.BillID);
                Console.WriteLine("Patient Name:" + searchpatien.Name);
                InPatient searchpatients = HMSBAL.SearchInPatientBL(searchpatient.PatientID);
                Console.WriteLine("Doctor Name:" + searchpatients.DoctorName);
                 InPatient objpat = HMSBAL.SearchInPatientBL(searchpatient.PatientID);
                 if (objpat.RoomNo >= 1 && objpat.RoomNo <= 30)
                {
                    billreport.RoomAmount = 500;
                    Console.WriteLine("Room Amount:" + billreport.RoomAmount);
                   
                }
                else if (objpat.RoomNo > 30 && objpat.RoomNo <= 60)
                {
                    billreport.RoomAmount = 1000;
                    Console.WriteLine("Room Amount:" + billreport.RoomAmount);
                }
                else if(objpat.RoomNo > 60 && objpat.RoomNo <= 100)
                {
                    billreport.RoomAmount = 2000;
                    Console.WriteLine("Room Amount:" + billreport.RoomAmount);
                }
                Console.WriteLine("Operation Theatre Amount:" + billreport.OperationTheatreAmount);
                Console.WriteLine("Medical Bill:" + billreport.MedicalBill);
                LabReport objLAB = HMSBAL.SearchLabreportBL(searchlab.ReportID);
                Console.WriteLine("Lab Bill:" + objLAB.LabAmount);





            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }




        }

        private static void BillOutPatient()
        {
            bool billreportadded = true;
            BillInformation billreport = new BillInformation();
            Patient searchpatient = new Patient();
            LabReport searchlab = new LabReport();


            Console.WriteLine("Enter Bill ID:");
            billreport.BillID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Patient ID:");
            searchpatient.PatientID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Medical Bill:");
            billreport.MedicalBill = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Lab Report ID:");
            searchlab.ReportID = Convert.ToInt32(Console.ReadLine());

            billreportadded = HMSBAL.BillReportOutPatientBL(billreport);

            if (billreportadded == true)
                Console.WriteLine("BillReport Added");
            else
                Console.WriteLine("Could not Add BillReport !!");

            try
            {

                billreportadded = Convert.ToBoolean(HMSBAL.BillReportOutPatientBL(billreport));
                Patient searchpatien = HMSBAL.SearchPatientBL(searchpatient.PatientID);
                Console.WriteLine("Bill ID:" + billreport.BillID);
                Console.WriteLine("Patient Name:" + searchpatien.Name);
                OutPatient searchpatients = HMSBAL.SearchOutPatientBL(searchpatient.PatientID);
                Console.WriteLine("Doctor Name:" + searchpatients.DoctorName);
                InPatient objpat = HMSBAL.SearchInPatientBL(searchpatient.PatientID);
                Console.WriteLine("Medical Bill:" + billreport.MedicalBill);
                LabReport objLAB = HMSBAL.SearchLabreportBL(searchlab.ReportID);
                Console.WriteLine("Lab Bill:" + objLAB.LabAmount);
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }


        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n*****************Hospital Management System****************");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. UpdatePatient");
            Console.WriteLine("3. PatientAppointment");
            Console.WriteLine("4. Search");
            Console.WriteLine("5. View");
            Console.WriteLine("6. Lab Report");
            Console.WriteLine("7. Bill Report");
            Console.WriteLine("8. Exit");
            Console.WriteLine("******************************************\n");

        }

    }
}
