﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMS_DAL;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_BAL
{
    public class HMSBAL
    {
        public static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();

            bool ValidatePatient = true;

            if (!(Convert.ToString(patient.PatientID).Length == 4))

            {

                ValidatePatient = false;

                sb.Append(Environment.NewLine + "PatientID Must Be 4 Digits");
            }

                if (patient.Name == string.Empty)

                {

                    ValidatePatient = false;

                    sb.Append(Environment.NewLine + "Invalid Patient Name");

                }


                if (patient.Gender == string.Empty)

                {

                    ValidatePatient = false;

                    sb.Append(Environment.NewLine + "Enter the Patient Gender");

                }

                

                if (patient.Address == string.Empty)

                {

                    ValidatePatient = false;

                    sb.Append(Environment.NewLine + "Invalid patient Address");

                }

                if (!Regex.Match(patient.PhoneNo, @"^([0-9]{10})$").Success)
                {

                    ValidatePatient = false;

                    sb.Append(Environment.NewLine + "Invalid PhoneNumber(Requires 10 digits)");

                }


                if (patient.Weight == string.Empty)

                {

                    ValidatePatient = false;

                    sb.Append(Environment.NewLine + "Invalid Weight");

                }

                if (ValidatePatient == false)

                    throw new HMSExceptions(sb.ToString());



            

            return ValidatePatient;

        }

        public static bool ValidateInPatient(InPatient inpatient)
        {
            StringBuilder sb = new StringBuilder();

            bool ValidateInPatient = true;

            if (!(Convert.ToString(inpatient.AppointmentID).Length == 3))

            {

                ValidateInPatient = false;

                sb.Append(Environment.NewLine + "Appointment ID Must Be 3 Digits");
            }

            if (!(Convert.ToString(inpatient.PatientID).Length == 4))

            {

                ValidateInPatient = false;

                sb.Append(Environment.NewLine + "PatientID Must Be 4 Digits");
            }

            if (inpatient.DoctorName == string.Empty)

            {

                ValidateInPatient = false;

                sb.Append(Environment.NewLine + "Invalid Doctor Name");

            }

            if(inpatient.RoomNo > 100)
            {

                ValidateInPatient = false;

                sb.Append(Environment.NewLine + "Only 100 Rooms are There!!");
            }

            if (ValidateInPatient == false)

                throw new HMSExceptions(sb.ToString());





            return ValidateInPatient;
        }

        private static bool ValidateOutpatient(OutPatient patient)

        {



            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (patient.DateOfVisit == null)

            {

                isValid = false;

                sb.Append("Treatment Date is Null" + Environment.NewLine);

            }



            if (patient.DoctorName.ToString() == null)

            {

                isValid = false;

                sb.Append("Doctor ID is Null" + Environment.NewLine);

            }



            if (patient.PatientID.ToString() == null)

            {

                isValid = false;

                sb.Append("Patient ID is Null" + Environment.NewLine);

            }



            if (!isValid)

            {

                throw new HMSExceptions(sb.ToString());

            }



            return isValid; ;

        }


        public static bool AddPatient(Patient AddPatient)
        {
            bool patientadded = false;


           
            try
            {
               if(ValidatePatient(AddPatient))
                {
                    patientadded = HMSDAL.AddPatient(AddPatient);
                    patientadded = true;
                }
               
                
                return patientadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool AddInPatient(InPatient AddInPatient)
        {
            bool Inpatientadded = false;



            try
            {
                if (ValidateInPatient(AddInPatient))
                {
                    Inpatientadded = HMSDAL.AddInPatient(AddInPatient);
                    Inpatientadded = true;
                }

                

                return Inpatientadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool AddOutPatient(OutPatient AddOutPatient)
        {
            bool Outpatientadded = false;



            try
            {
                if (ValidateOutpatient(AddOutPatient))
                {
                    Outpatientadded = HMSDAL.AddOutPatient(AddOutPatient);
                }

                return Outpatientadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool UpdatePatientBL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {

                HMSDAL patientDAL = new HMSDAL();
                    patientUpdated = patientDAL.UpdatePatientDAL(updatePatient);
                
            }
            catch (HMSExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }

        public static Patient SearchPatientBL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchPatientDAL(searchPatientID);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static LabReport SearchLabreportBL(int LabReportID)
        {
            LabReport searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchlabreportDAL(LabReportID);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        //public static LabReport SearchInPatientLabreportBL(int SearchpatientID)
        //{
        //    LabReport searchInPatient = null;
        //    try
        //    {
        //        HMSDAL patientDAL = new HMSDAL();
        //        searchInPatient = patientDAL.SearchInpatientLabReportDAL(SearchpatientID);
        //    }
        //    catch (HMSExceptions ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchInPatient;

        //}

        //public static LabReport SearchOutPatientLabreportBL(int SearchpatientID)
        //{
        //    LabReport searchOutPatient = null;
        //    try
        //    {
        //        HMSDAL patientDAL = new HMSDAL();
        //        searchOutPatient = patientDAL.SearchOutpatientLabReportDAL(SearchpatientID);
        //    }
        //    catch (HMSExceptions ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return searchOutPatient;

        //}


        public static InPatient SearchInPatientBL(int searchPatientID)
        {
            InPatient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchInPatientDAL(searchPatientID);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static InPatient SearchInPatientAdateBL(DateTime searchAdmissionDate)
        {
            InPatient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchInPatientADateDAL(searchAdmissionDate);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static InPatient SearchInPatientDdateBL(DateTime searchDischargeDate)
        {
            InPatient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchInPatientDDateDAL(searchDischargeDate);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static OutPatient SearchOutPatientBL(int searchPatientID)
        {
            OutPatient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchOutPatientDAL(searchPatientID);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }



        public static OutPatient SearchOutPatientDOVBL(DateTime searchDateofVisit)
        {
            OutPatient searchPatient = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                searchPatient = patientDAL.SearchOutPatientdovDAL(searchDateofVisit);
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }

        public static List<InPatient> ViewInPatientBL()
        {
            List<InPatient> InpatientList = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                InpatientList = patientDAL.ViewInPatientDAL();
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return InpatientList;
        }


        public static List<OutPatient> ViewOutPatientBL()
        {
            List<OutPatient> OutpatientList = null;
            try
            {
                HMSDAL patientDAL = new HMSDAL();
                OutpatientList = patientDAL.ViewOutPatientDAL();
            }
            catch (HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutpatientList;
        }

        public static bool LabReportPatientBL(LabReport labreport)
        {
            bool labreportadded = false;



            try
            {

                labreportadded = HMSDAL.LabReportPatientDAL(labreport);

                return labreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }



        public static bool BillReportInPatientBL(BillInformation billreport)
        {
            bool billreportadded = false;



            try
            {

                billreportadded = HMSDAL.BillReportInPatientDAL(billreport);

                return billreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }


        public static bool BillReportOutPatientBL(BillInformation billreport)
        {
            bool billreportadded = false;



            try
            {

                billreportadded = HMSDAL.BillReportOutPatientDAL(billreport);

                return billreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }


    }
}
