﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_DAL
{
    public class HMSDAL
    {
        public static List<Patient> patientList = new List<Patient>();
        public static List<InPatient> InpatientList = new List<InPatient>();
        public static List<OutPatient> OutpatientList = new List<OutPatient>();
        public static List<LabReport> LabreportList = new List<LabReport>();
        public static List<BillInformation> BillreportList = new List<BillInformation>();


        public static bool AddPatient(Patient Addpatient)
        {
            bool patientAdded = false;
            try
            {
                patientList.Add(Addpatient);
                patientAdded = true;
                return patientAdded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool AddInPatient(InPatient AddInpatient)
        {
            bool InpatientAdded = false;
            try
            {
                InpatientList.Add(AddInpatient);
                InpatientAdded = true;
                return InpatientAdded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool AddOutPatient(OutPatient AddOutpatient)
        {
            bool OutpatientAdded = false;
            try
            {
                OutpatientList.Add(AddOutpatient);
                OutpatientAdded = true;
                return OutpatientAdded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }



        public bool UpdatePatientDAL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                for (int i = 0; i < patientList.Count; i++)
                {
                    if (patientList[i].PatientID == updatePatient.PatientID)
                    {
                        updatePatient.Address = patientList[i].Address;
                        updatePatient.PhoneNo = patientList[i].PhoneNo;
                        updatePatient.Weight = patientList[i].Weight;
                        patientUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return patientUpdated;

        }


        public Patient SearchPatientDAL(int searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = patientList.Find(patient => patient.PatientID == searchPatientID);
            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }


        public LabReport SearchlabreportDAL(int LabReportID)
        {
            LabReport searchPatient = null;
            try
            {
                searchPatient = LabreportList.Find(labreport => labreport.ReportID == LabReportID);

            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        //public LabReport SearchInpatientLabReportDAL(int searchPatientID)
        //{
        //    LabReport searchInPatient = null;
        //    try
        //    {
        //        searchInPatient = LabreportList.Find(labreport => labreport.PatientID == searchPatientID);

        //    }
        //    catch (SystemException ex)
        //    {
        //        throw new HMSExceptions(ex.Message);
        //    }
        //    return searchInPatient;
        //}


        //public LabReport SearchOutpatientLabReportDAL(int searchPatientID)
        //{
        //    LabReport searchOutPatient = null;
        //    try
        //    {
        //        searchOutPatient = LabreportList.Find(labreport => labreport.PatientID == searchPatientID);

        //    }
        //    catch (SystemException ex)
        //    {
        //        throw new HMSExceptions(ex.Message);
        //    }
        //    return searchOutPatient;
        //}

        public InPatient SearchInPatientDAL(int searchPatientID)
        {
            InPatient searchPatient = null;
            try
            {
                searchPatient = InpatientList.Find(patient => patient.PatientID == searchPatientID);

            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public InPatient SearchInPatientADateDAL(DateTime searchAdmissionDate)
        {
            InPatient searchPatient = null;
            try
            {
                searchPatient = InpatientList.Find(patient => patient.AdmissionDate == searchAdmissionDate);

            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public InPatient SearchInPatientDDateDAL(DateTime searchDischargeDate)
        {
            InPatient searchPatient = null;
            try
            {
                searchPatient = InpatientList.Find(patient => patient.DisChargeDate == searchDischargeDate);

            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public OutPatient SearchOutPatientDAL(int searchPatientID)
        {
            OutPatient searchPatient = null;
            try
            {
                searchPatient = OutpatientList.Find(patient => patient.PatientID == searchPatientID);
            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public OutPatient SearchOutPatientdovDAL(DateTime searchDateOfVisit)
        {
            OutPatient searchPatient = null;
            try
            {
                searchPatient = OutpatientList.Find(patient => patient.DateOfVisit == searchDateOfVisit);
            }
            catch (SystemException ex)
            {
                throw new HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public List<InPatient> ViewInPatientDAL()
        {
            return InpatientList;
        }

        public List<OutPatient> ViewOutPatientDAL()
        {
            return OutpatientList;
        }

        public  static bool LabReportPatientDAL(LabReport labReport)
        {

            bool labreportadded = false;
            try
            {
                LabreportList.Add(labReport);
                labreportadded = true;
                return labreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }


        public static bool BillReportInPatientDAL(BillInformation billreport)
        {

            bool billreportadded = false;
            try
            {
                BillreportList.Add(billreport);
                billreportadded = true;
                return billreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }

        public static bool BillReportOutPatientDAL(BillInformation billreport)
        {

            bool billreportadded = false;
            try
            {
                BillreportList.Add(billreport);
                billreportadded = true;
                return billreportadded;
            }
            catch (SystemException ex)
            {

                throw new HMSExceptions(ex.Message);
            }
            catch (HMSExceptions e)
            {
                throw e;
            }
        }


    }
}
