﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
    public class BillInformation
    {
        public int BillID { get; set; }

        public int RoomAmount { get; set; }

        public int OperationTheatreAmount { get; set; }

        public int MedicalBill { get; set; }

        public int LabBill { get; set; }
    }
}
