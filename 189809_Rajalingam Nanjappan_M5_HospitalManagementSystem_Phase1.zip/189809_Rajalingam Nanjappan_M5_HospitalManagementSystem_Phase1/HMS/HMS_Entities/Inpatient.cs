﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
   public class InPatient
    {
        public int AppointmentID { get; set; }

        public int PatientID { get; set; }

        public string DoctorName { get; set; }

        public int RoomNo { get; set; }

        public DateTime AdmissionDate { get; set; }

        public DateTime DisChargeDate { get; set; }

        public string ReMarks { get; set; }
    }
}
