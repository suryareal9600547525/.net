﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Exceptions
{
    public class HMSExceptions :ApplicationException
    {
        public HMSExceptions() : base()
        {

        }
        public HMSExceptions(string message) : base(message)
        {

        }
        public HMSExceptions(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
