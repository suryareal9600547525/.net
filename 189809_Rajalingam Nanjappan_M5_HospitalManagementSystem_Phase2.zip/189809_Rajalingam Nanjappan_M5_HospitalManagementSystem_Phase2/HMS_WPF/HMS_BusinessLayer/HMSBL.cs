﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_DataAccessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;
using System.Text.RegularExpressions;

namespace HMS_BusinessLayer
{
    public class HMSBL
    {


        private static bool ValidatePatient(Patient Patient)

        {

            bool isValid = true;

            StringBuilder sb = new StringBuilder();



            if (Patient.Name == null)

            {

                isValid = false;

                sb.Append("Name is Empty!" + Environment.NewLine);

            }





            if ((Patient.Age) <= 0 | (Patient.Age) > 120)

            {

                isValid = false;

                sb.Append(Environment.NewLine + "Please Enter Age above 0 and Less than 120");

            }

            if (Patient.Gender == null)

            {

                isValid = false;

                sb.Append("Gender is Empty!" + Environment.NewLine);

            }




            if (Patient.Weight == null)

            {

                isValid = false;

                sb.Append("Weight is Empty!" + Environment.NewLine);

            }




            if (Patient.Address == null)

            {

                isValid = false;

                sb.Append("Address is Empty!" + Environment.NewLine);

            }





            if (!Regex.IsMatch(Patient.PhoneNo, @"[0-9]{10}"))

            {

                isValid = false;

                sb.Append(Environment.NewLine + "Phone Number must be 10 digits");

            }



            if (Patient.Disease == null)

            {

                isValid = false;

                sb.Append("Disease is Empty!" + Environment.NewLine);

            }

            if ((Patient.DoctorID).ToString() == null)

            {

                isValid = false;

                sb.Append("Doctor ID is Empty!" + Environment.NewLine);

            }

           

            if (!isValid)

            {

                throw new HMSExceptions(sb.ToString());

            }



            return isValid;

        }



        private static bool ValidateInpatient(InPatient patient)

        {



            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (patient.AdmissionDate == null)

            {

                isValid = false;

                sb.Append("Admission Date is Null" + Environment.NewLine);

            }



            if (patient.DisChargeDate == null)

            {

                isValid = false;

                sb.Append("Discharge Date is Null" + Environment.NewLine);

            }



            if ((patient.AdmissionDate) > (patient.DisChargeDate))

            {

                isValid = false;

                sb.Append("Error ---- Discharge Date Earlier than Admission date" + Environment.NewLine);

            }



            if (patient.DoctorID.ToString() == null)

            {

                isValid = false;

                sb.Append("Doctor Id is Null" + Environment.NewLine);

            }



            if (patient.PatientID.ToString() == null)

            {

                isValid = false;

                sb.Append("Patient Id is Null" + Environment.NewLine);

            }



            if (patient.LabID.ToString() == null)

            {

                isValid = false;

                sb.Append("Lab Id is Null" + Environment.NewLine);

            }

            if (!isValid)

            {

                throw new HMSExceptions(sb.ToString());

            }



            return isValid;

        }



        private static bool ValidateOutpatient(OutPatient patient)

        {



            bool isValid = true;

            StringBuilder sb = new StringBuilder();

            if (patient.TreatmentDate == null)

            {

                isValid = false;

                sb.Append("Treatment Date is Null" + Environment.NewLine);

            }



            if (patient.DoctorID.ToString() == null)

            {

                isValid = false;

                sb.Append("Doctor ID is Null" + Environment.NewLine);

            }



            if (patient.PatientID.ToString() == null)

            {

                isValid = false;

                sb.Append("Patient ID is Null" + Environment.NewLine);

            }



            if (patient.LabID.ToString() == null)

            {

                isValid = false;

                sb.Append("Lab ID is Null" + Environment.NewLine);

            }



            if (!isValid)

            {

                throw new HMSExceptions(sb.ToString());

            }



            return isValid; ;

        }

        public static bool AddPatientBL(Patient Addpatient)
        {
            bool patientadded = false;
            try
            {
                if (ValidatePatient(Addpatient))
                {
                    patientadded = HMSDAL.AddPatientDAL(Addpatient);
                }
                
            }
            
            catch (Exception ex)
            {
                throw ex;
            }

            return patientadded;
        }

        public static bool AddInPatientBL(InPatient AddInpatient)
        {
            bool Inpatientadded = false;
            try
            {
                if(ValidateInpatient(AddInpatient))
                
                    Inpatientadded = HMSDAL.AddInPatientDAL(AddInpatient);
                
            }       
            catch (Exception ex)
            {
                throw ex;
            }

            return Inpatientadded;
        }

        public static bool AddOutPatientBL(OutPatient AddOutpatient)
        {
            bool Outpatientadded = false;
            try
            {
                if (ValidateOutpatient(AddOutpatient))
                {
                    Outpatientadded = HMSDAL.AddOutPatientDAL(AddOutpatient);
                }
            } 
            catch (Exception ex)
            {
                throw ex;
            }

            return Outpatientadded;
        }

        public static DataTable GetDoctorsBL()

        {

            DataTable doctorsList;

            try

            {

                HMSDAL doctorDal = new HMSDAL();

                doctorsList = doctorDal.GetDoctorsDAL();

            }

            catch (HMSExceptions ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return doctorsList;

        }


        public static DataTable GetPatientBL()

        {

            DataTable patientList;

            try

            {

                HMSDAL patientdal = new HMSDAL();

                patientList = patientdal.GetPatientsDAL();

            }

            catch (HMSExceptions ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return patientList;

        }

        public static DataTable GetLabBL()

        {

            DataTable LabList;

            try

            {

                HMSDAL labdal = new HMSDAL();

                LabList = labdal.GetLabDAL();

            }

            catch (HMSExceptions ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return LabList;

        }





        public static bool AddDoctorBL(Doctor adddoctor)
        {
            bool doctoradded = false;
            try
            {
                doctoradded = HMSDAL.AddDoctorDAL(adddoctor);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return doctoradded;
        }

       

        public static bool AddlabReportBL(Lab addlabreport)
        {
            bool labreportadded = false;
            try
            {
                labreportadded = HMSDAL.AddLabreportDAL(addlabreport);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return labreportadded;
        }


        public static bool UpdatePatientBL(Patient updatepatient)
        {
            bool patientupdated = false;
            try
            {
                patientupdated = HMSDAL.UpdatePatientDAL(updatepatient);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientupdated;
        }


        public static bool UpdateInPatientBL(InPatient updateinpatient)
        {
            bool Inpatientupdated = false;
            try
            {
                Inpatientupdated = HMSDAL.UpdateInPatientDAL(updateinpatient);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Inpatientupdated;
        }


        public static bool UpdateOutPatientBL(OutPatient updateoutpatient)
        {
            bool Outpatientupdated = false;
            try
            {
                Outpatientupdated = HMSDAL.UpdateOutPatientDAL(updateoutpatient);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Outpatientupdated;
        }


        public static bool UpdateDoctorBL(Doctor updatedoctor)
        {
            bool Doctorupdated = false;
            try
            {
                Doctorupdated = HMSDAL.UpdateDoctorDAL(updatedoctor);
            }
            catch (HMSExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Doctorupdated;
        }


        public static Patient SearchPatientBL(int patientId)
        {

            
            HMSDAL objDAL = new HMSDAL();
            Patient patient = new Patient();
            try
            {
                patient = objDAL.SearchPatientDAL(patientId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patient;
        }

        public static InPatient SearchInPatientBL(int patientId)
        {


            HMSDAL objDAL = new HMSDAL();
            InPatient inpatient = new InPatient();
            try
            {
                inpatient = objDAL.SearchInPatientDAL(patientId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return inpatient;
        }


        public static OutPatient SearchOutPatientBL(int patientId)
        {


            HMSDAL objDAL = new HMSDAL();
            OutPatient outpatient = new OutPatient();
            try
            {
                outpatient = objDAL.SearchOutPatientDAL(patientId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return outpatient;
        }

        public static Doctor SearchDoctorBL(int doctorId)
        {
            HMSDAL objDAL = new HMSDAL();
            Doctor doctor = null;
            try
            {
                doctor = objDAL.SearchDoctor(doctorId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return doctor;
        }


        public static List<Patient> SelectAllBL()
        {
            List<Patient> request = null;
            HMSDAL objDAL = new HMSDAL();
            try
            {
                request = objDAL.SelectAll();
            }
            catch (Exception e)
            {
                throw e;
            }
            return request;
        }


        public static List<InPatient> SelectInPatientBL()
        {
            List<InPatient> request = null;
            HMSDAL objDAL = new HMSDAL();
            try
            {
                request = objDAL.SelectInPatient();
            }
            catch (Exception e)
            {
                throw e;
            }
            return request;
        }


        public static List<OutPatient> SelectOutPatientBL()
        {
            List<OutPatient> request = null;
            HMSDAL objDAL = new HMSDAL();
            try
            {
                request = objDAL.SelectOutPatient();
            }
            catch (Exception e)
            {
                throw e;
            }
            return request;
        }


        public static Lab SearchLabBL(int patientId)
        {
            HMSDAL objDAL = new HMSDAL();
            Lab labreport = null;
            try
            {
                labreport = objDAL.LabReport(patientId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labreport;
        }


        public static Lab SearchLab(int labId)
        {
            HMSDAL objDAL = new HMSDAL();
            Lab lab = null;
            try
            {
                lab = objDAL.SearchLab(labId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lab;
        }


        public bool AddBillBL(BillData bill)
        {
            HMSDAL objDAL = new HMSDAL();
            bool billAdded = false;
            try
            {
                billAdded = objDAL.AddBillDAL(bill);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billAdded;
        }


        public bool AddBillBL2(BillData bill)
        {
            HMSDAL objDAL = new HMSDAL();
            bool billAdded = false;
            try
            {
                billAdded = objDAL.AddBillDAL2(bill);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billAdded;
        }


        public static BillData SearchBillBL(int patientID)
        {
            HMSDAL objDAL = new HMSDAL();
            BillData billreport = null;
            try
            {
                billreport = objDAL.BillReport(patientID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billreport;
        }

        public static BillData SearchBill2BL(int patientId)
        {
            HMSDAL objDAL = new HMSDAL();
            BillData billreport = null;
            try
            {
                billreport = objDAL.BillReport2(patientId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billreport;
        }
    }

}
