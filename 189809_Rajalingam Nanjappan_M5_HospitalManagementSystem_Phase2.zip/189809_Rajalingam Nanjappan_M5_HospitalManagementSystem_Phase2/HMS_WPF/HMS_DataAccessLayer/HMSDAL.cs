﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HMS_DataAccessLayer
{
    public class HMSDAL
    {
        public  static bool AddPatientDAL(Patient patient)
        {
            bool patientadded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("[rj_189809].[SPPatient]", objcon);
                objcom.CommandType = CommandType.StoredProcedure;


                SqlParameter objSqlParam_name = new SqlParameter("@name", patient.Name);
                SqlParameter objSqlParam_age = new SqlParameter("@age", patient.Age);
                SqlParameter objSqlParam_gender = new SqlParameter("@gender", patient.Gender);
                SqlParameter objSqlParam_address = new SqlParameter("@address", patient.Address);
                SqlParameter objSqlParam_phoneno = new SqlParameter("@phoneno", patient.PhoneNo);
                SqlParameter objSqlParam_weight = new SqlParameter("@weight", patient.Weight);
                SqlParameter objSqlParam_disease = new SqlParameter("@disease", patient.Disease);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", patient.DoctorID);

                
                objcom.Parameters.Add(objSqlParam_name);
                objcom.Parameters.Add(objSqlParam_age);
                objcom.Parameters.Add(objSqlParam_gender);
                objcom.Parameters.Add(objSqlParam_address);
                objcom.Parameters.Add(objSqlParam_phoneno);
                objcom.Parameters.Add(objSqlParam_weight);
                objcom.Parameters.Add(objSqlParam_disease);
                objcom.Parameters.Add(objSqlParam_doctorid);

                objcon.Open();
                objcom.ExecuteNonQuery();
                patientadded = true;
               
            }
            catch (SqlException objSqlEx)
            {

                throw new HMSExceptions(objSqlEx.Message);
            }

            finally
            {
                objcon.Close();
            }
            return patientadded;
        }

        public DataTable GetDoctorsDAL()

        {

            DataTable DoctorsList = null;

            SqlConnection objCon = null;

            try

            {



                objCon = new SqlConnection(

                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);

                SqlCommand objCom = new SqlCommand("select * from rj_189809.Doctor", objCon);

             

                //

                objCon.Open();

                SqlDataReader objDR = objCom.ExecuteReader();

                DoctorsList = new DataTable();

                DoctorsList.Load(objDR);

            }

            catch (SqlException ex)

            {

                throw new HMSExceptions(ex.Message);

            }

            finally

            {

                objCon.Close();

            }

            return DoctorsList;

        }

        public DataTable GetPatientsDAL()

        {

            DataTable PatientList = null;

            SqlConnection objCon = null;

            try

            {



                objCon = new SqlConnection(

                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);

                SqlCommand objCom = new SqlCommand("select PatientID from rj_189809.Patient", objCon);



                //

                objCon.Open();

                SqlDataReader objDR = objCom.ExecuteReader();

                PatientList = new DataTable();

                PatientList.Load(objDR);

            }

            catch (SqlException ex)

            {

                throw new HMSExceptions(ex.Message);

            }

            finally

            {

                objCon.Close();

            }

            return PatientList;

        }

        public DataTable GetLabDAL()
        {
            DataTable LabList = null;

            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(

                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);

                SqlCommand objCom = new SqlCommand("select LabID,LabFees from rj_189809.Lab", objCon);
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();

                LabList = new DataTable();

                LabList.Load(objDR);

            }

            catch (SqlException ex)

            {

                throw new HMSExceptions(ex.Message);

            }

            finally

            {

                objCon.Close();

            }

            return LabList;
        }

        public static bool AddInPatientDAL(InPatient Inpatient)
        {

            bool Inpatientadded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("[rj_189809].[SPInPatient]", objcon);
                objcom.CommandType = CommandType.StoredProcedure;


                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", Inpatient.PatientID);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", Inpatient.DoctorID);
                SqlParameter objSqlParam_roomno = new SqlParameter("@roomno", Inpatient.RoomNo);
                SqlParameter objSqlParam_admissiondate = new SqlParameter("@admissiondate", Inpatient.AdmissionDate);
                SqlParameter objSqlParam_dischargedate = new SqlParameter("@dischargedate", Inpatient.DisChargeDate);
                SqlParameter objSqlParam_labid = new SqlParameter("@labid", Inpatient.LabID);
               


                objcom.Parameters.Add(objSqlParam_patientid);
                objcom.Parameters.Add(objSqlParam_doctorid);
                objcom.Parameters.Add(objSqlParam_roomno);
                objcom.Parameters.Add(objSqlParam_admissiondate);
                objcom.Parameters.Add(objSqlParam_dischargedate);
                objcom.Parameters.Add(objSqlParam_labid);
                

                objcon.Open();
                objcom.ExecuteNonQuery();
                Inpatientadded = true;

            }
            catch (SqlException objSqlEx)
            {

                throw new HMSExceptions(objSqlEx.Message);
            }

            finally
            {
                objcon.Close();
            }
            return Inpatientadded;
        }

        public static bool AddDoctorDAL(Doctor adddoctor)
        {
            bool doctoradded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("[rj_189809].[SPDoctor]", objcon);
                objcom.CommandType = CommandType.StoredProcedure;


                SqlParameter objSqlParam_doctorname = new SqlParameter("@doctorname", adddoctor.DoctorName);
                SqlParameter objSqlParam_department = new SqlParameter("@dept", adddoctor.Department);
                SqlParameter objSqlParam_doctorfees = new SqlParameter("@doctorfees", adddoctor.DoctorFees);

                objcom.Parameters.Add(objSqlParam_doctorname);
                objcom.Parameters.Add(objSqlParam_department);
                objcom.Parameters.Add(objSqlParam_doctorfees);

                objcon.Open();
                objcom.ExecuteNonQuery();
                doctoradded = true;
            }

            catch (SqlException objSqlEx)
            {

                throw new HMSExceptions(objSqlEx.Message);
            }

            finally
            {
                objcon.Close();
            }
            return doctoradded;
        }


        public static bool AddOutPatientDAL(OutPatient outpatient)
        {

            bool Outpatientadded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("[rj_189809].[SPOutPatient]", objcon);
                objcom.CommandType = CommandType.StoredProcedure;


                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", outpatient.PatientID);
                SqlParameter objSqlParam_treatmentdate = new SqlParameter("@treatmentdate", outpatient.TreatmentDate);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", outpatient.DoctorID);
                SqlParameter objSqlParam_labid = new SqlParameter("@labid", outpatient.LabID);



                objcom.Parameters.Add(objSqlParam_patientid);
                objcom.Parameters.Add(objSqlParam_doctorid);
                objcom.Parameters.Add(objSqlParam_treatmentdate);
                objcom.Parameters.Add(objSqlParam_labid);


                objcon.Open();
                objcom.ExecuteNonQuery();
                Outpatientadded = true;

            }
            catch (SqlException objSqlEx)
            {

                throw new HMSExceptions(objSqlEx.Message);
            }

            finally
            {
                objcon.Close();
            }
            return Outpatientadded;
        }

        public static bool AddLabreportDAL(Lab labreport)
        {
            bool Outpatientadded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("[rj_189809].[SPLab]", objcon);
                objcom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_labid = new SqlParameter("@labid", labreport.LabID);
                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", labreport.PatientID);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", labreport.DoctorID);
                SqlParameter objSqlParam_testdate = new SqlParameter("@testdate", labreport.TestDate);
                SqlParameter objSqlParam_testtype = new SqlParameter("@testtype", labreport.TestType);
                SqlParameter objSqlParam_labfees = new SqlParameter("@labfees", labreport.LabFees);



                objcom.Parameters.Add(objSqlParam_labid);
                objcom.Parameters.Add(objSqlParam_patientid);
                objcom.Parameters.Add(objSqlParam_doctorid);
                objcom.Parameters.Add(objSqlParam_testdate);
                objcom.Parameters.Add(objSqlParam_testtype);
                objcom.Parameters.Add(objSqlParam_labfees);


                objcon.Open();
                objcom.ExecuteNonQuery();
                Outpatientadded = true;

            }
            catch (SqlException objSqlEx)
            {

                throw new HMSExceptions(objSqlEx.Message);
            }

            finally
            {
                objcon.Close();
            }
            return Outpatientadded;





        }

        public static bool UpdatePatientDAL(Patient patient)
        {
            bool patientupdated = false;
            SqlConnection objcon = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPUpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", patient.PatientID);
                SqlParameter objSqlParam_name = new SqlParameter("@name", patient.Name);
                SqlParameter objSqlParam_age = new SqlParameter("@age", patient.Age);
                SqlParameter objSqlParam_address = new SqlParameter("@address", patient.Address);
                SqlParameter objSqlParam_phoneno = new SqlParameter("@phoneno", patient.PhoneNo);
                SqlParameter objSqlParam_weight = new SqlParameter("@weight", patient.Weight);
                SqlParameter objSqlParam_disease = new SqlParameter("@disease", patient.Disease);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", patient.DoctorID);

                objCom.Parameters.Add(objSqlParam_patientid);
                objCom.Parameters.Add(objSqlParam_name);
                objCom.Parameters.Add(objSqlParam_age);
                objCom.Parameters.Add(objSqlParam_address);
                objCom.Parameters.Add(objSqlParam_phoneno);
                objCom.Parameters.Add(objSqlParam_weight);
                objCom.Parameters.Add(objSqlParam_disease);
                objCom.Parameters.Add(objSqlParam_doctorid);

                objcon.Open();
                objCom.ExecuteNonQuery();
                patientupdated = true;


            }

             catch(SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patientupdated;
        }


        public static bool UpdateInPatientDAL(InPatient Inpatient)
        {
            bool patientupdated = false;
            SqlConnection objcon = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPUInpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", Inpatient.PatientID);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", Inpatient.DoctorID);
                SqlParameter objSqlParam_roomno = new SqlParameter("@roomno", Inpatient.RoomNo);
                SqlParameter objSqlParam_admissiondate= new SqlParameter("@admissiondate", Inpatient.AdmissionDate);
                SqlParameter objSqlParam_dischargedate = new SqlParameter("@dischargedate", Inpatient.DisChargeDate);
                SqlParameter objSqlParam_labid = new SqlParameter("@labid", Inpatient.LabID);
               
                objCom.Parameters.Add(objSqlParam_patientid);
                objCom.Parameters.Add(objSqlParam_doctorid);
                objCom.Parameters.Add(objSqlParam_roomno);
                objCom.Parameters.Add(objSqlParam_admissiondate);
                objCom.Parameters.Add(objSqlParam_dischargedate);
                objCom.Parameters.Add(objSqlParam_labid);
               
                objcon.Open();
                objCom.ExecuteNonQuery();
                patientupdated = true;


            }

            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patientupdated;
        }



        public static bool UpdateOutPatientDAL(OutPatient Outpatient)
        {
            bool outpatientupdated = false;
            SqlConnection objcon = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPUOutpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_patientid = new SqlParameter("@patientid", Outpatient.PatientID);
                SqlParameter objSqlParam_treatmentdate = new SqlParameter("@treatmentdate", Outpatient.TreatmentDate);
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", Outpatient.DoctorID);
                SqlParameter objSqlParam_labid= new SqlParameter("@labid", Outpatient.LabID);
               

                objCom.Parameters.Add(objSqlParam_patientid);
                objCom.Parameters.Add(objSqlParam_treatmentdate);
                objCom.Parameters.Add(objSqlParam_doctorid);
                objCom.Parameters.Add(objSqlParam_labid);

                objcon.Open();
                objCom.ExecuteNonQuery();
                outpatientupdated = true;


            }

            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return outpatientupdated;
        }


        public static bool UpdateDoctorDAL(Doctor doctor)
        {
            bool doctorupdated = false;
            SqlConnection objcon = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPUDoctor]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_doctorid = new SqlParameter("@doctorid", doctor.DoctorID);
                SqlParameter objSqlParam_doctorname = new SqlParameter("@doctorname", doctor.DoctorName);
                SqlParameter objSqlParam_department = new SqlParameter("@department", doctor.Department);
                SqlParameter objSqlParam_doctorfees = new SqlParameter("@doctorfees", doctor.DoctorFees);


                objCom.Parameters.Add(objSqlParam_doctorid);
                objCom.Parameters.Add(objSqlParam_doctorname);
                objCom.Parameters.Add(objSqlParam_department);
                objCom.Parameters.Add(objSqlParam_doctorfees);

                objcon.Open();
                objCom.ExecuteNonQuery();
                doctorupdated = true;


            }

            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return doctorupdated;
        }

        public Patient SearchPatientDAL(int PatientID)
        {
            Patient patient = new Patient();
            

            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSPatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

        objCom.Parameters.AddWithValue("@patientid", PatientID);

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    patient.PatientID = Convert.ToInt32(dr[0]);
                    patient.Name = dr[1].ToString();
                    patient.Age = Convert.ToInt32(dr[2]);
                    patient.Gender = dr[3].ToString();
                    patient.Address = dr[4].ToString();
                    patient.PhoneNo = dr[5].ToString();
                    patient.Weight = dr[6].ToString();
                    patient.Disease = dr[7].ToString();
                    patient.DoctorID = Convert.ToInt32(dr[8]);
                }
               
                
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patient;
        }


        public InPatient SearchInPatientDAL(int PatientID)
        {
            InPatient inpatient = new InPatient();


            SqlConnection objcon = null;

            SqlDataReader dr = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSInpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@patientid", PatientID);

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    inpatient.PatientID = Convert.ToInt32(dr[0]);
                    inpatient.DoctorID = Convert.ToInt32(dr[1]);
                    inpatient.RoomNo = Convert.ToInt32(dr[2]);
                    inpatient.AdmissionDate = Convert.ToDateTime(dr[3]); 
                    inpatient.DisChargeDate = Convert.ToDateTime(dr[4]);
                    inpatient.LabID = Convert.ToInt32(dr[5]);

                }


            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return inpatient;
        }


        public OutPatient SearchOutPatientDAL(int PatientID)
        {
            OutPatient outpatient = new OutPatient();


            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {

                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSOutpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@patientid", PatientID);

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    outpatient.PatientID = Convert.ToInt32(dr[0]);
                    outpatient.TreatmentDate = Convert.ToDateTime(dr[1]); 
                    outpatient.DoctorID = Convert.ToInt32(dr[2]);
                    outpatient.LabID = Convert.ToInt32(dr[3]);
                    

                }


            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return outpatient;
        }


        public Doctor SearchDoctor(int doctorId)
        {
            Doctor doctor = new Doctor();
            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSDoctor]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@DoctorId", doctorId);
                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    doctor.DoctorID = Convert.ToInt32(dr[0]);
                    doctor.DoctorName = dr[1].ToString();
                    doctor.DoctorFees = Convert.ToInt32(dr[2]);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                dr.Close();
                objcon.Close();
            }
            return doctor;
        }

        public Lab SearchLab(int labId)
        {
            Lab lab = null;
           
            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("select * from rj_189809.Lab where LabID=@LabId", objcon);
               
                
               

                objCom.Parameters.AddWithValue("@LabId", labId);
                objcon.Open();
                dr = objCom.ExecuteReader();
                if (dr.Read())
                {
                  lab = new Lab();
                    lab.LabID = Convert.ToInt32(dr[0]);
                    lab.PatientID = Convert.ToInt32(dr[1]);
                    lab.DoctorID = Convert.ToInt32(dr[2]);
                    lab.TestDate = Convert.ToDateTime(dr[3]);
                    lab.TestType = dr[4] as string;
                    lab.LabFees = Convert.ToInt32(dr[5]);
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                objcon.Close();
            }
            return lab;
        }



        public List<Patient> SelectAll()
        {
            List<Patient> patient1 = new List<Patient>();


            

            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPLpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    Patient patient = new Patient();

                    patient.PatientID = Convert.ToInt32(dr[0]);
                    patient.Name = dr[1].ToString();
                    patient.Age = Convert.ToInt32(dr[2]);
                    patient.Gender = dr[3].ToString();
                    patient.Address = dr[4].ToString();
                    patient.PhoneNo = dr[5].ToString();
                    patient.Weight = dr[6].ToString();
                    patient.Disease = dr[7].ToString();
                    patient.DoctorID = Convert.ToInt32(dr[8]);

                    patient1.Add(patient);
                }
               
            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patient1;
        }



        public List<InPatient> SelectInPatient()
        {
            List<InPatient> patient1 = new List<InPatient>();




            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPLInpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    InPatient patient = new InPatient();

                    patient.PatientID = Convert.ToInt32(dr[0]);
                    patient.DoctorID = Convert.ToInt32(dr[1]);
                    patient.RoomNo = Convert.ToInt32(dr[2]);
                    patient.AdmissionDate = Convert.ToDateTime(dr[3]);
                    patient.DisChargeDate = Convert.ToDateTime(dr[4]);
                    patient.LabID = Convert.ToInt32(dr[5]);
                    
                    

                    patient1.Add(patient);
                }

            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patient1;
        }



        public List<OutPatient> SelectOutPatient()
        {
            List<OutPatient> patient1 = new List<OutPatient>();




            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPLOutpatient]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objcon.Open();
                dr = objCom.ExecuteReader();
                while (dr.Read())
                {
                    OutPatient patient = new OutPatient();

                    patient.PatientID = Convert.ToInt32(dr[0]);
                    patient.TreatmentDate = Convert.ToDateTime(dr[1]);
                    patient.DoctorID = Convert.ToInt32(dr[2]);
                    patient.LabID = Convert.ToInt32(dr[3]);



                    patient1.Add(patient);
                }

            }
            catch (SqlException objSqlEx)
            {
                throw new HMSExceptions(objSqlEx.Message);
            }
            finally
            {
                objcon.Close();
            }
            return patient1;
        }



        public Lab LabReport(int patientId)
        {
            Lab labReport = null;                                                                                                           
            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSLab]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@pid", patientId);


                objcon.Open();
                dr = objCom.ExecuteReader();
                if (dr.Read())
                {
                    labReport = new Lab();
                    labReport.LabID = Convert.ToInt32(dr[0]);
                    labReport.PatientID = Convert.ToInt32(dr[1]); 
                    labReport.DoctorID = Convert.ToInt32(dr[2]);
                    labReport.TestDate = Convert.ToDateTime(dr[3]);
                    labReport.TestType = dr[4].ToString();
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                objcon.Close();
            }
            return labReport;
        }


        public bool AddBillDAL(BillData bill)
        {
            bool billAdded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(
                   ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSBillData]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;


                SqlParameter sqlParameter_billNo = new SqlParameter("@BillNo", bill.BillNo);
                SqlParameter sqlParameter_patientId = new SqlParameter("@PatientId", bill.PatientID);
                SqlParameter sqlParameter_patientName = new SqlParameter("@PatientName", bill.PatientName);
                SqlParameter sqlParameter_doctorId = new SqlParameter("@DoctorId", bill.DoctorID);
                SqlParameter sqlParameter_doctorName = new SqlParameter("@DoctorName", bill.DoctorName);
                SqlParameter sqlParameter_doctorFees = new SqlParameter("@DoctorFees", bill.DoctorFees);
                SqlParameter sqlParameter_roomType = new SqlParameter("@RoomType", bill.RoomNo);
                SqlParameter sqlParameter_roomCharge = new SqlParameter("@RoomCharge", bill.RoomCharge);
                SqlParameter sqlParameter_operationCharge = new SqlParameter("@OperationCharge", bill.OperationCharges);
                SqlParameter sqlParameter_medicineFees = new SqlParameter("@MedicineFees", bill.MedicineFees);
                SqlParameter sqlParameter_labId = new SqlParameter("@LabId", bill.LabID);
                SqlParameter sqlParameter_totaldays = new SqlParameter("@TotalDays", bill.TotalDays);
                SqlParameter sqlParameter_labFees = new SqlParameter("@LabFees", bill.LabFees);
                SqlParameter sqlParameter_totalAmount = new SqlParameter("@TotalAmount", bill.TotalAmount);

                objCom.Parameters.Add(sqlParameter_billNo);
                objCom.Parameters.Add(sqlParameter_patientId);
                objCom.Parameters.Add(sqlParameter_patientName);
                objCom.Parameters.Add(sqlParameter_doctorId);
                objCom.Parameters.Add(sqlParameter_doctorName);
                objCom.Parameters.Add(sqlParameter_doctorFees);
                objCom.Parameters.Add(sqlParameter_roomType);
                objCom.Parameters.Add(sqlParameter_roomCharge);
                objCom.Parameters.Add(sqlParameter_operationCharge);
                objCom.Parameters.Add(sqlParameter_medicineFees);
                objCom.Parameters.Add(sqlParameter_labId);
                objCom.Parameters.Add(sqlParameter_totaldays);
                objCom.Parameters.Add(sqlParameter_labFees);
                objCom.Parameters.Add(sqlParameter_totalAmount);

                objcon.Open();
                int n = objCom.ExecuteNonQuery();
                if (n > 0)
                    billAdded = true;
                else
                    billAdded = false;
                objcon.Close();
                return billAdded;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        

        public bool AddBillDAL2(BillData bill)
        {
            bool billAdded = false;
            SqlConnection objcon = null;
            try
            {
                objcon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPSBillData1]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlParameter_billNo = new SqlParameter("@BillNo", bill.BillNo);
                SqlParameter sqlParameter_patientId = new SqlParameter("@PatientId", bill.PatientID);
                SqlParameter sqlParameter_patientName = new SqlParameter("@PatientName", bill.PatientName); 
                SqlParameter sqlParameter_doctorId = new SqlParameter("@DoctorId", bill.DoctorID);
                SqlParameter sqlParameter_doctorName = new SqlParameter("@DoctorName", bill.DoctorName);
                SqlParameter sqlParameter_doctorFees = new SqlParameter("@DoctorFees", bill.DoctorFees);
                //SqlParameter sqlParameter_roomType = new SqlParameter("@RoomType", bill.roomType);
                //SqlParameter sqlParameter_roomCharge = new SqlParameter("@RoomCharge", bill.roomCharge);
                //SqlParameter sqlParameter_operationCharge = new SqlParameter("@OperationCharge", bill.operationCharge);
                SqlParameter sqlParameter_medicineFees = new SqlParameter("@MedicineFees", bill.MedicineFees);
                SqlParameter sqlParameter_labId = new SqlParameter("@LabId", bill.LabID);
                //SqlParameter sqlParameter_totaldays = new SqlParameter("@TotalDays", bill.totaldays);
                SqlParameter sqlParameter_labFees = new SqlParameter("@LabFees", bill.LabFees);
                SqlParameter sqlParameter_totalAmount = new SqlParameter("@TotalAmount", bill.TotalAmount);

                objCom.Parameters.Add(sqlParameter_billNo);
                objCom.Parameters.Add(sqlParameter_patientId);
                objCom.Parameters.Add(sqlParameter_patientName);

                objCom.Parameters.Add(sqlParameter_doctorId);
                objCom.Parameters.Add(sqlParameter_doctorName);
                objCom.Parameters.Add(sqlParameter_doctorFees);
                //cmd.Parameters.Add(sqlParameter_roomType);
                //cmd.Parameters.Add(sqlParameter_roomCharge);
                //cmd.Parameters.Add(sqlParameter_operationCharge);
                objCom.Parameters.Add(sqlParameter_medicineFees);
                objCom.Parameters.Add(sqlParameter_labId);
                //cmd.Parameters.Add(sqlParameter_totaldays);
                objCom.Parameters.Add(sqlParameter_labFees);
                objCom.Parameters.Add(sqlParameter_totalAmount);

                objcon.Open();
                int n = objCom.ExecuteNonQuery();
                if (n > 0)
                    billAdded = true;
                else
                    billAdded = false;
                objcon.Close();
                return billAdded;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public BillData BillReport(int patientId)
        {
            BillData billReport = null;
           
            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {
                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPRBill]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@pid", patientId);


                objcon.Open();
                dr = objCom.ExecuteReader();
                if (dr.Read())
                {
                    billReport = new BillData();
                    billReport.BillNo = Convert.ToInt32(dr[0]);
                    billReport.PatientID = Convert.ToInt32(dr[1]);
                    billReport.PatientName = dr[2] as string;
                    billReport.DoctorID = Convert.ToInt32(dr[3]);
                    billReport.DoctorName = dr[4] as string;
                    billReport.DoctorFees = Convert.ToInt32(dr[4]);
                    billReport.RoomNo = Convert.ToInt32(dr[5]);
                    billReport.RoomCharge = Convert.ToInt32(dr[6]);
                    billReport.OperationCharges = Convert.ToInt32(dr[7]);
                    billReport.MedicineFees = Convert.ToInt32(dr[8]);
                    billReport.LabID = Convert.ToInt32(dr[9]);
                    billReport.LabFees = Convert.ToInt32(dr[10]);
                    billReport.TotalAmount = Convert.ToInt32(dr[11]);
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                objcon.Close();
            }
            return billReport;
        }

        public BillData BillReport2(int patientId)
        {
            BillData billReport = new BillData();
            SqlConnection objcon = null;
            SqlDataReader dr = null;
            try
            {

                objcon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["HMSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[rj_189809].[SPRBill1]", objcon);
                objCom.CommandType = CommandType.StoredProcedure;


                objCom.Parameters.AddWithValue("@pid", patientId);


                objcon.Open();
                dr = objCom.ExecuteReader();
                if (dr.Read())
                {
                    billReport = new BillData();
                    billReport.BillNo = Convert.ToInt32(dr[0]);
                    billReport.PatientID = Convert.ToInt32(dr[1]);
                    billReport.PatientName = dr[2] as string;
                    billReport.DoctorName = dr[3] as string;
                    billReport.DoctorFees = Convert.ToInt32(dr[4]);
                    billReport.MedicineFees = Convert.ToInt32(dr[5]);
                    billReport.LabFees = Convert.ToInt32(dr[6]);
                    billReport.TotalAmount = Convert.ToInt32(dr[7]);
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                objcon.Close();
            }
            return billReport;
        }
    }
}
            

