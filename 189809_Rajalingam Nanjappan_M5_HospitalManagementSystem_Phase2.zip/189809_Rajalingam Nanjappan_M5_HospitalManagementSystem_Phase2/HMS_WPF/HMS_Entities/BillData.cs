﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
   public  class BillData
    {
        public int BillNo { get; set; }

        public int PatientID { get; set; }

        public string PatientName { get; set; }

        public int DoctorID { get; set; }

        public string DoctorName { get; set; }

        public int DoctorFees { get; set; }

        public int RoomNo { get; set; }

        public int RoomCharge { get; set; }

        public int OperationCharges { get; set; }

        public int MedicineFees { get; set; }

        public int LabID { get; set; }
        public int TotalDays { get; set; }

        public int LabFees { get; set; }

        public int TotalAmount { get; set; }
    }
}


