﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
   public  class Doctor
    {
        public int DoctorID { get; set; }

        public string DoctorName { get; set; }

        public string Department { get; set; }

        public int DoctorFees { get; set; }
    }
}
