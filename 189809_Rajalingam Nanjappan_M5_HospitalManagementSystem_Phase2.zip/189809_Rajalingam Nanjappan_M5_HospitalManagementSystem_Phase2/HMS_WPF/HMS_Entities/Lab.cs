﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS_Entities
{
   public  class Lab
    {
        public int LabID { get; set; }

        public int PatientID { get; set; }

        public int DoctorID { get; set; }

        public DateTime TestDate { get; set; }

        public string TestType { get; set; }

        public int LabFees { get; set; }


    }
}
