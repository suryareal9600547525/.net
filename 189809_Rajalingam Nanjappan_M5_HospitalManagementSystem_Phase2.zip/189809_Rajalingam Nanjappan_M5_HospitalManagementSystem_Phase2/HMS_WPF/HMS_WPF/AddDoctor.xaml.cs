﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for AddDoctor.xaml
    /// </summary>
    public partial class AddDoctor : Window
    {
        public AddDoctor()
        {
            InitializeComponent();
        }

        private void Adddoctor_Click(object sender, RoutedEventArgs e)
        {
            Adddoctor();
        }

        private void Adddoctor()
        {
            try
            {
                string doctorname;
                string department;
                int doctorfees;

                bool doctoradded;

                doctorname = txtdname.Text;
                department = txtddept.Text;
                doctorfees = Convert.ToInt32(txtdfees.Text);

                Doctor objdoctor = new Doctor
                {
                    DoctorName = doctorname,
                    Department = department,
                    DoctorFees = doctorfees

                };

                doctoradded = HMSBL.AddDoctorBL(objdoctor);
                if (doctoradded == true)
                {
                    MessageBox.Show("Doctor Record added Sucessfully.");
                }
                else
                {
                    MessageBox.Show("Doctor Record Couldn't be Added.");
                }


            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Backdoctor_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
