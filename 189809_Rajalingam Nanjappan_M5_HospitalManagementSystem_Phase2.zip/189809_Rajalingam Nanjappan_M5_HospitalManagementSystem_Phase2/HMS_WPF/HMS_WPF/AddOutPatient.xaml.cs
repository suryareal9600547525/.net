﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for AddOutPatient.xaml
    /// </summary>
    public partial class AddOutPatient : Window
    {
        public AddOutPatient()
        {
            InitializeComponent();
        }

        private void Addoutpatient_Click(object sender, RoutedEventArgs e)
        {
            AddOutpatient();
        }


        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cboutpatientid.ItemsSource = patientList.DefaultView;

                cboutpatientid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cboutpatientid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }



        private void AddOutpatient()
        {

            try
            {

                int patientid;
                int doctorid;
                 DateTime treatmentdate;
                     int labid;

                bool Outpatientadded;

                patientid = Convert.ToInt32(cboutpatientid.SelectedValue);
                doctorid = Convert.ToInt32(cbdid.SelectedValue);
               
                treatmentdate = Convert.ToDateTime(txttreatmentdate.ToString());
               
                labid = Convert.ToInt32(txtlabid.Text);

                OutPatient objOutpatient = new OutPatient
                {
                    PatientID = patientid,
                    DoctorID = doctorid,
                    TreatmentDate = treatmentdate,
                    LabID = labid
                };

                Outpatientadded = HMSBL.AddOutPatientBL(objOutpatient);
                if (Outpatientadded == true)
                {
                    MessageBox.Show("OutPatient Record added Sucessfully.");
                }
                else
                {
                    MessageBox.Show("OutPatient Record Couldn't be Added.");
                }


            }

            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctors();
            GetPatients();
        }

        private void BackOutpatient_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
