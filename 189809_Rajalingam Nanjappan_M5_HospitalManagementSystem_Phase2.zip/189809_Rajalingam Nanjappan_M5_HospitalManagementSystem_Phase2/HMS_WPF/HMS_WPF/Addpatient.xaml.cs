﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for Addpatient.xaml
    /// </summary>
    public partial class Addpatient : Window
    {
        public Addpatient()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            AddPatient();
        }

        private void AddPatient()
        {
            try
            {
                string patientname;
                int age;
                string gender;
                string address;
                string phoneno;
                string weight;
                string disease;
                int doctorid;

                bool patientadded;

                patientname = txtname.Text;
                age = Convert.ToInt32(txtage.Text);
                if(rdmale.IsChecked == true)
                {
                    gender = rdmale.Content.ToString();
                }
                else
                {
                    gender = rdfemale.Content.ToString();
                }
                address = txtaddress.Text;
                phoneno = txtphoneno.Text;
                weight = txtweight.Text;
                disease = txtdisease.Text;
                doctorid = Convert.ToInt32(txtdocotorid.Text);

                Patient objPatient = new Patient
                {
                    Name = patientname,
                    Gender = gender,
                    Age = age,
                    Address = address,
                    PhoneNo = phoneno,
                    Weight = weight,
                    Disease = disease,
                    DoctorID = doctorid

                };

                patientadded = HMSBL.AddPatientBL(objPatient);
                if(patientadded == true)
                {
                    MessageBox.Show("Patient Record added Sucessfully.");
                }
                else
                {
                    MessageBox.Show("Patient Record Couldn't be Added.");
                }

            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message); 
            }
        }

        private void Backpatient_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
