﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for BillData.xaml
    /// </summary>
    public partial class BillReport : Window
    {
        public BillReport()
        {
            InitializeComponent();
        }


        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cmbPatientId.ItemsSource = patientList.DefaultView;

                cmbPatientId.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cmbPatientId.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void GetBillPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cmbBillPatientid.ItemsSource = patientList.DefaultView;

                cmbBillPatientid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cmbBillPatientid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }



        private void GetInPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cmbInpatientId.ItemsSource = patientList.DefaultView;

                cmbInpatientId.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cmbInpatientId.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cddoctorid.ItemsSource = doctorsList.DefaultView;

                cddoctorid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cddoctorid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void GetLabId()
        {
            try
            {
                DataTable labIdList = HMSBL.GetLabBL();
                cmbLabId.ItemsSource = labIdList.DefaultView;
                cmbLabId.DisplayMemberPath = labIdList.Columns[0].ColumnName;
                cmbLabId.SelectedValuePath = labIdList.Columns[0].ColumnName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbPatientId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int patientId = Convert.ToInt32(cmbPatientId.SelectedValue);
            Patient patientSearch;
            patientSearch = HMSBL.SearchPatientBL(patientId);
            if (patientSearch != null)
            {
                txtPatientName.Text = patientSearch.Name;

                if (chkoutpatient.IsChecked == true)
                {
                    lblRoomType.Visibility = Visibility.Hidden;
                    cmbRoomType.Visibility = Visibility.Hidden;
                    lblRoomCharge.Visibility = Visibility.Hidden;
                    txtRoomCharge.Visibility = Visibility.Hidden;
                    lblOperationCharge.Visibility = Visibility.Hidden;
                    txtOperationCharge.Visibility = Visibility.Hidden;
                    lblTotalDays.Visibility = Visibility.Hidden;
                    txtTotalDays.Visibility = Visibility.Hidden;
                    lblInpatientId.Visibility = Visibility.Hidden;
                    cmbInpatientId.Visibility = Visibility.Hidden;
                    lblAdmDate.Visibility = Visibility.Hidden;
                    dpAdmDate.Visibility = Visibility.Hidden;
                    lblDisDate.Visibility = Visibility.Hidden;
                    dpDiscDate.Visibility = Visibility.Hidden;
                }
                else
                {
                    lblRoomType.Visibility = Visibility.Visible;
                    cmbRoomType.Visibility = Visibility.Visible;
                    lblRoomCharge.Visibility = Visibility.Visible;
                    txtRoomCharge.Visibility = Visibility.Visible;
                    lblOperationCharge.Visibility = Visibility.Visible;
                    txtOperationCharge.Visibility = Visibility.Visible;
                    lblTotalDays.Visibility = Visibility.Visible;
                    txtTotalDays.Visibility = Visibility.Visible;
                    lblInpatientId.Visibility = Visibility.Visible;
                    cmbInpatientId.Visibility = Visibility.Visible;
                    lblAdmDate.Visibility = Visibility.Visible;
                    dpAdmDate.Visibility = Visibility.Visible;
                    lblDisDate.Visibility = Visibility.Visible;
                    dpDiscDate.Visibility = Visibility.Visible;
                }
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            GetLabId();
            GetDoctors();
            GetPatients();
            GetInPatients();
            GetBillPatients();
        }

        private void CmbRoomType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string roomType = ((ComboBoxItem)cmbRoomType.SelectedValue).Content.ToString();
            if (roomType == "AC")
            {
                Convert.ToInt32(txtRoomCharge.Text = "2000");
            }
            else if (roomType == "Non-AC")
            {
                Convert.ToInt32(txtRoomCharge.Text = "1200");
            }
            else if (roomType == "ICU")
            {
                Convert.ToInt32(txtRoomCharge.Text = "5000");
            }
            else if (roomType == "Ward")
            {
                Convert.ToInt32(txtRoomCharge.Text = "800");
            }
        }

       

        private void AddBill()
        {
            bool billAdded;
            try
            {

                if (chkoutpatient.IsChecked == true)
                {
                    int PatientId;
                    string patientname;

                    int DoctorId;
                    string DoctorName;
                    int DoctorFees;
                    string RoomType;
                    int RoomCharge;
                    int OperationCharge;
                    int MedicineFees;
                    int LabId;
                    int TotalDays;
                    int LabFees;
                    int TotalAmount;




                    PatientId = Convert.ToInt32(cmbPatientId.SelectedValue);
                    patientname = txtPatientName.Text;
                    DoctorId = Convert.ToInt32(cddoctorid.SelectedValue);
                    DoctorName = txtDoctorName.Text;
                    DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                    RoomType = ((ComboBoxItem)cmbRoomType.SelectedValue).Content.ToString();
                    RoomCharge = Convert.ToInt32(txtRoomCharge.Text);
                    OperationCharge = Convert.ToInt32(txtOperationCharge.Text);
                    MedicineFees = Convert.ToInt32(txtMedicineFees.Text);
                    LabId = Convert.ToInt32(cmbLabId.SelectedValue);
                    TotalDays = Convert.ToInt32(txtTotalDays.Text);
                    LabFees = Convert.ToInt32(txtLabFees.Text);
                    TotalAmount = Convert.ToInt32(txtTotalAmount.Text);

                    HMSBL objBillBL = new HMSBL();

                    BillData objBill = new BillData { PatientID = PatientId, PatientName = patientname, DoctorID = DoctorId, DoctorName = DoctorName, DoctorFees = DoctorFees, RoomCharge = RoomCharge, OperationCharges = OperationCharge, MedicineFees = MedicineFees, LabID = LabId, TotalDays = TotalDays, LabFees = LabFees, TotalAmount = TotalAmount };
                    billAdded = objBillBL.AddBillBL(objBill);
                    if (billAdded == true)
                    {
                        MessageBox.Show("Bill record added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Bill record couldn't be added");
                    }

                }

                else if (chkoutpatient.IsChecked == false)
                {
                    int PatientId;
                    string PatientName;

                    int DoctorId;
                    string DoctorName;
                    int DoctorFees;
                    int MedicineFees;
                    int LabId;
                    int LabFees;
                    int TotalAmount;




                    PatientId = Convert.ToInt32(cmbPatientId.SelectedValue);
                    PatientName = txtPatientName.Text;
                    DoctorId = Convert.ToInt32(cddoctorid.SelectedValue);
                    DoctorName = txtDoctorName.Text;
                    DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                    MedicineFees = Convert.ToInt32(txtMedicineFees.Text);
                    LabId = Convert.ToInt32(cmbLabId.SelectedValue);
                    LabFees = Convert.ToInt32(txtLabFees.Text);
                    TotalAmount = Convert.ToInt32(txtTotalAmount.Text);



                    HMSBL objBillBL = new HMSBL();

                    BillData objBill = new BillData { PatientID = PatientId, PatientName = PatientName, DoctorID = DoctorId, DoctorName = DoctorName, DoctorFees = DoctorFees, MedicineFees = MedicineFees, LabID = LabId, LabFees = LabFees, TotalAmount = TotalAmount };
                    billAdded = objBillBL.AddBillBL2(objBill);



                    if (billAdded == true)
                    {
                        MessageBox.Show("Bill record added successfully");
                    }
                    else
                    {
                        MessageBox.Show("Bill record couldn't be added");
                    }
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CmbInpatientId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int inpatientId = Convert.ToInt32(cmbInpatientId.SelectedValue);
                InPatient inpatientSearch;
                inpatientSearch = HMSBL.SearchInPatientBL(inpatientId);
                if (inpatientSearch != null)
                {
                    dpAdmDate.Text = inpatientSearch.AdmissionDate.ToShortDateString();
                    dpDiscDate.Text = inpatientSearch.DisChargeDate.ToShortDateString();
                    DateTime admDate = Convert.ToDateTime(dpAdmDate.Text);
                    DateTime disDate = Convert.ToDateTime(dpDiscDate.Text);
                    TimeSpan days = disDate.Subtract(admDate);
                    txtTotalDays.Text = Convert.ToString(days.TotalDays);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void CmbLabId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int labId = Convert.ToInt32(cmbLabId.SelectedValue);
               
               Lab labsearch = HMSBL.SearchLab(labId);
                if (labsearch != null)
                {
                    txtLabFees.Text = Convert.ToString(labsearch.LabFees);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddBill();
        }

        private void TxtMedicineFees_TextChanged(object sender, TextChangedEventArgs e)
        {

            if (chkoutpatient.IsChecked == true)
            {
                try
                {
                    if (txtMedicineFees.Text == string.Empty)
                    {
                        int DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                        int RoomCharge = Convert.ToInt32(txtRoomCharge.Text);
                        int OperationCharge = Convert.ToInt32(txtOperationCharge.Text);
                        int MedicineFees = 0;
                        int TotalDays = Convert.ToInt32(txtTotalDays.Text);
                        int LabFees = Convert.ToInt32(txtLabFees.Text);
                        int TotalAmount1 = RoomCharge * TotalDays + DoctorFees + OperationCharge + MedicineFees + LabFees;
                        int TotalAmount = Convert.ToInt32(TotalAmount1);
                        txtTotalAmount.Text = TotalAmount.ToString();
                    }
                    else if (Convert.ToInt32(txtMedicineFees.Text) > 0)
                    {
                        int DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                        int RoomCharge = Convert.ToInt32(txtRoomCharge.Text);
                        int OperationCharge = Convert.ToInt32(txtOperationCharge.Text);
                        int MedicineFees = Convert.ToInt32(txtMedicineFees.Text);
                        int TotalDays = Convert.ToInt32(txtTotalDays.Text);
                        int LabFees = Convert.ToInt32(txtLabFees.Text);
                        int TotalAmount1 = RoomCharge * TotalDays + DoctorFees + OperationCharge + MedicineFees + LabFees;
                        int TotalAmount = Convert.ToInt32(TotalAmount1);
                        txtTotalAmount.Text = TotalAmount.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                try
                {
                    if (txtMedicineFees.Text == string.Empty)
                    {
                        int MedicineFees = 0;
                        int DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                        int LabFees = Convert.ToInt32(txtLabFees.Text);
                        int TotalAmount1 = MedicineFees + DoctorFees + LabFees;
                        int TotalAmount = Convert.ToInt32(TotalAmount1);
                        txtTotalAmount.Text = TotalAmount.ToString();
                    }
                    else if (Convert.ToInt32(txtMedicineFees.Text) > 0)
                    {
                        int MedicineFees = Convert.ToInt32(txtMedicineFees.Text);
                        int DoctorFees = Convert.ToInt32(txtDoctorFees.Text);
                        int LabFees = Convert.ToInt32(txtLabFees.Text);
                        int TotalAmount1 = MedicineFees + DoctorFees + LabFees;
                        int TotalAmount = Convert.ToInt32(TotalAmount1);
                        txtTotalAmount.Text = TotalAmount.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }



        private void Cddoctorid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            int doctorid = Convert.ToInt32(cddoctorid.SelectedValue);
            Doctor doctorSearch;
            doctorSearch = HMSBL.SearchDoctorBL(doctorid);
            if (doctorSearch != null)
            {
                txtDoctorFees.Text = doctorSearch.DoctorFees.ToString();
                txtDoctorName.Text = doctorSearch.DoctorName;
            }
        }

        private void CmbBillPatientid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int patientId = 0;
                

                if (chkoutpatient.IsChecked == true)
                {
                    BillData objBill = HMSBL.SearchBillBL(patientId);
                    if (objBill != null)
                    {
                        dgView.Visibility = Visibility.Visible;
                        dgView1.Visibility = Visibility.Hidden;
                        List<BillData> reportList = new List<BillData>();
                        reportList.Add(objBill);
                        dgView.ItemsSource = reportList;
                    }
                    else
                    {
                        MessageBox.Show("No records available");
                    }
                }
                else if (chkoutpatient.IsChecked == false)
                {
                    BillData objBill = HMSBL.SearchBill2BL(patientId);
                    if (objBill != null)
                    {
                        dgView1.Visibility = Visibility.Visible;
                        dgView.Visibility = Visibility.Hidden;
                        List<BillData> reportList = new List<BillData>();
                        reportList.Add(objBill);
                        dgView1.ItemsSource = reportList;
                    }
                    else
                    {
                        MessageBox.Show("No records available");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


    }
}

       
           
