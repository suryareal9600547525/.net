﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for LabReport.xaml
    /// </summary>
    public partial class LabReport : Window
    {
        public LabReport()
        {
            InitializeComponent();
        }

        private void AddLabReport_Click(object sender, RoutedEventArgs e)
        {
            Addlabreport();
        }

        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void Addlabreport()
        {

            try
            {
                int labid;
                int patientid;
                int doctorid;
                DateTime testdate;
                string testtype;
                int labfees;
                

                bool labreportadded;

                labid = Convert.ToInt32(txtlabid.Text);
                patientid = Convert.ToInt32(txtpatientid.Text);
                doctorid = Convert.ToInt32(cbdid.SelectedValue);

                testdate = Convert.ToDateTime(txttestdate.ToString());
                testtype = txttesttype.Text;
                labfees = Convert.ToInt32(txtlabfees.Text);



                Lab objlabreport = new Lab
                {
                    LabID = labid,
                    PatientID = patientid,
                    DoctorID = doctorid,
                    TestDate = testdate,
                    TestType = testtype,
                    LabFees = labfees
                    
                    
                    
                };

                labreportadded = HMSBL.AddlabReportBL(objlabreport);
                if (labreportadded == true)
                {
                    MessageBox.Show("Lab Record added Sucessfully.");
                }
                else
                {
                    MessageBox.Show("Lab Record Couldn't be Added.");
                }


            }

            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctors();
        }
    }
}
