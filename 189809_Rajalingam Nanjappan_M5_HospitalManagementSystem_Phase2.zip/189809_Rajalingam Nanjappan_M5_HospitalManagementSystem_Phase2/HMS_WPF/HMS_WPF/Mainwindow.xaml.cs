﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        

       
        

        private void AddPatient_Click(object sender, RoutedEventArgs e)
        {

            var form = new Addpatient();
            form.Show();
            
        }

        private void AddInPatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new AddInPatient();
            form.Show();
        }

        private void AddOutPatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new AddOutPatient();
            form.Show();
        }

        private void AddDoctor_Click(object sender, RoutedEventArgs e)
        {
            var form = new AddDoctor();
            form.Show();
        }

        private void Addlab_Click(object sender, RoutedEventArgs e)
        {
            var form = new LabReport();
            form.Show();
        }

        private void AddBillData_Click(object sender, RoutedEventArgs e)
        {
            var form = new BillReport();
            form.Show();
        }

        private void ViewDetails_Click(object sender, RoutedEventArgs e)
        {
            var form = new GetDetails();
            form.Show();
        }

        private void UpdateDetails_Click(object sender, RoutedEventArgs e)
        {
            var form = new Update();
            form.Show();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            var form = new Search();
            form.Show();
        }
    }
}
