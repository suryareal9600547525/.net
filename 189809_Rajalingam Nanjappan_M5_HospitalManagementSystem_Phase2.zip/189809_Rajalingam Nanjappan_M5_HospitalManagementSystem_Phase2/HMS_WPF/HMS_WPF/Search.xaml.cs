﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        HMSBL objpl = new HMSBL();
        public Search()
        {
            InitializeComponent();
        }

        private void Searchpatient_Click(object sender, RoutedEventArgs e)
        {
            SearchPatientById();
        }



        private void SearchPatientById()
        {
            Patient objSearch = new Patient();
            try
            {
                int patientId;
                Patient objPatient;
                patientId = Convert.ToInt32(txtpatientid.Text);

                objPatient = HMSBL.SearchPatientBL(patientId);
                if (objPatient != null)
                {
                    txtname.Text = objPatient.Name;
                    txtage.Text = Convert.ToString(objPatient.Age); 
                    txtgender.Text = objPatient.Gender;
                    txtaddress.Text = objPatient.Address;
                    txtphoneno.Text = objPatient.PhoneNo;
                    txtweight.Text = Convert.ToString(objPatient.Weight);
                    txtdisease.Text = objPatient.Disease; 
                    txtdocotorid.Text = Convert.ToString(objPatient.DoctorID);
                }
                else
                {
                    MessageBox.Show("No Patient Details Available");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Searchinpatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new SearchPatient();
            form.Show();
        }

        private void Searchoutpatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new SearchOutPatient();
            form.Show();
        }
    }
}
