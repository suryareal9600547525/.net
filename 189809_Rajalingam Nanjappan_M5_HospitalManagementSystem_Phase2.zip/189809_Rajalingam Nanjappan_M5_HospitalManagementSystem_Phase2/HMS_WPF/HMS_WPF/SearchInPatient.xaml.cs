﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for SearchPatient.xaml
    /// </summary>
    public partial class SearchPatient : Window
    {
        public SearchPatient()
        {
            InitializeComponent();
        }

        private void Searchpatient_Click(object sender, RoutedEventArgs e)
        {
            SearchInPatientById();
        }


        private void SearchInPatientById()
        {
            InPatient objSearch = new InPatient();
            try
            {
                int patientId;
                InPatient objPatient;
                patientId = Convert.ToInt32(txtpatientid.Text);

                objPatient = HMSBL.SearchInPatientBL(patientId);
                if (objPatient != null)
                {
                    txtdocotorid.Text = Convert.ToString(objPatient.DoctorID);
                    txtroomno.Text = Convert.ToString(objPatient.RoomNo);
                    txtadmissiondate.Text = Convert.ToString(objPatient.AdmissionDate.ToShortDateString());
                    txtdischargedate.Text = Convert.ToString(objPatient.DisChargeDate.ToShortDateString());
                    txtlabid.Text = Convert.ToString(objPatient.LabID);
                }
                else
                {
                    MessageBox.Show("No Patient Details Available");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

       
    }
}
