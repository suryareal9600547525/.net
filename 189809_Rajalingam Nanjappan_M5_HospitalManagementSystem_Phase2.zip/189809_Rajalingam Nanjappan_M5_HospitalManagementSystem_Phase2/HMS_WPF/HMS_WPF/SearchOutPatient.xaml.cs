﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for SearchOutPatient.xaml
    /// </summary>
    public partial class SearchOutPatient : Window
    {
        public SearchOutPatient()
        {
            InitializeComponent();
        }



        private void SearchOutPatientById()
        {
            OutPatient objSearch = new OutPatient();
            try
            {
                int patientId;
                OutPatient objPatient;
                patientId = Convert.ToInt32(txtpatientid.Text);

                objPatient = HMSBL.SearchOutPatientBL(patientId);
                if (objPatient != null)
                {
                    txttreatmentdate.Text = Convert.ToString(objPatient.TreatmentDate.ToShortDateString());
                    txtdocotorid.Text = Convert.ToString(objPatient.DoctorID);
                    txtlabid.Text = Convert.ToString(objPatient.LabID);
                }
                else
                {
                    MessageBox.Show("No Patient Details Available");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Searchpatient_Click(object sender, RoutedEventArgs e)
        {
            SearchOutPatientById();
        }
    }
}
