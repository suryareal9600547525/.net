﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;
namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        public Update()
        {
            InitializeComponent();
        }
        private void UpdatePatient_Click(object sender, RoutedEventArgs e)
        {
            UpdatePatients();
            
        }


        private void Updateinpatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new UpdateInPatient();
            form.Show();
        }

        private void Updateoutpatient_Click(object sender, RoutedEventArgs e)
        {
            var form = new UpdateOutPatient();
            form.Show();
        }

        private void UpdateDoctor_Click(object sender, RoutedEventArgs e)
        {
            var form = new UpdateDoctor();
            form.Show();
        }


        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cbdid.ItemsSource = patientList.DefaultView;

                cbdid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private   void UpdatePatients()
        {
            try
            {
                int patientid;
                string patientname;
                int age;
                string address;
                string phoneno;
                string weight;
                string disease;
                int doctorid;

                bool patientupdated;

                patientid = Convert.ToInt32(cbdid.Text);
                patientname = txtname.Text;
                age = Convert.ToInt32(txtage.Text);
                
                address = txtaddress.Text;
                phoneno = txtphoneno.Text;
                weight = txtweight.Text;
                disease = txtudisease.Text;
                doctorid = Convert.ToInt32(txtudocotorid.Text);

                Patient objPatient = new Patient
                {
                    PatientID = patientid,
                    Name = patientname, 
                    Age = age,
                    Address = address,
                    PhoneNo = phoneno,
                    Weight = weight,
                    Disease = disease,
                    DoctorID = doctorid

                };

                patientupdated = HMSBL.UpdatePatientBL(objPatient);
                if (patientupdated == true)
                {
                    MessageBox.Show("Patient Record Updated Sucessfully.");
                }
                else
                {
                    MessageBox.Show("Patient Record Couldn't be Updated.");
                }

            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetPatients();
           
        }

        private   void Backpage_Click(object sender, RoutedEventArgs e)
        {
            this.Close();



        }
    }
}
