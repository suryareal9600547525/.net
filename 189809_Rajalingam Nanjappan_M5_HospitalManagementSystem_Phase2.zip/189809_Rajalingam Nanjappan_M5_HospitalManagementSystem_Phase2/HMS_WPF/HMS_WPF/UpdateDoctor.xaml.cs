﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for UpdateDoctor.xaml
    /// </summary>
    public partial class UpdateDoctor : Window
    {
        public UpdateDoctor()
        {
            InitializeComponent();
        }

        private void Updatedoctor_Click(object sender, RoutedEventArgs e)
        {
            UpdateDoctors();
        }

        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void UpdateDoctors()
        {
            try
            {
               
                int doctorid;
                string doctorname;
                string department;
                int doctorfees;
                
                

                bool Doctorupdated;

                doctorid = Convert.ToInt32(cbdid.Text);
                doctorname = txtdname.Text;
                department = txtddept.Text;
                doctorfees = Convert.ToInt32(txtdfees.Text);
                

                Doctor objDoctor = new Doctor
                {
                   
                    DoctorID = doctorid,
                    DoctorName = doctorname,
                    Department = department,
                    DoctorFees = doctorfees
                    

                };

                Doctorupdated = HMSBL.UpdateDoctorBL(objDoctor);
                if (Doctorupdated == true)
                {
                    MessageBox.Show("Doctor Record Updated Sucessfully.");
                }
                else
                {
                    MessageBox.Show("Doctor Record Couldn't be Updated.");
                }

            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Backpage_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctors();
        }
    }
}
