﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for UpdateInPatient.xaml
    /// </summary>
    public partial class UpdateInPatient : Window
    {
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetPatients();
            GetDoctors();
           

        }
        public UpdateInPatient()
        {
            InitializeComponent();
        }

        private void Updateinpatient_Click(object sender, RoutedEventArgs e)
        {
            UpdateInPatients();
        }


        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cbpid.ItemsSource = patientList.DefaultView;

                cbpid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cbpid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }


        private void UpdateInPatients()
        {
            try
            {
                int patientid;
                int doctorid;
                int roomno;
                DateTime admissiondate;
                DateTime dischargedate;
                int labid;

                bool Inpatientupdated;

                patientid = Convert.ToInt32(cbpid.Text);
                doctorid = Convert.ToInt32(cbdid.Text);
                roomno = Convert.ToInt32(txtroomno.Text);
                admissiondate = Convert.ToDateTime(txtadmissiondate.ToString());
                dischargedate = Convert.ToDateTime(txtdischargedate.ToString());
                labid = Convert.ToInt32(txtlabid.Text);

                InPatient objPatient = new InPatient
                {
                    PatientID = patientid,
                    DoctorID = doctorid,
                    RoomNo = roomno,
                    AdmissionDate = admissiondate,
                    DisChargeDate = dischargedate,
                    LabID = labid
 
                };

                Inpatientupdated = HMSBL.UpdateInPatientBL(objPatient);
                if (Inpatientupdated == true)
                {
                    MessageBox.Show("InPatient Record Updated Sucessfully.");
                }
                else
                {
                    MessageBox.Show("InPatient Record Couldn't be Updated.");
                }

            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Backpage_Click(object sender, RoutedEventArgs e)
        {
            
            this.Close();
        }
    }
}
