﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for UpdateOutPatient.xaml
    /// </summary>
    public partial class UpdateOutPatient : Window
    {
        public UpdateOutPatient()
        {
            InitializeComponent();
        }

        private void Backoutpage_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void GetDoctors()

        {

            try

            {

                DataTable doctorsList = HMSBL.GetDoctorsBL();

                cbdid.ItemsSource = doctorsList.DefaultView;

                cbdid.DisplayMemberPath = doctorsList.Columns[0].ColumnName;

                cbdid.SelectedValuePath = doctorsList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cbpid.ItemsSource = patientList.DefaultView;

                cbpid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cbpid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void Updateoutpatient_Click(object sender, RoutedEventArgs e)
        {
            UpdateOutPatients();
        }

        private void UpdateOutPatients()
        {
            try
            {
                int patientid;
                DateTime treatmentdate;
                int doctorid;
                int labid;

                bool Outpatientupdated;

                patientid = Convert.ToInt32(cbpid.Text);
                doctorid = Convert.ToInt32(cbdid.Text);
                treatmentdate = Convert.ToDateTime(txttreatmmentdate.ToString());
                labid = Convert.ToInt32(txtlabid.Text);

                OutPatient objPatient = new OutPatient
                {
                    PatientID = patientid,
                    TreatmentDate = treatmentdate,
                    DoctorID = doctorid, 
                    LabID = labid

                };

                Outpatientupdated = HMSBL.UpdateOutPatientBL(objPatient);
                if (Outpatientupdated == true)
                {
                    MessageBox.Show("InPatient Record Updated Sucessfully.");
                }
                else
                {
                    MessageBox.Show("InPatient Record Couldn't be Updated.");
                }

            }
            catch (HMSExceptions ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDoctors();
            GetPatients();
        }
    }
}
