﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for ViewInPatient.xaml
    /// </summary>
    public partial class ViewInPatient : Window
    {
        public ViewInPatient()
        {
            InitializeComponent();
        }


        private void ListInPatient()
        {
            try
            {
                List<InPatient> objPatient = HMSBL.SelectInPatientBL();
                if (objPatient != null)
                {
                    dgView.ItemsSource = objPatient;
                }
                else
                {
                    MessageBox.Show("No records available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ListInPatient();
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
