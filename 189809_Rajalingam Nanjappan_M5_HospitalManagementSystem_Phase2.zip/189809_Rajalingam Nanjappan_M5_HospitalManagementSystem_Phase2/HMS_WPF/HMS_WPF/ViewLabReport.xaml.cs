﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HMS_BusinessLayer;
using HMS_Entities;
using HMS_Exceptions;
using System.Data;

namespace HMS_WPF
{
    /// <summary>
    /// Interaction logic for ViewLabReport.xaml
    /// </summary>
    public partial class ViewLabReport : Window
    {
        public ViewLabReport()
        {
            InitializeComponent();
        }


        private void GetPatients()

        {

            try

            {

                DataTable patientList = HMSBL.GetPatientBL();

                cmbPid.ItemsSource = patientList.DefaultView;

                cmbPid.DisplayMemberPath = patientList.Columns[0].ColumnName;

                cmbPid.SelectedValuePath = patientList.Columns[0].ColumnName;

            }

            catch (HMSExceptions ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void CmbPid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int patientId;
                patientId = Convert.ToInt32(cmbPid.SelectedValue.ToString());
                Lab objLab = HMSBL.SearchLabBL(patientId);
                if (objLab != null)
                {
                    List<Lab> reportList = new List<Lab>();
                    reportList.Add(objLab);
                    dgView.ItemsSource = reportList.ToList();
                }
                else
                {
                    MessageBox.Show("No records available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Previousbtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetPatients();
        }
    }
}
