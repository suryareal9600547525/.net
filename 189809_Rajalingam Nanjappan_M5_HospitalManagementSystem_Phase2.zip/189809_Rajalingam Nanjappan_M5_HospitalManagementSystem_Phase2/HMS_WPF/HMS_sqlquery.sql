﻿create schema rj_189809

create table rj_189809.Patient
(
PatientID int primary key identity(1909001,1),
Name varchar(40),
Age int,
Gender varchar(6),
Address varchar(100),
PhoneNo char(10),
Weight int,
Disease varchar(50),
DoctorID int,
foreign key(DoctorID) references rj_189809.Doctor(DoctorID)
)

create table rj_189809.Doctor(
DoctorID int primary key identity(1001,1),
DoctorName varchar(30),
Department varchar(20)
)

create table rj_189809.Lab
(LabID int primary key,
PatientID int,
DoctorID int,
TestDate date,
TestType varchar(30),
foreign key(PatientID) references rj_189809.Patient(PatientID),
foreign key(DoctorID) references rj_189809.Doctor(DoctorID)
)

alter table rj_189809.InPatient
(PatientID int,
RoomNo int primary key,
DoctorID int,
AdmissionDate date,
DischargeDate date,
LabID int,
foreign key(PatientID) references rj_189809.Patient(PatientID),
foreign key(DoctorID) references rj_189809.Doctor(DoctorID),
foreign key(LabID) references rj_189809.Lab(LabID)
)

create table rj_189809.OutPatient
(PatientID int,
TreatmentDate date,
DoctorID int,
LabID int,
foreign key(PatientID) references rj_189809.Patient(PatientID),
foreign key(DoctorID) references rj_189809.Doctor(DoctorID),
foreign key(LabID) references rj_189809.Lab(LabID)
)

create table rj_189809.BillData
(BillNo int primary key identity(10001,1),
PatientID int,
DoctorID int,
DoctorFees int,
RoomNo int,
RoomCharge int,
OperationCharges int,
MedicineFees int,
TotalDays int,
LabFees int,
TotalAmount int,
foreign key(PatientID) references rj_189809.Patient(PatientID),
foreign key(DoctorID) references rj_189809.Doctor(DoctorID),
foreign key(RoomNo) references rj_189809.InPatient(RoomNo)
)

select * from rj_189809.BillData