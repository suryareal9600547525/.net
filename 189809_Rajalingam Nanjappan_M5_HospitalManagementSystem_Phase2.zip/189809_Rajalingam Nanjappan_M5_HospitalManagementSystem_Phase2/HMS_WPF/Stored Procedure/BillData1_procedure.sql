﻿CREATE PROCEDURE [rj_189809].[SPBillData]
	@BillNo int,
	@PatientId int,
	@DoctorId int,
	@DoctorFees int,
	@RoomType varchar(20),
	@RoomCharge int,
	@OperationCharge int,
	@MedicineFees int,
	@TotalDays int,
	@LabFees int,
	@TotalAmount int,
	@DoctorName varchar(40),
	@LabId int,
	@PatientName varchar(40)
AS
	Insert into rj_189809.BillData Values(@BillNo,@PatientId,@DoctorId,@DoctorFees,@RoomType,@RoomCharge,@OperationCharge,@MedicineFees,@TotalDays,@LabFees,@TotalAmount,@DoctorName,@LabId,@PatientName)

RETURN 0
