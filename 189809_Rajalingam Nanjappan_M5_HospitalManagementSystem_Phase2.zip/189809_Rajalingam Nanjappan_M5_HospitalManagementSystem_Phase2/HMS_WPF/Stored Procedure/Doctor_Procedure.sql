﻿CREATE PROCEDURE [rj_189809].[SPDoctor]
	@doctorname varchar(30),
	@dept varchar(20),
	@doctorfees int
AS
	Insert into rj_189809.Doctor values(@doctorname,@dept,@doctorfees)
RETURN 0
