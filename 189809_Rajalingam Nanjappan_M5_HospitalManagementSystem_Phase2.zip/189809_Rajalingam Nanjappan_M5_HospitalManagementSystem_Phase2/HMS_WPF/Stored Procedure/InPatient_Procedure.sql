﻿CREATE PROCEDURE [rj_189809].[SPInPatient]
	@patientid int,
	@roomno int,
	@doctorid int,
	@admissiondate date,
	@dischargedate date,
	@labid int
	
AS
	Insert into rj_189809.InPatient values(@patientid,@roomno,@doctorid,@admissiondate,@dischargedate,@labid)
RETURN 0