﻿CREATE PROCEDURE [rj_189809].[SPLab]
	@labid int, 
	@patientid int,
	@doctorid int,
	@testdate date,
	@testtype varchar(20),
	@labfees int
	
AS
	Insert into rj_189809.Lab values(@labid,@patientid,@doctorid,@testdate,@testtype,@labfees)
RETURN 0
