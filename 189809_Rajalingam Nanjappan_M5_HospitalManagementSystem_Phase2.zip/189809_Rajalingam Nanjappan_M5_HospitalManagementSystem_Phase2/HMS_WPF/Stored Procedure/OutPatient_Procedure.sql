﻿CREATE PROCEDURE [rj_189809].[SPOutPatient]
	@patientid int,
	@treatmentdate date,
	@doctorid int,
	@labid int
	
AS
	Insert into rj_189809.OutPatient values(@patientid,@treatmentdate,@doctorid,@labid)
RETURN 0
