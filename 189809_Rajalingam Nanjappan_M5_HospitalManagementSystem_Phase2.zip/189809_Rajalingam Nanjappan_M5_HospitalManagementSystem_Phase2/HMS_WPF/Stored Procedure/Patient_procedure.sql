﻿CREATE PROCEDURE [rj_189809].[SPPatient]
	@name varchar(30),
	@age int,
	@gender varchar(10),
	@address varchar(100),
	@phoneno int,
	@weight varchar(20),
	@disease varchar(20),
	@doctorid int
AS
	Insert into rj_189809.Patient Values(@name,@age,@gender,@address,@phoneno,@weight,@disease,@doctorid)
RETURN 0








