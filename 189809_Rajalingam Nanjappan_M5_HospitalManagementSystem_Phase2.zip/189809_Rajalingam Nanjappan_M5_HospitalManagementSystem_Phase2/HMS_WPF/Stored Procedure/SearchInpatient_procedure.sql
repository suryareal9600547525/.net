﻿CREATE PROCEDURE [rj_189809].[SPSInpatient]
	@patientid int
AS
	select * from rj_189809.InPatient where PatientID=@patientid
RETURN 0
