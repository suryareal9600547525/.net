﻿CREATE PROCEDURE [rj_189809].[SPSOutpatient]
	@patientid int
AS
	select * from rj_189809.OutPatient where PatientID=@patientid
RETURN 0
