﻿CREATE PROCEDURE [rj_189809].[SPSPatient]
	@patientid int

AS
	select * from rj_189809.Patient where PatientID=@patientid
RETURN 0
