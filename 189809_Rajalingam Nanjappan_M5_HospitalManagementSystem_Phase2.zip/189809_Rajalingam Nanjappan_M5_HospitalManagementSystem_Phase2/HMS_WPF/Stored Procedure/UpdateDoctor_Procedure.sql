﻿CREATE PROCEDURE [rj_189809].[SPUDoctor]
	@doctorid int,
	@doctorname varchar(30),
	@department varchar(20),
	@doctorfees int
AS
	update rj_189809.Doctor set DoctorName=@doctorname,Department=@department,DoctorFees=@doctorfees where DoctorID=@doctorid
RETURN 0
