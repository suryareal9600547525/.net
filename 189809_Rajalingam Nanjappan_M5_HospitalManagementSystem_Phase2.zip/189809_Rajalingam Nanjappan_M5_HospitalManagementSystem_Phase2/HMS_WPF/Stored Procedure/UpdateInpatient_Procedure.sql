﻿CREATE PROCEDURE [rj_189809].[SPUInpatient]
	@patientid int,
	@doctorid int,
	@roomno int,
	@admissiondate date,
	@dischargedate date,
	@labid int
AS
	update rj_189809.InPatient set PatientID=@patientid,DoctorID=@doctorid,RoomNo=@roomno,AdmissionDate = @admissiondate,DischargeDate=@dischargedate,LabID=@labid where PatientID=@patientid
RETURN 0