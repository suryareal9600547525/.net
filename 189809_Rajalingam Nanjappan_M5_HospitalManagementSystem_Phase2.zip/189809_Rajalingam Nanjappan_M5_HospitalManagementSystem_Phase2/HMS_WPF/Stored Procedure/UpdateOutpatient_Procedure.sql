﻿CREATE PROCEDURE [rj_189809].[SPUOutpatient]
	@patientid int,
	@treatmentdate date,
	@doctorid int,
	@labid int
AS
	update rj_189809.OutPatient set PatientID=@patientid,TreatmentDate=@treatmentdate,DoctorID=@doctorid,LabID=@labid where PatientID=@patientid
RETURN 0
