﻿CREATE PROCEDURE [rj_189809].[SPUpatient]
	@patientid int,
	@name varchar(30),
	@age int,
	@address varchar(50),
	@phoneno char(10),
	@weight varchar(20),
	@disease varchar(30),
	@doctorid int
AS
	update rj_189809.Patient set Name=@name,Age=@age,Address=@address,PhoneNo = @phoneno,Weight=@weight,Disease = @disease,DoctorID=@doctorid where PatientID=@patientid
RETURN 0
