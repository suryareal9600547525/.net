﻿CREATE PROCEDURE [rj_189809].[SPSDoctor]
	@DoctorId int
AS
	select DoctorId, DoctorName, DoctorFees from rj_189809.Doctor where DoctorId=@DoctorId
RETURN 0
