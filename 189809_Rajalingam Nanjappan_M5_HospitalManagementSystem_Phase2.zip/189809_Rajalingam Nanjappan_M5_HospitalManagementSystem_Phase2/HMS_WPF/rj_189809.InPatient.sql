﻿CREATE TABLE [rj_189809].[InPatient] (
    [PatientID]     INT  NULL,
    [RoomNo]        INT  NOT NULL,
    [DoctorID]      INT  NULL,
    [AdmissionDate] DATE NULL,
    [DischargeDate] DATE NULL,
    [LabID]         INT  NULL,
    PRIMARY KEY CLUSTERED ([RoomNo] ASC),
    FOREIGN KEY ([LabID]) REFERENCES [rj_189809].[Lab] ([LabID]),
    FOREIGN KEY ([PatientID]) REFERENCES [rj_189809].[Patient] ([PatientID]),
    FOREIGN KEY ([DoctorID]) REFERENCES [rj_189809].[Doctor] ([DoctorID])
);

