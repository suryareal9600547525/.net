﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS_MVC.Controllers
{
    public class BillController : Controller
    {
        // GET: Bill

        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult IndexBillHMS()
        {
            return View(context.BillDatas.ToList());
        }
    }
}