﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS_MVC.Controllers
{
    public class DoctorController : Controller
    {
        // GET: Doctor
        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();

        public ActionResult Index()
        {
            return View(context.Doctors.ToList());
        }

        public ActionResult ListDoctor()
        {
            return View(context.Doctors.ToList());
        }

        public ActionResult InsertDoctor()
        {
            return View();
        }

        [HttpPost]
        public ActionResult InsertDoctor(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                context.Doctors.Add(doctor);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(doctor);
        }
    }
}