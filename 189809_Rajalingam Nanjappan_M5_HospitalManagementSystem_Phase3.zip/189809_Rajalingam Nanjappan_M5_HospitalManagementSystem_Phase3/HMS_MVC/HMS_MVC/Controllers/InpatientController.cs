﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS_MVC.Controllers
{
    public class InpatientController : Controller
    {
        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();
        // GET: Inpatient
        public ActionResult IndexinPatient()
        {
            return View(context.InPatients.ToList());
        }

        public ActionResult ListInpatient()
        {
            return View(context.InPatients.ToList());
        }


        public ActionResult InsertInPatient()
        {

            ViewBag.PatientId = new SelectList(context.Patients, "PatientId", "PatientId");
            ViewBag.DoctorId = new SelectList(context.Doctors, "DoctorId", "DoctorId");
            ViewBag.LabId = new SelectList(context.Labs, "LabId", "LabId");
            return View();
        }
        [HttpPost]
        public ActionResult InsertInPatient(InPatient inpatient)
        {
            if (ModelState.IsValid)
            {
                context.InPatients.Add(inpatient);
                context.SaveChanges();
                return RedirectToAction("IndexinPatient");
            }
            return View(inpatient);
        }
    }
}