﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS_MVC.Controllers
{
    public class LabReportController : Controller
    {
        // GET: LabReport

        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();
        public ActionResult IndexLab()
        {
            return View(context.Labs.ToList());
        }
        public ActionResult InsertLabReport()
        {
            ViewBag.DoctorId = new SelectList(context.Doctors, "DoctorId", "DoctorId");
            ViewBag.PatientId = new SelectList(context.Patients, "PatientId", "PatientId");
            return View();
        }
        [HttpPost]
        public ActionResult InsertLabReport(Lab lab)
        {
            if (ModelState.IsValid)
            {
                context.Labs.Add(lab);
                context.SaveChanges();
                return RedirectToAction("IndexLab");
            }
            return View(lab);
        }

        public ActionResult GenerateLab(int? patientId)

        {

            Lab searchedPatient = (from lab in context.Labs

                                   where lab.PatientID == patientId

                                   select lab).FirstOrDefault();
            return View(searchedPatient);

        }

    }
}