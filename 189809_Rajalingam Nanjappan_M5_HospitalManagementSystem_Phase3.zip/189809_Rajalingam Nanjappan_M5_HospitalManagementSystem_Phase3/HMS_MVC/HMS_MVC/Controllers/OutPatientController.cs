﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS_MVC.Controllers
{
    public class OutPatientController : Controller
    {
        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();
        // GET: OutPatient
        public ActionResult IndexoutPatient()
        {
            return View(context.OutPatients.ToList());
        }

        public ActionResult ListoutPatient()
        {
            return View(context.OutPatients.ToList());
        }

        public ActionResult InsertOutPatient()
        {
            ViewBag.PatientId = new SelectList(context.Patients, "PatientId", "PatientId");
            ViewBag.DoctorId = new SelectList(context.Doctors, "DoctorId", "DoctorId");
            ViewBag.LabId = new SelectList(context.Labs, "LabId", "LabId");
            return View();
        }
        [HttpPost]
        public ActionResult InsertOutPatient(OutPatient outpatient)
        {
            if (ModelState.IsValid)
            {
                context.OutPatients.Add(outpatient);
                context.SaveChanges();
                return RedirectToAction("IndexoutPatient");
            }
            return View(outpatient);
        }

    }
}