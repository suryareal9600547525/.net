﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Mvc;
using HMS_MVC.Models;

namespace HMS.Controllers
{
    public class PatientController : Controller
    {
        Training_18Jul19_PuneEntities1 context = new Training_18Jul19_PuneEntities1();

        public ActionResult Index()
        {
            return View(context.Patients.ToList());
        }


        public ActionResult List()
        {
            return View(context.Patients.ToList());
        }

        public ActionResult InsertPatient()
        {
            ViewBag.DoctorId = new SelectList(context.Doctors, "DoctorId", "DoctorId");
            return View();
        }
        [HttpPost]
        public ActionResult InsertPatient(Patient patient)
        {
            if (ModelState.IsValid)
            {
                context.Patients.Add(patient);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(patient);
        }

        public ActionResult Search(int? patientId)

        {

            Patient searchedPatient = (from patient in context.Patients

                                       where patient.PatientID == patientId

                                       select patient).FirstOrDefault();
            return View(searchedPatient);

        }
        public ActionResult UpdatePatient(int patientId)
        {
            Patient patients = context.Patients.Find(patientId);
            // ViewBag.DoctorId = new SelectList(context.Doctors, "DoctorId", "DoctorId");
            return View(patients);
        }

        [HttpPost]
        public ActionResult UpdatePatient(int patientId, FormCollection collection)
        {
            Patient patient = context.Patients.Find(Convert.ToInt32(collection["PatientId"]));
            if (patient != null)
            {
                if (ModelState.IsValid)
                {
                    patient.Name = collection["Name"];
                    patient.DoctorID = Convert.ToInt32(collection["DoctorId"]);
                    patient.Gender = collection["Gender"];
                    patient.Age = Convert.ToInt32(collection["Age"]);
                    patient.Address = collection["Address"];
                    patient.PhoneNo = collection["PhoneNo"];
                    patient.Weight = collection["Weight"];
                    patient.Disease = collection["Disease"];
                    

                    context.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            return View(patient);
        }


    }
}
