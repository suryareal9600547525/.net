﻿using EmployeeDataAccessLayer;
using EmployeeEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeBusinessLayer
{
    public class EmployeeBAL
    {
        EmployeeDAL dal = new EmployeeDAL();

        public int Add(Employee employee)
        {
            int rollno;
            try
            {
                rollno = dal.Insert(employee);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rollno;
        }

        public void Modify(Employee employee)
        {
            try
            {
                dal.Update(employee);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Employee Search(int rollNo)
        {
            Employee employee = null;
            try
            {
                employee = dal.SelectBy(rollNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        public void Remove(int rollNo)
        {
            try
            {
                dal.delete(rollNo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> view()
        {
            List<Employee> employee = null;
            try
            {
                employee = dal.SelectAll();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }
    }
}
    

