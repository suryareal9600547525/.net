﻿using EmployeeEntities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDataAccessLayer
{
    public class EmployeeDAL
    {
        static SqlConnection cn = null;
        static SqlCommand cmd = null;
        SqlDataReader dr = null;

        public EmployeeDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }
        public int Insert(Employee employee)
        {
            int rollno;
            try
            {
                cmd = new SqlCommand("[190305].USP_InsertStudent", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter rno = new SqlParameter("@rollno", System.Data.SqlDbType.Int);
                rno.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(rno);
                cmd.Parameters.AddWithValue("@fullName", employee.FullName);
                cmd.Parameters.AddWithValue("@gender", employee.Gender);
                cmd.Parameters.AddWithValue("@dob", employee.DOB);
                cmd.Parameters.AddWithValue("@mobNo", employee.Contact);
                cmd.Parameters.AddWithValue("@email", employee.Emailid);
                cmd.Parameters.AddWithValue("@state", employee.ResedentialState);
                cmd.Parameters.AddWithValue("@add", employee.CommunicationAddress);
                cn.Open();
                cmd.ExecuteNonQuery();
                rollno = Convert.ToInt32(cmd.Parameters["@rollno"].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return rollno;
        }

        public void Update(Employee employee)
        {
            try
            {
                cmd = new SqlCommand("[190305].[USP_UpdateStudent]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@rollno", employee.RollNo);
                cmd.Parameters.AddWithValue("@fullName", employee.FullName);
                cmd.Parameters.AddWithValue("@gender", employee.Gender);
                cmd.Parameters.AddWithValue("@dob", employee.DOB);
                cmd.Parameters.AddWithValue("@mobNo", employee.Contact);
                cmd.Parameters.AddWithValue("@email", employee.Emailid);
                cmd.Parameters.AddWithValue("@state", employee.ResedentialState);
                cmd.Parameters.AddWithValue("@add", employee.CommunicationAddress);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public Employee SelectBy(int rollNo)
        {
            Employee employee = new Employee();
            try
            {
                cmd = new SqlCommand("[190305].[USP_SearchStudent]", cn);
                cmd.Parameters.AddWithValue("@rollno", rollNo);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    employee.RollNo = Convert.ToInt32(dr[0]);
                    employee.FullName = dr[1].ToString();
                    employee.Gender = dr[2].ToString();
                    employee.DOB = Convert.ToDateTime(dr[3]);
                    employee.Contact = dr[4].ToString();
                    employee.Emailid = dr[5].ToString();
                    employee.ResedentialState = dr[6].ToString();
                    employee.CommunicationAddress = dr[7].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return employee;
        }

        public void delete(int rollNo)
        {
            try
            {
                cmd = new SqlCommand("[190305].[USP_DeleteStudent]", cn);
                cmd.Parameters.AddWithValue("@rollno", rollNo);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public List<Employee> SelectAll()
        {
            List<Employee> listst = new List<Employee>();
            try
            {
                cmd = new SqlCommand("[190305].USP_ViewStudent", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee employee = new Employee();
                    employee.RollNo = Convert.ToInt32(dr[0]);
                    employee.FullName = dr[1].ToString();
                    employee.Gender = dr[2].ToString();
                    employee.DOB = Convert.ToDateTime(dr[3]);
                    employee.Contact = dr[4].ToString();
                    employee.Emailid = dr[5].ToString();
                    employee.ResedentialState = dr[6].ToString();
                    employee.CommunicationAddress = dr[7].ToString();
                    listst.Add(employee);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return listst;
        }

    }
}
    

