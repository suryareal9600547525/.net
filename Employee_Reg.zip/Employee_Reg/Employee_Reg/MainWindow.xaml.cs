﻿using EmployeeBusinessLayer;
using EmployeeEntities;
using EmployeeExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Employee_Reg
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeBAL bal = null;

        public MainWindow()
        {
            InitializeComponent();
            bal = new EmployeeBAL();
            Populate();
        }

        private void clear()
        {
            txt2.Text = txt.Text = txt1.Text = txt3.Text = txt4.Text = txt6.Selection.Text = string.Empty;
            Female.IsChecked = false;
            Male.IsChecked = false;
            txt5.SelectedIndex = 0;
        }

        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txt1.Text == null | txt1.Text == string.Empty | txt1.Text.Length < 5)
            {
                isValid = false;
                sb.Append("Full Name must contain atleast 5 characters and it can't be empty!" + Environment.NewLine);
            }
            if (!Regex.Match(txt1.Text, "^[a-zA-Z]*$").Success)
            {
                isValid = false;
                sb.Append("Full Name should only contain Alphabets !!!\n");
            }

            if (txt2.Text == null | txt2.Text == string.Empty)
            {
                isValid = false;
                sb.Append("\nDOB is Empty!" + Environment.NewLine);
            }

            if (txt3.Text == null | txt3.Text == string.Empty | txt3.Text.Length < 10)
            {
                isValid = false;
                sb.Append("Mobile No must contain 10 digits and it can't be empty!!" + Environment.NewLine);
            }
            if (!Regex.Match(txt3.Text.ToString(), "^[0-9]*$").Success)
            {
                isValid = false;
                sb.Append("Mobile no. should only contain digits !!!");
            }

            if (txt4.Text == null | txt4.Text == string.Empty)
            {
                isValid = false;
                sb.Append("Email can't be empty!!" + Environment.NewLine);
            }
            if (!Regex.Match(txt4.Text, "^[a-z0-9]+@([a-z0-9]+[.])+[a-z]{2,5}$").Success)
            {
                isValid = false;
                sb.Append("Invalid Email Id!!!");
            }

            txt6.SelectAll();
            if (txt6.Selection.Text.Length <= 8)
            {
                isValid = false;
                sb.Append("Address must contain atleast 8 characters and it can't be empty!!" + Environment.NewLine);
            }

            if (!isValid)
            {
                throw new EmployeeException(sb.ToString());
            }
            return isValid;
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee();
            try
            {
                if (Male.IsChecked == true)
                {
                    employee.Gender = Male.Content.ToString();
                }
                else
                {
                    employee.Gender = Female.Content.ToString();
                }
                txt6.SelectAll();
                if (ValidateUI())
                {
                    employee.FullName = txt1.Text;
                    employee.DOB = (DateTime)txt2.SelectedDate;
                    employee.Contact = txt3.Text;
                    employee.Emailid = txt4.Text;
                    employee.ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString();
                    employee.CommunicationAddress = txt6.Selection.Text;
                    bal.Add(employee);
                    MessageBox.Show("Record Inserted");
                    Populate();
                    clear();
                }
                else
                {
                    MessageBox.Show("Validation error");
                }
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee();
            try
            {
                employee.RollNo = Convert.ToInt32(txt.Text);
                employee.FullName = txt1.Text;
                if (Male.IsChecked == true)
                {
                    employee.Gender = Male.Content.ToString();
                }
                else
                {
                    employee.Gender = Female.Content.ToString();
                }
                employee.DOB = (DateTime)txt2.SelectedDate;
                employee.Contact = txt3.Text;
                employee.Emailid = txt4.Text;
                txt6.SelectAll();
                employee.CommunicationAddress = txt6.Selection.Text;
                employee.ResedentialState = ((ListBoxItem)txt5.SelectedItem).Content.ToString();
                bal.Modify(employee);
                MessageBox.Show("Record updated");
                Populate();
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee();
            try
            {
                employee.RollNo = Convert.ToInt32(txt.Text);
                bal.Remove(employee.RollNo);
                MessageBox.Show("Record Deleted");
                Populate();
                clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rollNo = int.Parse(txt.Text);
                Employee employee = bal.Search(rollNo);

                txt.Text = employee.RollNo.ToString();
                txt1.Text = employee.FullName.ToString();

                String gender = employee.Gender;
                if (gender == "Male")
                {
                    Male.IsChecked = true;
                }
                else if (gender == "Female")
                {
                    Female.IsChecked = true;
                }
                txt2.Text = employee.DOB.ToShortDateString().ToString();
                txt3.Text = employee.Contact.ToString();
                txt4.Text = employee.Emailid.ToString();
                txt6.Document.Blocks.Clear();
                txt6.Document.Blocks.Add(new Paragraph(new Run(employee.CommunicationAddress)));

                foreach (ListBoxItem lbi in txt5.Items)
                {
                    if (lbi.Content.ToString() == employee.ResedentialState.ToString())
                    {
                        lbi.IsSelected = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Populate()
        {
            try
            {
                List<Employee> studs = bal.view();
                dgStudents.ItemsSource = studs;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

    }
}

    

