﻿CREATE schema [H189821]

CREATE TABLE [H189821].Employee
(
  RollNo int PRIMARY KEY,
  FullName varchar(20),
  Gender varchar(10),
  DOB DateTime,
  Contact varchar(10),
  Emailid varchar(20),
  ResedentialState varchar(50),
  CommunicationAddress varchar(50)

  
)
