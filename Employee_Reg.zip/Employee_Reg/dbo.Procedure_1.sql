﻿CREATE PROCEDURE [H189821].[USP_SearchStudent]
	@RollNo int 	
AS
begin
	if(@RollNo is null OR @rollNo <0)
		Begin 
			Raiserror ('Student Id cannot be null or empty',1,1)
		end
		Else		
			Begin
			Select * from [H189821].Employee where RollNo = @RollNo
			End
	End
RETURN 0