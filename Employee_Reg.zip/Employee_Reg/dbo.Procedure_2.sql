﻿CREATE PROCEDURE [H189821].[USP_UpdateStudent1]
	@RollNo int ,
	@FullName varchar(30),
	@Gender varchar(6),
	@DOB datetime,
	@Contact varchar(10),
	@Emailid varchar(20),
	@ResedentialState varchar(20),
	@CommunicationAddress varchar(100)
	
	
	
AS
BEGIN
		if (@RollNo is null OR @RollNo <0 ) 
		BEGIN
			RaisError('Employee Id cannot be null or empty',1,1)
		END
	ELSE
		BEGIN
			if exists (select RollNo from [H189821].Employee where RollNo = @RollNo ) 
			BEGIN
				update [H189821].Employee set
				 RollNo = @FullName ,
				 Gender = @Gender,
				 DOB = @DOB,
				 Contact =@Contact,
				 Emailid = @Emailid, 
				 ResedentialState = @ResedentialState,
				 CommunicationAddress = @CommunicationAddress
				 
				 where 
				 RollNo = @RollNo
			End
		Else
			Begin
					RaisError('Employee ID not Exists',1,1)
			end
		end
	end
RETURN 0

