﻿CREATE PROCEDURE [H189821].[USP_ViewStudent1]
	@RollNo int out,
	@FullName varchar(30),
	@Gender varchar(6),
	@DOB datetime,
	@Contact varchar(10),
	@Emailid varchar(20),
	@ResedentialState varchar(20),
	@CommuniacationAddress varchar(100)
	
	
	
AS
	SELECT @RollNo ,@FullName,@Gender,@DOB,@Contact,@Emailid,@ResedentialState,@CommuniacationAddress
RETURN 0