﻿using System;

namespace GuestBook.Exceptions
{
    public class GuestBookException :ApplicationException
    {
        public GuestBookException()
            : base()
        {
        }
        public GuestBookException( string message)
           : base(message)
        {
        }
        public GuestBookException(string message,Exception InnerException)
           : base(message,InnerException)
        {
        }
    }
}
