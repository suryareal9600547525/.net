﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestBook.Entities;
using GuestBook.BusinessLayer;
using GuestBook.Exceptions;

namespace GuestBook
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char c;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestByID();
                        break;
                    case 4:
                        UpdateGuest();
                        break;
                    case 5:
                        DeleteGuest();
                        break;
                    case 6:
                        SerializeGuest();
                        break;
                    case 7:
                        DeSerializeGuest();
                        break;
                    case 8:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you Want to Continue? 'y' to continue and 'n' to exit.");
                c = Convert.ToChar(Console.ReadLine());
            } while (c=='y');
        }

        private static void DeleteGuest()
        {
            try
            {
                int deleteGuestID;
                Console.WriteLine("Enter GuestID to Delete:");
                deleteGuestID = Convert.ToInt32(Console.ReadLine());
                Guest deleteGuest = GuestBL.SearchGuestBL(deleteGuestID);
                if (deleteGuest != null)
                {
                    bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                    if (guestdeleted)
                        Console.WriteLine("Guest Deleted");
                    else
                        Console.WriteLine("Guest not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }


            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateGuest()
        {
            try
            {
                int updateGuestID;
                Console.WriteLine("Enter GuestID to Update Details:");
                updateGuestID = Convert.ToInt32(Console.ReadLine());
                Guest updatedGuest = GuestBL.SearchGuestBL(updateGuestID);
                if (updatedGuest != null)
                {
                    Console.WriteLine("Update Guest Name :");
                    updatedGuest.GuestName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedGuest.ContactNumber = Console.ReadLine();
                    bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                    if (guestUpdated)
                        Console.WriteLine("Guest Details Updated");
                    else
                        Console.WriteLine("Guest Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }


            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchGuestByID()
        {
            try
            {
                int searchGuestID;
                Console.WriteLine("Enter GuestID to Search:");
                searchGuestID = Convert.ToInt32(Console.ReadLine());
                Guest searchGuest = GuestBL.SearchGuestBL(searchGuestID);
                if (searchGuest != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.ContactNumber);
                    Console.WriteLine("==============================================================================");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ListAllGuests()
        {
            try
            {
                List<Guest> guestList = GuestBL.GetAllGuestsBL();
                if (guestList != null)
                {
                    Console.WriteLine("==============================================================================");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("==============================================================================");
                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", guest.GuestID, guest.GuestName, guest.ContactNumber);
                    }
                    Console.WriteLine("==============================================================================");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddGuest()
        {
            try
            {
                Guest newGuest = new Guest();
                Console.WriteLine("Enter GuestID :");
                newGuest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Guest Name :");
                newGuest.GuestName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newGuest.ContactNumber = Console.ReadLine();
                bool guestAdded = GuestBL.AddGuestBL(newGuest);
                if (guestAdded)
                    Console.WriteLine("Guest Added");
                else
                    Console.WriteLine("Guest not Added");
            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n=======================Guest Phonebook Menu==========================");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search Guest by ID");
            Console.WriteLine("4. Update Guest");
            Console.WriteLine("5. Delete Guest");
            Console.WriteLine("6. Serialize Guest");
            Console.WriteLine("7. DeSerialize Guest");
            Console.WriteLine("8. Exit");
            Console.WriteLine("==============================================================================\n");

        }

        private static void SerializeGuest()
        {
            bool guestSerialize = GuestBL.SerializeGuestBL();
            try
            {
                if (guestSerialize == true)
                {
                    Console.WriteLine("---------------Serialized.....................");
                }
            }
            catch(GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
        private static void DeSerializeGuest()
        {
            try
            {
                List<Guest> guestDeserialize = GuestBL.DeSerializeGuestBL();
                guestDeserialize.ForEach(el => Console.WriteLine(" Guest ID : {0}, Guest Name :{1}, Contact Number :{2}",el.GuestID,el.GuestName,el.ContactNumber));
                foreach (Guest Guest in guestDeserialize) {
                   Console.WriteLine(Guest.GuestID+"\t"+Guest.GuestName+"\t"+"\t"+Guest.ContactNumber);
                }
                for (int i=0;i<guestDeserialize.Count;i++) {
                   Console.WriteLine(guestDeserialize[i].GuestID);
                }
               
            }
            catch (GuestBookException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
