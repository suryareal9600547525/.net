﻿using System;
using GuestBook.Entities;
using GuestBook.Exceptions;
using System.Data.Common;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
 
namespace guestBook.DataAccessLayer
{
    public class GuestDAL
    {
        public static List<Guest> guestList = new List<Guest>();

        public bool AddGuestDAL(Guest newGuest)
        {
            bool guestAdded = false;
            try
            {
                guestList.Add(newGuest);
                //SerializeGuestDAL();
                guestAdded = true;
                //DeSerializeGuestDAL();
                guestAdded = true;
            }
            catch(SystemException e)
            {
                throw new GuestBookException(e.Message);
            }
            return guestAdded;
        }
        public Guest SearchGuestDAL(int searchGuestID)
        {
            Guest searchGuest = null;
            try
            {
                searchGuest=guestList.Find(guest=> guest.GuestID==searchGuestID);
            }
            catch (SystemException e)
            {
                throw new GuestBookException(e.Message);
            }
            return searchGuest;
        }
        public bool UpdateGuestDAL(Guest updateGuest)
        {
            bool guestUpdated = false;
            try
            {
                for(int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].GuestID == updateGuest.GuestID)
                    {
                        updateGuest.GuestName = guestList[i].GuestName;
                        updateGuest.ContactNumber = guestList[i].ContactNumber;
                        guestUpdated = true;
                    }
                }
                
            } 
            catch (SystemException e)
            {
                throw new GuestBookException(e.Message);
            }
            return guestUpdated;
        }
        public bool DeleteGuestDAL(int deleteGuestID)
        {
            bool guestDeleted = false;
            try
            {
                Guest deleteGuest = guestList.Find(guest => guest.GuestID == deleteGuestID);

                if (deleteGuest != null)
                {
                    guestList.Remove(deleteGuest);
                    guestDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new GuestBookException(ex.Message);
            }
            return guestDeleted;

        }
        public List<Guest> GetAllGuestDAL()
        {
            return guestList;
        }

        public  bool SerializeGuestDAL( )
        {
            bool serializedGuest = false;
            try
            {
                FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Append, FileAccess.Write, FileShare.Read);
                BinaryFormatter objBinF = new BinaryFormatter();
                objBinF.Serialize(objFS, guestList);
                objFS.Close();
                serializedGuest = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return serializedGuest;
        }
        public  List<Guest> DeSerializeGuestDAL()
        {
            
                FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Open, FileAccess.Read, FileShare.Read);
                BinaryFormatter binary = new BinaryFormatter();
                List<Guest> objNewGuest = binary.Deserialize(objFS) as List<Guest>;
                objFS.Close();
            Console.WriteLine("-----Deserialized----");
            
                return objNewGuest;
      
        }
    }
}
