﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS_Entities;
using HRDS_Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace HRDS_DataAccessLayer
{
    public class EmployeeDAL
    {
        public EmployeeDAL()
        {

        }

        public bool AddEmployeeDAL(Employee objemployee)
        {
            SqlConnection objCon = null;
            bool employeeAdded = false;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("D189752_InsertEmployee", objCon);
                objcom.CommandType = System.Data.CommandType.StoredProcedure;
                //
                SqlParameter sqlParam_Id = new SqlParameter("@Id", objemployee.Id);
                SqlParameter sqlParam_Name = new SqlParameter("@Name", objemployee.Name);
                SqlParameter sqlParam_Designation = new SqlParameter("@Designation", objemployee.Designation);
                SqlParameter sqlParam_Department = new SqlParameter("@Department", objemployee.Department);
                //
                objcom.Parameters.Add(sqlParam_Id);
                objcom.Parameters.Add(sqlParam_Name);
                objcom.Parameters.Add(sqlParam_Designation);
                objcom.Parameters.Add(sqlParam_Department);
                //
                objCon.Open();
                objcom.ExecuteNonQuery();
                employeeAdded = true;
                
                
            }
            catch (SqlException objsqlexp)
            {

                throw new HRDSException(objsqlexp.Message);
            }
            finally {
                objCon.Close();
            }
            return employeeAdded;
        }

        public bool UpdateEmployeeDAL(Employee objemployee)
        {
            SqlConnection objCon = null;
            bool employeeUpdated = false;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("D189752_UpdateEmployee", objCon);
                objcom.CommandType = System.Data.CommandType.StoredProcedure;
                //
                SqlParameter sqlParam_Id = new SqlParameter("@Id", objemployee.Id);
                SqlParameter sqlParam_Name = new SqlParameter("@Name", objemployee.Name);
                SqlParameter sqlParam_Designation = new SqlParameter("@Designation", objemployee.Designation);
                SqlParameter sqlParam_Department = new SqlParameter("@Department", objemployee.Department);
                //
                objcom.Parameters.Add(sqlParam_Id);
                objcom.Parameters.Add(sqlParam_Name);
                objcom.Parameters.Add(sqlParam_Designation);
                objcom.Parameters.Add(sqlParam_Department);
                //
                objCon.Open();
                objcom.ExecuteNonQuery();
                employeeUpdated = true;


            }
            catch (SqlException objsqlexp)
            {

                throw new HRDSException(objsqlexp.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeUpdated;
        }

        public bool DeleteEmployeeDAL(int id)
        {
            SqlConnection objCon = null;
            bool employeeDeleted = false;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("D189752_DeleteEmployee", objCon);
                objcom.CommandType = System.Data.CommandType.StoredProcedure;
                //
                SqlParameter sqlParam_Id = new SqlParameter("@Id", id);
               
                //
                objcom.Parameters.Add(sqlParam_Id);
                //
                objCon.Open();
                objcom.ExecuteNonQuery();
                employeeDeleted = true;


            }
            catch (SqlException objsqlexp)
            {

                throw new HRDSException(objsqlexp.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeDeleted;
        }
        public Employee SearchEmployeeDAL(int id)
        {
            SqlConnection objCon = null;
            Employee objEmployee = null;
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("D189752_DeleteEmployee", objCon);
                objcom.CommandType = System.Data.CommandType.StoredProcedure;
                //
                SqlParameter sqlParam_Id = new SqlParameter("@Id", SqlDbType.Int);
                SqlParameter sqlParam_Name = new SqlParameter("@Name", SqlDbType.VarChar,50);
                SqlParameter sqlParam_Designation = new SqlParameter("@Designation", SqlDbType.Int);
                SqlParameter sqlParam_Department = new SqlParameter("@Department", SqlDbType.Int);
                //
                sqlParam_Id.Direction = ParameterDirection.Input;
                sqlParam_Name.Direction = ParameterDirection.Output;
                sqlParam_Designation.Direction = ParameterDirection.Output;
                sqlParam_Department.Direction = ParameterDirection.Output;
                //
                objcom.Parameters.Add(sqlParam_Id);
                objcom.Parameters.Add(sqlParam_Name);
                objcom.Parameters.Add(sqlParam_Designation);
                objcom.Parameters.Add(sqlParam_Department);
                //
                sqlParam_Id.Value = id;
                //
                objCon.Open();
                objcom.ExecuteNonQuery();
                objEmployee = new Employee();
                objEmployee.Id = id;
                objEmployee.Name = sqlParam_Name.Value as string;
                objEmployee.Designation =Convert.ToInt32 (sqlParam_Designation.Value);
                objEmployee.Department = Convert.ToInt32 (sqlParam_Department.Value);

            }
            catch (SqlException objsqlexp)
            {

                throw new HRDSException(objsqlexp.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployee;
        }
        public List<Employee> GetAllEmployeeDAL()
        {

            SqlConnection objCon = null;
            List<Employee> objEmployees = new List<Employee>();
            try
            {
                objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objcom = new SqlCommand("D189752_SelectEmployees", objCon);
                objcom.CommandType = System.Data.CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objcom.ExecuteReader();

                while (objDR.Read()) {
                    Employee objEmployee = new Employee();
                    objEmployee.Id = Convert.ToInt32(objDR[0]);
                    objEmployee.Name = Convert.ToString(objDR[0]);
                    objEmployee.Designation = Convert.ToInt32(objDR[0]);
                    objEmployee.Department = Convert.ToInt32(objDR[0]);
                    objEmployees.Add(objEmployee);
                }
                
            }
            catch (SqlException objsqlexp)
            {

                throw new HRDSException(objsqlexp.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployees;
        }
    }
}
