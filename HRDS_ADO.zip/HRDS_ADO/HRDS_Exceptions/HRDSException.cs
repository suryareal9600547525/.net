﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRDS_Exceptions
{
    public class HRDSException:ApplicationException
    {
        public HRDSException() : base() {

        }
        public HRDSException(String message) : base(message)
        {

        }
        public HRDSException(string message, Exception innerException) : base(message,innerException)
        {

        }
    }
}
