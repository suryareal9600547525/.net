﻿CREATE PROCEDURE [D189752].[InsertEmployee]
	@Id int ,
	@Name varchar(50),
	@Designation int,
	@Department int
AS
BEGIN
	INSERT INTO D189752.Employee1 values(@Id,@Name,@Designation,@Department) 
END

