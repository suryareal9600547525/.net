﻿CREATE PROCEDURE [D189752].[UpdateEmployee]
	@Id int ,
	@Name varchar(50),
	@Designation int,
	@Department int
AS
BEGIN
	UPDATE D189752.Employee1 SET id = @Id,name = @Name,Designation = @Designation,Department = @Department WHERE id=@Id
END

Drop PROCEDURE [D189752].[UpdateEmployee]
