﻿CREATE PROCEDURE [D189752].[DeleteEmployee]
	@Id int 
	
AS
BEGIN
	Delete From D189752.Employee1 WHERE id=@Id
END
