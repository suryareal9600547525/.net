﻿CREATE PROCEDURE [D189752].[SelectEmployee]
	@Id int ,
	@Name varchar(50) output,
	@Designation int  output,
	@Department int output
AS
Begin
	Select Name,Designation ,Department  From D189752.Employee1 
End