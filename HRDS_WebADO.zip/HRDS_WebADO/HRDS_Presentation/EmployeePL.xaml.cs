﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using HRDS_BusinessLayer;
using HRDS_DataAccessLayer;
using HRDS_Exceptions;
using HRDS_Entities;
using System.Data;

namespace HRDS_Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class EmployeePL : Window
    {
        public EmployeePL()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDepartment();
            GetDesignation();
        }

        private void BtnAddEmp_Click(object sender, RoutedEventArgs e)
        {
            AddEmp();
        }

        private void BtnUpdateEmp_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmp();
        }

        private void BtnDeleteEmp_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmp();
        }

        private void BtnSearchEmp_Click(object sender, RoutedEventArgs e)
        {
            searchEmp();
        }

        private void BtnGetEmp_Click(object sender, RoutedEventArgs e)
        {
            GetAllEmp();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            clear();
        }

        private void GetDesignation()
        {
            try
            {
                DataTable desiglist = EmployeeBL.getDesigBL();
                cmbDesig.ItemsSource = desiglist.DefaultView;
                cmbDesig.DisplayMemberPath = desiglist.Columns[1].ColumnName;
                cmbDesig.SelectedValuePath = desiglist.Columns[0].ColumnName;
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetDepartment() {
            try
            {
                DataTable deptlist = EmployeeBL.getDeptBL();
                cmbDept.ItemsSource = deptlist.DefaultView;
                cmbDept.DisplayMemberPath = deptlist.Columns[1].ColumnName;
                cmbDept.SelectedValuePath = deptlist.Columns[0].ColumnName;
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void AddEmp() {
            try

            {
                int id, desigid, deptid;
                string name;
                bool result;

                id = Convert.ToInt32(txtID.Text);
                name = txtName.Text;
                desigid = Convert.ToInt32(cmbDesig.SelectedValue);
                deptid = Convert.ToInt32(cmbDept.SelectedValue);

                Employee employee = new Employee
                {
                    Id = id,
                    Name = name,
                    Designation = desigid,
                    Department = deptid
                };
                result = EmployeeBL.AddEmployeeBL(employee);
                
                if (result == true)
                {
                    MessageBox.Show("Employee Record Added Sucessfully");
                }
                else
                {
                    MessageBox.Show("Employee Record couldn't be Added");
                }
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void UpdateEmp() {
            try
            {
                int id, desigid, deptid;
                string name;
                bool result;

                id = Convert.ToInt32(txtID.Text);
                name = txtName.Text;
                desigid = Convert.ToInt32(cmbDesig.SelectedValue);
                deptid = Convert.ToInt32(cmbDept.SelectedValue);

                Employee employee = new Employee
                {
                    Id = id,
                    Name = name,
                    Designation = desigid,
                    Department = deptid
                };
                result=EmployeeBL.UpdateEmployeeBL(employee);
                if(result==true)
                {
                    MessageBox.Show("Employee Record Updated Sucessfully");
                }
                else
                {
                    MessageBox.Show("Employee Record couldn't be Updated");
                }
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void DeleteEmp() {
            try
            {
                int id;
                bool result;

                id = Convert.ToInt32(txtID.Text);
                
                result = EmployeeBL.DeleteEmployeeBL(id);
                if (result == true)
                {
                    MessageBox.Show("Employee Record Deleted Sucessfully");
                }
                else
                {
                    MessageBox.Show("Employee Record couldn't be Deleted");
                }
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void searchEmp()
        {
            try
            {
                int id;
                Employee result;

                id = Convert.ToInt32(txtID.Text);

                result = EmployeeBL.SearchEmployeeBL(id);
                if (result != null)
                {
                    txtName.Text = result.Name;
                    cmbDept.SelectedValue = result.Department;
                    cmbDesig.SelectedValue = result.Designation;
                }
                else
                {
                    MessageBox.Show("Employee couldn't be found");
                }
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetAllEmp()
        {
            try
            {              
                List<Employee> objEmp;

                objEmp = EmployeeBL.GetAllEmployeeBL();
               
                if(objEmp != null)
                {
                    dgEmployee.ItemsSource = objEmp;
                }
                else
                {
                    MessageBox.Show("No Record Available");
                }
            }
            catch (HRDSExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void clear() {
            txtID.Clear();
            txtName.Clear();
            cmbDesig.SelectedIndex = -1;
            cmbDept.SelectedIndex = -1;            
            dgEmployee.DataContext = null;

        }
    }
}
