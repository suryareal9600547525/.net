﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LAB12_Extended
{
    class Program
    {
        static void Main(string[] args)
        {


            int choice;
            char c;

            do
            {
                Console.WriteLine("================================== Menu =================================" +
                    "\n 1 to Create Directory" +
                    "\n 2 to Create File" +
                    "\n 3 to Store Batch Details" +
                    "\n 4 to Get Backup" +
                    "\n 5 to View Details" +
                    "\n ============================================================================= ");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Directory Name :");
                        string Dir = Console.ReadLine();
                        createDirectory(Dir);
                        break;
                    case 2:
                        CreateFile(get());
                        break;
                    case 3:

                        GetBatchDetails(get());
                        break;
                    case 4:
                        GetBackUpCopy();
                        break;
                    case 5:
                        ViewDetails(get());
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Do u want to Continue? press 'y' to Continue and 'n' to Exit. ");
                c = Convert.ToChar(Console.ReadLine());
            } while (c =='y');
        }
        static void createDirectory(string path)
        {
            string strDirectoryPath = @"C:\Academy\"+path;
            if (!Directory.Exists(strDirectoryPath))
            {
                Directory.CreateDirectory(strDirectoryPath);
                if (Directory.Exists(strDirectoryPath))
                {
                    Console.WriteLine("Directory Created Successfully.");
                }
                else
                {
                    Console.WriteLine("Directory could not beCreated ");
                }
            }
            else
            {
                Console.WriteLine("Directory Already exists...");
            }
        }
        static void CreateFile(string directory)
        {
            FileStream objFS = new FileStream(@"C:\Academy\"+directory, FileMode.Create, FileAccess.Write, FileShare.Read);
            objFS.Close();
            if (objFS != null)
            {
                Console.WriteLine("File Created Successfully.");
            }
        }
        static void GetBatchDetails(string d)
        {
            
            Console.WriteLine("Enter the Batch Domain :");
            string domain = Console.ReadLine();
            Console.WriteLine("Enter the Date of Joing in (mm/dd/yy) :");
            DateTime doj = Convert.ToDateTime(Console.ReadLine());
            string strFilePath = @"C:\Academy\" + d;
         
                FileStream objFS = new FileStream(strFilePath, FileMode.Append, FileAccess.Write, FileShare.Read);
                StreamWriter objSW = new StreamWriter(objFS);
                objSW.WriteLine("Batch Domain : "+ domain + ", Date of Joining :" + doj);
                if (objFS != null)
                {
                    Console.WriteLine("File Updated Successfully.");
                }
            objSW.Flush();
            objFS.Flush();
            objFS.Close();
        } 
        static void GetBackUpCopy()
        {
            //TODO:
            string sourceFilePath = get();
            Console.WriteLine("Enter Destination File Name :");
            string destinationFilePath = Console.ReadLine();
            string strFilePath = @"C:\Academy\" + sourceFilePath;
            string strFileDestinationPath = @"D:\" + destinationFilePath;
            if (File.Exists(strFileDestinationPath))
            {
                Console.WriteLine("The Destination File Name is Already Exists.");
            }
            else if (!File.Exists(strFilePath))
            {
                Console.WriteLine("The Source File not Exists.");
            }
            else if (File.Exists(strFilePath))
            {
                File.Copy(strFilePath, strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))
                {
                    Console.WriteLine("File Backup Successfully.");
                }
                else
                {
                    Console.WriteLine("Backup Failed.");
                }
            }
        }
        static void ViewDetails(string directory)
        {
            FileStream objFS = new FileStream(@"C:\Academy\"+directory, FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            string strDataFromFile = objSR.ReadToEnd();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("============================\n" + strDataFromFile);
        }
        static string get()
        {
            Console.WriteLine("Enter Directory Name :");
            string d = Console.ReadLine();
            Console.WriteLine("Enter File Name :");
            string file = "\\" + Console.ReadLine();
            string dir = d + file;
            return dir;
        }
    }
}
