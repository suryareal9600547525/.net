﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestPhoneBookDataAccessLayer;
using GuestPhoneBookEntities;
using GuestPhoneBookExceptions;

namespace GuestPhoneBookBusinessLayer
{
    public class ClassBL
    {
        public static bool Validation( ClassEL objGuest)
        {
            
            bool valid = true;
            try
            {
                if (objGuest.PhoneNo.Length < 10 || objGuest.PhoneNo.Length > 10)
                {
                    valid = false;
                    throw new ClassExpL ("Enter Phone no of 10 digits.");
                }
            }
            catch (ClassExpL e)
            {
                Console.WriteLine("Error: "+e.Message);
            }
            try
            {
                if (objGuest.ID <= 0)
                {
                    throw new ClassExpL("The value of Id should be greater than 0");
                }
            }
            catch (ClassExpL e) {
                Console.WriteLine("Error: "+e.Message);
            }
            try
            {
                if (objGuest.Name == string.Empty)
                {
                    valid = false;
                    throw new ClassExpL("Name can't be Empty");
                   
                }
            }
            catch (ClassExpL e)
            {

                Console.Write("Error: "+e.Message);
            }

            return valid;  
        }


        public static bool AddGuest(ClassEL AddGuest)
        {
            bool guestadded = false;


            bool valid= Validation(AddGuest);
            try
            {
                if (valid == true)
                {
                    guestadded = ClassDAL.AddGuest(AddGuest);
                }
                return guestadded;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
        }

        public static List<ClassEL> ListallGuest()
        {
            List<ClassEL> GuestList = new List<ClassEL>();

            GuestList= ClassDAL.ListallGuest();

            return GuestList;
        }

        public static ClassEL SearchGuest(int SearchGuestId)
        {
            try
            {
                ClassEL SearchGuest = ClassDAL.SearchGuest(SearchGuestId);
            
            return SearchGuest;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
        }

        public static bool UpdateGuest(ClassEL UpdateGuest)
        {
            try { 
            bool GuestUpdated = ClassDAL.UpdateGuest(UpdateGuest);

            return GuestUpdated;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
        }

        public static bool RemoveGuest(int UpdateGuestId) {
            bool guestRemoved=false;
            try { 
            guestRemoved= ClassDAL.RemoveGuest(UpdateGuestId);
            return guestRemoved;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
        }


        public static void SerializeGuest()
        {
            ClassDAL.SerializeGuest();
        }

        public static void DeSerializeGuest()
        {
            ClassDAL.DeSerializeGuest();
        }
    }
}
