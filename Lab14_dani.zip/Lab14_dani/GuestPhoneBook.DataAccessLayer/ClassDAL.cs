﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using GuestPhoneBookEntities;
using GuestPhoneBookExceptions;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;



namespace GuestPhoneBookDataAccessLayer
{
    public class ClassDAL
    {
        public static List<ClassEL> guestList = new List<ClassEL>();

        public static bool AddGuest(ClassEL AddGuest)
        {
            bool guestAdded = false;
            try { 
            guestList.Add(AddGuest);
            guestAdded = true;
            return guestAdded;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
        }

        public static List<ClassEL> ListallGuest()
        {

            return guestList;
        }

        public static ClassEL SearchGuest(int SearchGuestId)
        {
            ClassEL SearchGuest = new ClassEL();
            try { 
            SearchGuest = guestList.Find(guest => guest.ID == SearchGuestId);
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
            return SearchGuest;
        }

        public static bool UpdateGuest(ClassEL UpdateGuest)
        {
            bool GuestUpdated=false;
            try { 
            ClassEL Guest = guestList.Find(guest =>guest.ID==UpdateGuest.ID);
            Guest.Name = UpdateGuest.Name;
            Guest.PhoneNo = UpdateGuest.PhoneNo;
            GuestUpdated = true;
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
            return GuestUpdated;
        }

        public static bool RemoveGuest(int UpdateGuestId)
        {
            bool guestRemoved = false;
            try { 
            ClassEL UpdateGuest = guestList.Find(Guest =>Guest.ID==UpdateGuestId);
            if (UpdateGuest != null)
            {
                guestList.Remove(UpdateGuest);
                guestRemoved = true;
            }
            }
            catch (SystemException ex)
            {

                throw new ClassExpL(ex.Message);
            }
            catch (ClassExpL e)
            {
                throw e;
            }
            return guestRemoved;
        }

        public static void SerializeGuest()
        {
            try
            {
                FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Create, FileAccess.Write, FileShare.Read);
                BinaryFormatter objBinF = new BinaryFormatter();
                objBinF.Serialize(objFS, guestList);
                objFS.Close();
                Console.WriteLine("Serialization Completed");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeSerializeGuest()
        {
            
            try
            {

            
                FileStream objFS = new FileStream(@"D:\serializationGuest.dat", FileMode.Open,FileAccess.Read);
                BinaryFormatter objBINF = new BinaryFormatter();
                List<ClassEL> guestL = objBINF.Deserialize(objFS) as List<ClassEL>;
                objFS.Close();
                foreach ( ClassEL guest in guestL) {
                    Console.WriteLine(guest.ID+"\t"+guest.Name+"\t"+guest.PhoneNo);
                }
            }
            catch (Exception e)
            {

                Console.WriteLine(e.Message);
            }
        }
    }

}
