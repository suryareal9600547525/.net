﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuestPhoneBookEntities
{
    [Serializable]
    public class ClassEL
    {
        
        private int id;
        public int ID { get; set; }
        private string name;
        public string Name { get; set; }
        private string phoneNo;
        public string PhoneNo { get; set; }
       


        

    }

    

}
