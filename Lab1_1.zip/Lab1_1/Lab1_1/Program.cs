﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeLib.Employee[] objemp = new EmployeeLib.Employee[2];

            
            Console.WriteLine("--Taking Input From User--");
            Console.WriteLine("--------------------------");

            for (int i=0;i<objemp.Length;i++) {
                objemp[i]= new EmployeeLib.Employee(); 
            }

            for (int i=0;i<objemp.Length;i++) {
                Console.WriteLine("Enter your ID:");
                objemp[i].employeeid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter your name:");
                objemp[i].employeename = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Address:");
                objemp[i].address = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your City:");
                objemp[i].city = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Department:");
                objemp[i].department = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter your Salary:");
                objemp[i].salary = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("--Displaying Employee Details--");
            Console.WriteLine("--------------------------");
            for (int i=0;i<objemp.Length;i++) {
                Console.WriteLine("Empoyee name :" + objemp[i].employeename);
                Console.WriteLine("Empoyee Salary :" + objemp[i].salary);
            }

            Console.ReadKey();
        }
    }
}
