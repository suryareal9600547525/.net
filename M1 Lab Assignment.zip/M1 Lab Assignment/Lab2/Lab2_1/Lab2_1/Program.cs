﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            char choice;
            do
            {
                Console.WriteLine("Select the option:");
                Console.WriteLine("1-Square");
                Console.WriteLine("2-Cube");
                int option = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the number:");
                int inum = Convert.ToInt32(Console.ReadLine());

                Number objn = new Number(inum);

                int result;
                switch (option)
                {
                    case 1:
                        result = objn.Square();
                        Console.WriteLine(inum + " Square is : " + result);
                        break;
                    case 2:
                        result = objn.Cube();
                        Console.WriteLine(inum + " Cube is : " + result);
                        break;
                    default:
                        break;
                }

                Console.WriteLine("do you want to continue, y for contiue n for exit");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice=='y');
                   
            }
        }
    }
