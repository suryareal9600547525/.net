﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2_Q5
{
    class BooksDemo
    {
        static void Main(string[] args)
        {
            string[] colName = new string[4] {"Book Title","Author","Publisher","Price"};
            string[,] BookDetails = new string[2, 4];
            for(int i = 0; i < BookDetails.GetLength(0); i++)
            {
                Console.WriteLine("\nEnter the Details of Book :" + (i + 1));
                for (int j = 0; j < BookDetails.GetLength(1); j++)
                {
                    Console.Write("\nEnter the {0} : ", colName[j]);
                    BookDetails[i, j] = Console.ReadLine();
                }
            }
            //
            Console.WriteLine("\n-------- Details of Books --------");

            foreach (string str in colName)
            {
                Console.Write(str +" ");
            }
            for (int i = 0; i < BookDetails.GetLength(0); i++)
            {
                Console.WriteLine("");
                //Console.WriteLine("\nDetails of Book :" + (i + 1));
                for (int j = 0; j < BookDetails.GetLength(1); j++)
                {
                    //Console.WriteLine(colName[j]+":  "+BookDetails[i, j]);
                    Console.Write(BookDetails[i, j]);
                    Console.Write("\t   ");
                }
                
            }

            Console.Read();
        }
    }
}
