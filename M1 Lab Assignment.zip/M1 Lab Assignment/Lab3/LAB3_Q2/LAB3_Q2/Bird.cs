﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_Q2
{
    class Bird
    {
        
            public string Name;
            public double Maxheight;
            public Bird() //Default Constructor
            {
                this.Name = "MountainEagle";
                this.Maxheight = 500;
                
                // TODO: Add constructor logic here
                
            }
            public Bird(string birdname, double max_ht) //Overloaded Constructor
            {
            this.Name = birdname;
                this.Maxheight = max_ht;
            }
            public void fly()
            {
                Console.WriteLine(Name+" is flying at altitude "+Maxheight);
            }
            public void fly(double AtHeight)
            {
                if (AtHeight <= Maxheight)
                    Console.WriteLine(Name + " flying at " + AtHeight.ToString());
                else
            {
                Console.WriteLine(Name + " cannot fly at this height");
            }
                         
            }
        
        //The code in the Main function is as follows:
 
        static void Main(string[] args)
        {
            Bird b = new Bird("Eagle",200);
            b.fly();
            b.fly(300);
        }
    }
}
