﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace LAB3_Q3
{
    public class Cars 
    {
        static Car[] objCars = new Car[2];

        int ctr;
        public void AddCar(Car objCar)
        {
            objCars[ctr++] = objCar;
        }
        public void UpdateCar(Car objCar)
        {
            Car objCarSearch=SearchCar(objCar.Make);
            if (objCarSearch != null)
            {
                objCarSearch.Model = objCar.Model;
                objCarSearch.Year = objCar.Year;
                objCarSearch.SalePrice = objCar.SalePrice;
            }
        }
        public void DeleteCar(string make)
        {
             for(int i = 0; i < objCars.Length; i++)
            {//TODO: resolve the Exception
                if (objCars[i].Make == make)
                {
                    objCars[i] = null;
                }
            }

        }
        public Car SearchCar(string make)
        {
            foreach(Car objCar in objCars)
            {
                if (objCar.Make == make)
                {
                    return objCar;
                }
            }
            return null;

        }
        public Car[] GetCars()
        {
            return objCars;
        }

    }
}
