﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L_4Q_2
{
    class Circle :  Shape
    {
       public override void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
}
