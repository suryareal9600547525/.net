﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTOAPP
{
    class Customer1
    {
        int customerID;
        string customerName;
        string address;
        string city;
        string phone;
        int creditLimit;

        public int CustID { get { return customerID; } set { customerID = value; } }
        public string CustName { get{ return customerName; }
        set { customerName = value; }
}
        public string Address { get { return address; } set { address = value; } }
        public string City { get { return city; } set { city = value; } }
        public string Phone { get { return phone; } set { phone = value; } }
        public int CreditLimit { get { return creditLimit; } set { creditLimit = value; } }


        public Customer1()
        {

        }
        public Customer1(int id,string name,string add,string city,string phoneno,int limit)
        {
            this.CustID = id;
            this.CustName = name;
            this.Address = add;
            this.City = city;
            this.Phone = phoneno;
            this.CreditLimit = limit;
            if (CreditLimit > 50000)
            {
                throw (new InvalidCreditLimitException("404-Error"));
            }
            else
                this.CreditLimit = limit;
        }

    }
}
