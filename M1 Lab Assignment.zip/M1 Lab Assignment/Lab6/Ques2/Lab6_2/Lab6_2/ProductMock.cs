﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace Lab6_2
{
    
    class ProductMock
    {
        public bool A = false;
        public int productid;
        public string productname;
        public double productprice;

        public int ProductID{
            get{
            return productid;
            }
    set
        {
        productid=value;
        }
}
        public ProductMock()
        {

        }
        public string ProductName
        {
            get
            {
                return productname;
            }
            set
            {
                productname = value;
            }
        }
        public double ProductPrice
        {
            get
            {
                return productprice;
            }
            set
            {
                productprice = value;
            }
        }
        public ProductMock(int id,string name1,double price)
        {
            this.ProductID = id;
            this.ProductName = name1;
            this.ProductPrice = price;


            try
            {
                
                if (ProductID <= 0)
                {
                    throw new DataEntryException(" Product ID must be greater than 0 ");
                }


              
                // bool A = false;
                //A = ;
                else if (!Regex.IsMatch(productname, @"^[a-zA-Z0-9]+$"))
                {
                    throw new DataEntryException("enter only digits and numbers");
                }
                else if (ProductPrice <= 0)
                {
                    throw new DataEntryException("Enter Price greater than 0");
                }
                else if (ProductName == "")
                {
                    throw new DataEntryException("Product name should not be left blank");
                }
                else
                    A = true;

            }

            catch (DataEntryException ex)

            {
                Console.WriteLine(ex.Message);
            }
        }
        
            
            
        }
    }


