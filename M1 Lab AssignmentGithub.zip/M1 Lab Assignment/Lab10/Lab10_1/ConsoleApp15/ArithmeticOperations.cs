﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10Q1
{
    internal class ArithmeticOperations
    {
        delegate int ArithmeticOperationHandler(int num1, int num2);
        static void Main(string[] args)
        {
            Calculator obj = new Calculator();
            //UNICASTING DELEGATES
            ArithmeticOperationHandler objAOH = new ArithmeticOperationHandler(obj.Addition); 
            int result = objAOH.Invoke(12, 24);
            Console.WriteLine("output of addition=" + result);
            ArithmeticOperationHandler objAOH2 = new ArithmeticOperationHandler(obj.Subtraction);
            int result2 = objAOH2.Invoke(24, 12);
            Console.WriteLine("output of subtraction=" + result2); ArithmeticOperationHandler objAOH3 = new ArithmeticOperationHandler(obj.Multiplication);
            int result3 = objAOH3.Invoke(12, 24);
            Console.WriteLine("output of addition=" + result3);
            ArithmeticOperationHandler objAOH4 = new ArithmeticOperationHandler(obj.Division);
            int result4 = objAOH.Invoke(12, 24);
            Console.WriteLine("output of addition=" + result4);
            Console.ReadKey();

        }
    }
}
