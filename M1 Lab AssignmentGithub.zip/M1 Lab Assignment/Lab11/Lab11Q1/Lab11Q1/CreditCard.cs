﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11Q1
{
    delegate void CreditHandler();
    class CreditCard
    {
        internal event CreditHandler makePayment;
        int creditCardNo; 
        static int creditLimit=100000;
        int balanceAmount=creditLimit;
        string cardHolderName;
        public CreditCard(int ccno, string chname)
        {
            this.creditCardNo = ccno;
            this.cardHolderName = chname;  
        }
        public int GetBalance()
        {
            return balanceAmount;
        }
        public int GetCreditLimit()
        {
            return creditLimit;
        }
        public void MakePayment(int paymentAmount)
        {
            if (creditCardNo == 0000987 && cardHolderName == "xxx" && paymentAmount <= balanceAmount)
            {
                balanceAmount = balanceAmount - paymentAmount;
                makePayment();
                Console.WriteLine("Updated Balance Is : " + balanceAmount);
            }
            else
                Console.WriteLine("Transaction Failed");
        }
    }
}
