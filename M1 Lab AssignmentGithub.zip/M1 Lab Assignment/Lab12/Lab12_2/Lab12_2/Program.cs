﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

public class FileNotFound : Exception
{
    public FileNotFound(string Message) : base(Message) { }

}

namespace Lab12_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Copyoperation();
            Console.ReadKey();
        }
        static void Copyoperation()
        {
            Console.WriteLine("enter the source file with extension");
            string strFilePath = @"D:\ForfileIO\" + Console.ReadLine();
            Console.WriteLine("Enter the destination path with file extension");
            string strFileDestinationPath = @"D:\ForfileIO\DestinationFolder\" + Console.ReadLine();


            try
            {
                if (File.Exists(strFilePath))
                {
                    File.Copy(strFilePath, strFileDestinationPath);
                    if (File.Exists(strFileDestinationPath))
                    {
                        Console.WriteLine("file  copied succcessfully.");
                    }
                }
                if (!File.Exists(strFilePath))
                {
                    throw (new FileNotFound("Error-404"));
                }
            }
            catch (FileNotFound s)
            {
                Console.WriteLine("FileNotFound" + s.Message);
            }


        }     

            }
        }

    

