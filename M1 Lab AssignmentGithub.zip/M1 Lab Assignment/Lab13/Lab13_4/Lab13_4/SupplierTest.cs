﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace Lab13_4
{
    class SupplierTest
    {

        public static Supplier sup = new Supplier();
        static void Main(string[] args)
        {

            Console.Write("Enter Supplier ID = ");
            sup.SupplierId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Supplier Name = ");
            sup.SupplierName = Console.ReadLine();
            Console.Write("Enter Supplier City = ");
            sup.City = Console.ReadLine();
            Console.Write("Enter Supplier Phone Number = ");
            sup.PhoneNo = Console.ReadLine();
            Console.Write("Enter Supplier Email = ");
            sup.Email = Console.ReadLine();

            sup.AccpetDetail(sup);
            XmlSerialization();
            XmlDeserialization();
            //sup.DisplayDetail();
            //Console.WriteLine("ID = {0}\tName = {1}\tCity = {2}\tphone No = {3}\tEmail = {4}", sup.DisplayDetail().SupplierId/*, sup.DisplayDetail().SupplierName, sup.DisplayDetail().City, sup.DisplayDetail().PhoneNo, sup.DisplayDetail().Email*/);
            //Console.WriteLine("ID=" + sup.SupplierId);
            //Console.WriteLine("Name=" + sup.SupplierName);
            //Console.WriteLine("City=" + sup.City);
            //Console.WriteLine("Phone=" + sup.PhoneNo);
            //Console.WriteLine("Email=" + sup.Email);

            Console.ReadLine();
        }

        static void XmlSerialization()
        {
            FileStream objFS = new FileStream(@"D:\xmlserialize.xml", FileMode.Create, FileAccess.ReadWrite, FileShare.Read);
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));
            objXmlS.Serialize(objFS, sup);
            objFS.Close();

            Console.WriteLine("-------------Serialization Successfull------------------");
        }
        static void XmlDeserialization()
        {
            XmlSerializer objXmlS = new XmlSerializer(typeof(Supplier));

            Supplier i;

            using (Stream reader = new FileStream(@"D:\xmlserialize.xml", FileMode.Open))
            {
                // Call the Deserialize method to restore the object's state.
                i = (Supplier)objXmlS.Deserialize(reader);
            }
            Console.WriteLine("-------------Deserialization Sucessfull------------------");
            Console.WriteLine("-- Supplier Detail--");
            Console.WriteLine("ID = {0}\tName = {1}\tCity = {2}\tphone No = {3}\tEmail = {4}", i.SupplierId, i.SupplierName, i.City, i.PhoneNo, i.Email);
           
        }


    }

}  