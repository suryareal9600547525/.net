﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;




namespace Lab13_6
{
    public class Program
    {
      
            public static void Main(string[] args)
            {
                FileStream stream = new FileStream(@"D:\NewFile.txt", FileMode.OpenOrCreate);
                BinaryFormatter formatter = new BinaryFormatter();

                Student s = new Student(021, "xxx", "yyy", "zzz");

                formatter.Serialize(stream, s);
                Console.WriteLine("021, xxx, yyy, zzz");
            stream.Close();

                Console.ReadLine();
            }
    }
}
