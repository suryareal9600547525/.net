﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_4
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            object objProductID, objProductName, objPrice, objQuantity;
            double AmountPayable;

            Console.Write("Enter the ID of product : ");
            objProductID = Console.ReadLine();
            Console.Write("\nEnter the Name of product : ");
            objProductName = Console.ReadLine();
            Console.Write("\nEnter price : ");
            objPrice = Console.ReadLine();
            Console.Write("\nEnter quantity : ");
            objQuantity = Console.ReadLine();
            //unboxing
            int ProductID = Convert.ToInt32(objProductID);
            int Quantity = Convert.ToInt32(objQuantity);
            int Price = Convert.ToInt32(objPrice);
            //
            AmountPayable = Quantity * Price;
            //
            Console.WriteLine("\n\n---------- Product Details ------- ");
            Console.WriteLine("Product ID : " + ProductID);
            Console.WriteLine("Product Name : " + objProductName.ToString());
            Console.WriteLine("Price : " + Price);
            Console.WriteLine("Quantity : " + Quantity);
            Console.WriteLine("Amount Payable : " + AmountPayable);

            Console.ReadKey();
        }

    }

}
