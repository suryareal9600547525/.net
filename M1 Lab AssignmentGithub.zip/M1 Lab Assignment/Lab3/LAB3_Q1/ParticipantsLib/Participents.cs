﻿using System;

namespace ParticipantsLib
{
    public class Participents
    {
        int EmpId;
        int FMarks;
        int DMarks;
        int WMarks;
        int ObtainedMarks;
        int TotalMarks = 300;
        double Percentage;
        string Name;
        static string CName;
         

        public Participents()
        {
     
             
        }
        public Participents(int EmpId,string Name,int FMarks,int DMarks,int WMarks)
        {
            this.EmpId = EmpId;
            this.Name = Name;
            this.FMarks = FMarks;
            this.WMarks = WMarks;
            this.DMarks = DMarks;

        }
         static Participents()
        {
            CName = "Corporate Unniversity";
        }
         public void CalculateObtainedMarks()
        {
            ObtainedMarks = FMarks + DMarks + WMarks;
        }
        public void CalculatePercentage()
        {
            Percentage = Convert.ToDouble((ObtainedMarks*100)/TotalMarks);
            
        }
        public double GetPercentage()
        {
            return Percentage;
        }

    }
}
