﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_Q3
{
    class Program
    {
        static Cars objCars = new Cars();
        //static Car objCar = new Car();
        static void Main(string[] args)
        {
            int choice;
            char c;
            do
            {
                Console.WriteLine("====== Cars Portal =====");
                Console.WriteLine("Press 1 to Add Car,2 to Update Car,3 to Delete Car,4 to Search Car,5 to Get cars,6 to Exit.");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddCar();
                        break;
                    case 2:
                        UpdateCar();
                        break;
                    case 3:
                        DeleteCar();
                        break;
                    case 4:
                        SearchCar();
                        break;
                    case 5:
                        GetCars();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Do you want to Continue? press 'y' to Continue and 'n' to Exit.");
                c = Convert.ToChar(Console.ReadLine());
            } while (c=='y');
        }

        static void AddCar()
        {
            string make;
            string model;
            string year;
            int saleprice;
            Console.WriteLine("========== Enter Car Details to add============");
            Console.WriteLine("Enter make :");
            make = Console.ReadLine();
            Console.WriteLine("Enter model :");
            model = Console.ReadLine();
            Console.WriteLine("Enter year :");
            year = Console.ReadLine();
            Console.WriteLine("Enter Price :");
            saleprice = Convert.ToInt32(Console.ReadLine());
            Car objCar = new Car { Make = make, Model = model, Year = year, SalePrice = saleprice };
            objCars.AddCar(objCar);

        }
         static void UpdateCar()
        {
            string make, model;
            string year;
            int saleprice;
            Console.WriteLine("Enter Car Details to Update");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            Console.WriteLine("Enter Model :");
            model = Console.ReadLine();
            Console.WriteLine("Enter Year :");
            year = Console.ReadLine();
            Console.WriteLine("Enter sale Price:");
            saleprice = Convert.ToInt32(Console.ReadLine());
            Car objCar = new Car { Make = make, Model = model, Year = year, SalePrice = saleprice };
            objCars.UpdateCar(objCar);
        }
         static void DeleteCar()
        {
            string make;
            
            Console.WriteLine("Enter Car Details to Delete ");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            //Car objCar = objCars.DeleteCar(make);
            objCars.DeleteCar(make);
        }
         static void SearchCar()
        {
            string make;
             
            Console.WriteLine("Enter Car Details to Search ");
            Console.WriteLine("Enter Make :");
            make = Console.ReadLine();
            Car objCar = objCars.SearchCar(make);
            Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}",objCar.Make,objCar.Model,objCar.Year,objCar.SalePrice);

        }
         static void GetCars()
        {
            
            Car[] objCarArray = objCars.GetCars();
            foreach(Car objCar in objCarArray)
            {
                if (objCar != null)
                {
                    Console.WriteLine("Make : {0}, Model : {1}, Year : {2}, SalePrice :{3}", objCar.Make, objCar.Model, objCar.Year, objCar.SalePrice);
                }

            }

        }
    }
}
