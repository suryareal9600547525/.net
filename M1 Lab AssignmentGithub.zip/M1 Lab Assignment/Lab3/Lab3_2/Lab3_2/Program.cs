﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Bird b = new Bird("Eagle", 200);
            //b.Bird();
            b.fly();
            b.fly(300);
        }
    }
}
