﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    internal class Supplier
    {
        int supplierID;
        string supplierName;
        string city;
        string phoneNo;
        string email;

        internal void AcceptDetails()
        {
            Console.Write("Enter supplier ID :");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter supplier Name :");
            supplierName = Console.ReadLine();
            Console.Write("Enter the city :");
            city = Console.ReadLine();
            Console.Write("Enter phone number :");
            phoneNo = Console.ReadLine();
            Console.Write("Enter your e-mail :");
            email = Console.ReadLine();
        }

        internal void DisplayDetails()
        {
            Console.WriteLine("Supplier ID is :" + supplierID);
            Console.WriteLine("Supplier Name is :" + supplierName);
            Console.WriteLine("City :" + city);
            Console.WriteLine("Phone Number :" + phoneNo);
            Console.WriteLine("E-mail :" + email);

        }
    }
}
