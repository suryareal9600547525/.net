﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_4
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            Supplier objsup = new Supplier();
            Console.WriteLine("--------------Enter the details of the supplier-----------");
            objsup.AcceptDetails();
            Console.WriteLine("------------------details of the supplier-----------------");
            objsup.DisplayDetails();

        }
    }

}
