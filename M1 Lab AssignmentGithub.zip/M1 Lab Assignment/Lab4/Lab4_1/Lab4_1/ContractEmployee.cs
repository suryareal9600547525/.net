﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;


namespace Lab4_1
{
    public class ContractEmployee : Employee
    {
        private static double perks;
        public static Employee e1 = new Employee();


        public double PERKS
        {
            get { return perks; }
            set { perks = value; }

        }

        public ContractEmployee(int EId, string EName, string Address, string City, string Department, int Salary)
        {
            e1 = new Employee(EId, EName, Address, Department, City, Salary);

        }
        public double getSalary()
        {

            double sal = e1.Salary + perks;
            return sal;
        }


    }
}
