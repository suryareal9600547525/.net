﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;

namespace Lab4_1
{
    class PermanentEmployee : Employee
    {
        private static int NoOfLeaves;
        private static int Pf;
        public static Employee e1 = new Employee();
        public int NOOFLEAVES
        {
            get { return NoOfLeaves; }
            set { NoOfLeaves = value; }
        }
        public int PF
        {
            get { return Pf; }
            set { Pf = value; }
        }
        public PermanentEmployee(int EId, string EName, string Address, string City, string Department, int Salary)
        {
            e1 = new Employee(EId, EName, Address, Department, City, Salary);

        }

        public double getSalary()
        {

            double sal = e1.salary - Pf;
            return sal;
        }
    }
}
