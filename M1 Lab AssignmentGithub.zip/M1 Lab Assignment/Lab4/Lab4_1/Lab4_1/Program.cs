﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;


namespace Lab4_1
{
    class Program
    {
        internal static int EId;
        internal static string EName;
        internal static string Address;
        internal static string City;
        internal static string Department;
        internal static int Salary;
        static void Main(string[] args)
        {

            Console.WriteLine("Employee type as contract or permanent.");
            Console.WriteLine("Press 1 for Contract emp and 2 for Permanent employee");
            int ch = Convert.ToInt32(Console.ReadLine());

            switch (ch)
            {
                case 1:
                    Console.WriteLine("Enter contract Employee Details");
                    setContEmpDetails();
                    break;

                case 2:
                    Console.WriteLine("Enter Permanent employee details:-");
                    setPermEmpDetails();
                    break;

                default:
                    Console.WriteLine("Inavlid Input");
                    break;
            }
            Console.ReadLine();

        }

        internal static void setContEmpDetails()
        {
            Console.WriteLine("Enter id:");
            EId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            EName = Console.ReadLine();
            Console.WriteLine("Enter address:");
            Address = Console.ReadLine();
            Console.WriteLine("Enter City:");
            City = Console.ReadLine();
            Console.WriteLine("Enter Dept:");
            Department = Console.ReadLine();
            Console.WriteLine("Enter base Salary:");
            Salary = Convert.ToInt32(Console.ReadLine());

            ContractEmployee CE = new ContractEmployee(EId, EName, Address, City, Department, Salary);
            Console.WriteLine("Enter Perks amount:");
            CE.PERKS = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Contract employees gross salary =" + CE.getSalary());



        }
        internal static void setPermEmpDetails()
        {
            Console.WriteLine("Enter id:");
            EId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            EName = Console.ReadLine();
            Console.WriteLine("Enter address:");
            Address = Console.ReadLine();
            Console.WriteLine("Enter City:");
            City = Console.ReadLine();
            Console.WriteLine("Enter Dept:");
            Department = Console.ReadLine();
            Console.WriteLine("Enter base Salary:");
            Salary = Convert.ToInt32(Console.ReadLine());

            PermanentEmployee PE = new PermanentEmployee(EId, EName, Address, City, Department, Salary);

            Console.WriteLine("Enter PF amount:");
            PE.PF = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Contract employees gross salary =" + PE.getSalary());
        }
    }
}
