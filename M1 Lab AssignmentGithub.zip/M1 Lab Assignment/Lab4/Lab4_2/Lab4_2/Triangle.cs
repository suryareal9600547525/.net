﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_2
{
    class Triangle : Shape
    {
        public override void WhoamI()
        {
            Console.WriteLine("I m Triangle");
        }
    }
}
