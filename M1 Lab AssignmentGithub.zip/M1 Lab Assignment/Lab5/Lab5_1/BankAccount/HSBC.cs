﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    public class HSBC : BankAccount
    {
        public override bool Withdraw(double amount)
        {
            //throw new NotImplementedException();

            if (balance - amount >= 5000)
            {
                balance = balance - amount;
                return true;
                //Console.WriteLine("Withdraw successful");
            }
            return false;
        }


        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            //throw new NotImplementedException();
            
            if (Balance - amount >= 5000)
            {
                Withdraw(amount);
                toAccount.Deposit(amount);
                
                return true;
            }
            return false;          
        }

        public void AccountType( BankAccountTypeEnum bankAccountTypeEnum)
        {
            accountType = bankAccountTypeEnum;
        }

        public override void CalculateInterest()
        {
            //throw new NotImplementedException();
            Console.WriteLine("HSBC RATE OF INTEREST ON YOUR " + accountType.ToString().ToUpper() + " ACCCOUNT " + Balance * 1 * 0.05);
        }
    }
    
}
