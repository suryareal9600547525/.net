﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_7
{
    class Program
    {
        static List<Contact> obj = new List<Contact>();
        static void Main(string[] args)
        {
            int choice;
            char conti;
            do
            {
                Console.WriteLine("\n\n1 to add,2 to display contact , 3 to edit ,4 to show all contacts.");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                       
                        AddContact();
                        break;
                    case 2:
                        DisplayContact();
                        break;
                    case 3:
                        EditContact();
                        break;
                    case 4:
                        ShowAllContacts();
                        break;
                    case 5:
                        
                        break;
                    default:
                        Console.WriteLine("please select a valid option.");
                        break;

                }
                Console.WriteLine("\n\ndo you wish to continue 'y' or 'n'.");
                conti = Convert.ToChar(Console.ReadLine());
            } while (conti == 'y');
            Console.ReadKey();
        }
        static void AddContact()
        {
            Console.WriteLine("-------------Add contact------------------\n\n");
            Contact contact1 = new Contact();
            //{
            //    ContactNo = 2,
            //    ContactName = "Shaili",
            //    CellNo = "I D K"
            //};

            Console.WriteLine("Enter Contact No:");
            contact1.ContactNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Contact Name:");
            contact1.ContactName = Console.ReadLine();
            Console.WriteLine("Enter Cell no:");
            contact1.CellNo = Console.ReadLine();


            obj.Add(contact1);
            
            Console.WriteLine("Record Inserted");

        }

        static void DisplayContact()
        {
            Console.WriteLine("-------------search contact------------------\n\n");
            int searchCno;
            
            Console.WriteLine("Enter Contact no you wwant to search:");
            searchCno = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < obj.Count; i++)
            {
                
                if (obj[i].ContactNo == searchCno)
                {

                    Console.WriteLine("Contact No:{0}\tContact Name:{1}\tCell no:{2}\n", obj[i].ContactNo, obj[i].ContactName, obj[i].CellNo);

                }
            }
        }

        static void EditContact()
        {
            Console.WriteLine("-------------Update contact------------------\n\n");
            int updtCno;

            Console.WriteLine("Enter Contact no you want to update:");
            updtCno = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < obj.Count; i++)
            {

                if (obj[i].ContactNo == updtCno)
                {
                    Console.WriteLine("Update Contact Name:");
                    obj[i].ContactName = Console.ReadLine();
                    Console.WriteLine("Update Cell no :");
                    obj[i].CellNo = Console.ReadLine();
                }
                Console.WriteLine("Record Updated");
            }

        }

        static void ShowAllContacts()
        {
            Console.WriteLine("-------------Show All contact------------------\n\n");
            foreach ( Contact c in obj)
            {
                Console.WriteLine("Contact No:{0}\tContact Name:{1}\tCell no:{2}",c.ContactNo,c.ContactName,c.CellNo);
            }
        }

    }
}
