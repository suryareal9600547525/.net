﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace Lab13_6
{
        [Serializable]
        class Student:ISerializable
        {
            public int rollno { get; set; }
            public string name { get; set; }
            public string city { get; set; }
            public string degree { get; set; }

            public Student(int Rollno, string Name, string City, string Degree)
            {
                this.rollno = Rollno;
                this.name = Name;
                this.city = City;
                this.degree = Degree;
            }
            public void GetObjectData(SerializationInfo info, StreamingContext context)

            {

                info.AddValue("rollno", this.rollno);
                info.AddValue("name", this.name);
                info.AddValue("city", this.city);
                info.AddValue("degree", this.degree);

            }
        }
    }



