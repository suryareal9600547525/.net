﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_1
{
    struct Number
    {
        public int number;

        public Number(int num)
        {
            number = num;
        }

        public int Square()
        {
            int result;
            result = number * number;
            return result;
        }

        public int Cube()
        {
            int result;
            result = number * number * number;
            return result;
        }
    }
}
