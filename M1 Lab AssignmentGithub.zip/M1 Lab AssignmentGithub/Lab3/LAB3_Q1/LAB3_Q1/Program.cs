﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                bool flag = true;
                Console.WriteLine("Enter Emp ID :");
                int empid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Emp Name :");
                string name = Console.ReadLine();
                Console.WriteLine("Enter FoundationMarks :");
                int fmarks = Convert.ToInt32(Console.ReadLine());
                if (fmarks < 0 || fmarks > 100) { flag = false; }
                Console.WriteLine("Enter WebBasicMarks, :");
                int wmarks = Convert.ToInt32(Console.ReadLine());
                if (wmarks < 0 || wmarks > 100) { flag = false; }
                Console.WriteLine("Enter DotNetMarks :");
                int dmarks = Convert.ToInt32(Console.ReadLine());
                if (dmarks < 0 || dmarks > 100) { flag = false; }
                ParticipantsLib.Participents objParticipents = new ParticipantsLib.Participents(empid, name, fmarks, dmarks, wmarks);
                if (flag == false)
                {
                    Console.WriteLine("please Enter valid Marks.");
                }
                else
                {
                    objParticipents.CalculateObtainedMarks();
                    objParticipents.CalculatePercentage();
                    double Percentage = objParticipents.GetPercentage();
                    Console.WriteLine("The Percentage of {0} is {1} ", name, Percentage);
                }
                Console.WriteLine("Press 'y' to Continue and 'n' to Exit.");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y');
            
        }
    }
}
