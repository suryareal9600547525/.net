﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_Q4
{
    class SupplierTest
    {
        
        
        static void Main(string[] args)
        {
            
            char choose;
            do
            {
                Supplier objSupplier = new Supplier();
                Console.WriteLine("===Enter Supplier Details===");
                objSupplier.AcceptDetails();
                Console.WriteLine("===Display Supplier Details===");
                objSupplier.DisplayDetails();
                Console.WriteLine("press y for continue n for exit");
                choose = Convert.ToChar(Console.ReadLine());
            }
            while (choose == 'y');
 
        }
    }
}
