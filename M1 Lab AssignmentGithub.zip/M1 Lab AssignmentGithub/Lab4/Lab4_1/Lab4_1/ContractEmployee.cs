﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;


namespace Lab4_1
{
    public class ContractEmployee : Employee
    {
        int perks;
        public int Perks
        {
            get
            {
                return perks;
            }
            set
            {
                perks=value ;
            }
        }

        public override int GetSalary()
       
        {
            Console.WriteLine("Enter salary");
           Salary= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Perks");
            perks = Convert.ToInt32(Console.ReadLine());
            Salary = Salary + Perks;
            return Salary;

            
        }


    }
}

