﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;

namespace Lab4_1
{
    class PermanentEmployee : Employee
    {
        int leaves;
        public int Leaves
        {
            get
            { 
                return leaves;
            }
            set
            {
                leaves = value;
            }
        }
        int providentfund;
        public int ProvidentFund
        {
            get
            {
                return providentfund;
            }
            set
            {
                 providentfund = value;
            }
            
        }

        public override int GetSalary()
        {
            Console.WriteLine("Enter leaves");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Salary");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter ProvidentFund");
            ProvidentFund = Convert.ToInt32(Console.ReadLine());
            Salary = (Salary - ProvidentFund);


            
            return Salary;
        }


    }
}
