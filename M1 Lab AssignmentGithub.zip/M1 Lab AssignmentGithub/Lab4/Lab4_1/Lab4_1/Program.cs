﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_1
{
    class Program
    {
        static void Main(string[] args)
        {
            char y;
            int choose;
            do
            {
                Console.WriteLine("enter the option,1 for ContractEmployee,2 for PermanentEmployee");
                choose = Convert.ToInt32(Console.ReadLine());
                switch (choose)
                {

                    case 1:
                        Console.WriteLine("ContractEmployee salary Details");
                        ContractEmployee objConEmp = new ContractEmployee();


                        Console.WriteLine(objConEmp.GetSalary());
                        break;

                    case 2:
                        

                        Console.WriteLine("PermanentEmployee Salary Details");
                        PermanentEmployee objPerEmp = new PermanentEmployee();

                        Console.WriteLine(objPerEmp.GetSalary());
                        break;

                }
                Console.WriteLine("do you want to continue, y for continue,n for exit");
               y = Convert.ToChar(Console.ReadLine());
            } while (y == 'y');
        }
    }
}