﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Xml;


namespace lab_8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnshowtitles.IsEnabled = false;
        }

        private void btnload_Click(object sender, EventArgs e)
        {

            XmlDataDocument doc = new XmlDataDocument();
            // Load the schema file.
            doc.DataSet.ReadXmlSchema("BookStore.xsd");
            // Load the XML data.
            XmlTextReader reader = new XmlTextReader("Books.xml");
            // Move the reader to the root node and load xml data
            reader.MoveToContent();
            doc.Load(reader);
            // Update the price on the first book using the DataSet methods.
            // Working with data as relational model
            DataTable book = doc.DataSet.Tables["book"];
            book.Rows[0]["price"] = "101.95";
            grdBook.ItemsSource =new DataView( doc.DataSet.Tables["book"]);

            btnload.IsEnabled = false;
            btnshowtitles.IsEnabled = true;
        }
        private void btnshowtitles_Click(object sender, EventArgs e)
        {
             XmlDataDocument doc = new XmlDataDocument();
            // Get the node list of titles of type ‘novel’
            // Working with data as heirarchical model
            //XmlNamespaceManager oManager = new XmlNamespaceManager(new NameTable());
            //oManager.AddNamespace("ns", "bookstore:samples");
            //XmlNodeList nodelist = doc.SelectNodes("/ns:bookstore/ns:book/@genre[1]", oManager);
            //XmlNodeList nodelist = doc.SelectNodes("//book[contains(title,Pride And Prejudice)]");
            //"/bookstore/book/@bk:ISBN", nsmgr
            doc.Load("Books.xml");
            XmlNodeList nodelist = doc.SelectNodes("/bookstore/book");
            string msg = "";
            foreach (XmlNode node in nodelist)
            {
                string title = node["title"].InnerText;
                msg += title + "\n";

            }
            if (msg != "")
            {
                MessageBox.Show(msg);
            }
            else { MessageBox.Show("Null"); }
        }
    }
}