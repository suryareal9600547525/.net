﻿create schema AB_189774
create table  AB_189774.Book
(
Title varchar(150) primary key not null,
author varchar(150) not null,
price money not null
)
insert into AB_189774.Book values('The Handmaid Tale','Margaret Atwood', '19.95')
insert into AB_189774.Book values('The Voyager Tale','David W. Swift', '29.95')
insert into AB_189774.Book values('The Robotic Man','Isaac Asimov', '25.95')
insert into AB_189774.Book values('Pride And Prejudice','Jane Austen', '24.95')

select * from  AB_189774.Book
drop table AB_189774.Book
