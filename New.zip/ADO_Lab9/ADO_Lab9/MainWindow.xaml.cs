﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;

namespace ADO_Lab9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection nwcon = null;
        SqlTransaction tr = null;
        public MainWindow()
        {
            InitializeComponent();
            //string constr = ConfigurationManager.ConnectionStrings[@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser"].ConnectionString;
            nwcon = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            //
        }

        public void btnsave_Click(object sender, RoutedEventArgs e)
        {




            if (!txttrtype.Text.ToLower().Equals("w") && !txttrtype.Text.ToLower().Equals("d"))
            {
                MessageBox.Show("Transaction type should be 'W' or 'D' ");
                return;
            }
            nwcon.Open();
            tr = nwcon.BeginTransaction();
            try
            {
                UpdateBal(txtacno.Text, txttrtype.Text, double.Parse(txtamt.Text));
                SaveStatement(txtacno.Text, txttrtype.Text, double.Parse(txtamt.Text));
                MessageBox.Show("Transaction Saved");
                tr.Commit();
            }
            catch (SqlException sqlex)
            {
                tr.Rollback();
                MessageBox.Show(sqlex.Message);
            }
            finally
            {
                tr = null;
                nwcon.Close();
            }
        }


        public void TransactionDemo_Load(object sender, EventArgs e)
        {
        }


        public void UpdateBal(string accno, string trtype, double tranamt)
        {
            SqlCommand cmd_upd = new SqlCommand
            ("update  [DLAB189752].[accountmaster] set accbal = accbal + @amt where accno = @accno", nwcon);
            cmd_upd.Transaction = tr;
            cmd_upd.Parameters.Add("@amt", System.Data.SqlDbType.Decimal);
            cmd_upd.Parameters.Add("@accno", System.Data.SqlDbType.Int, 4);
            if (trtype.ToLower().Equals("w"))
                cmd_upd.Parameters["@amt"].Value = -1 * tranamt;
            else
                cmd_upd.Parameters["@amt"].Value = tranamt;
            cmd_upd.Parameters["@accno"].Value = accno;
            cmd_upd.ExecuteNonQuery();
        }
        private void SaveStatement(string accno, string trtype, double tranamt)
        {
            //string constr = ConfigurationManager.ConnectionStrings[@"Data Source = ndamssql\sqlilearn; Initial Catalog = Training_18Jul19_Pune; Persist Security Info = True; User ID = sqluser; Password = sqluser"].ConnectionString;
            SqlCommand cmd_ins = new SqlCommand("insert into [DLAB189752].[accountTransaction] values(@accno,@trtype,@tramt)", nwcon);
            cmd_ins.Transaction = tr;
            cmd_ins.Parameters.Add("@tramt", System.Data.SqlDbType.Money, 4);
            cmd_ins.Parameters.Add("@accno", System.Data.SqlDbType.Int, 4);
            cmd_ins.Parameters.Add("@trtype", System.Data.SqlDbType.VarChar, 1);
            cmd_ins.Parameters["@accno"].Value = accno;
            cmd_ins.Parameters["@tramt"].Value = tranamt;
            cmd_ins.Parameters["@trtype"].Value = trtype;
            cmd_ins.ExecuteNonQuery();
        }


    }
}