﻿CREATE TABLE [DLAB189752].[accountmaster] (
    [accno]   INT             NOT NULL,
    [accname] VARCHAR (30)    NULL,
    [accbal]  NUMERIC (10, 2) NULL,
    PRIMARY KEY CLUSTERED ([accno] ASC),
    CHECK ([accbal]>=(5000))
);
