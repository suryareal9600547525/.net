﻿CREATE TABLE [DLAB189752].[accountTransaction] (
    [tranno] INT             IDENTITY (1, 1) NOT NULL,
    [accno]  INT             NULL,
    [trtype] VARCHAR (1)     NULL,
    [tramt]  NUMERIC (10, 2) NULL,
    PRIMARY KEY CLUSTERED ([tranno] ASC),
    FOREIGN KEY ([accno]) REFERENCES [190513].[accmaster] ([accno]),
    CHECK ([tramt]>=(500))
);