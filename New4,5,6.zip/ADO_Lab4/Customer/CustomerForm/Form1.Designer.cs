﻿namespace CustomerForm
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.cmbcolumnlist = new System.Windows.Forms.ComboBox();
            this.btnshow = new System.Windows.Forms.Button();
            this.grdcustomers = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.grdcustomers)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer City";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Sort Details on";
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(140, 40);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(121, 20);
            this.txtcity.TabIndex = 2;
            // 
            // cmbcolumnlist
            // 
            this.cmbcolumnlist.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcolumnlist.FormattingEnabled = true;
            this.cmbcolumnlist.Items.AddRange(new object[] {
            "City",
            "CreditLimit",
            "CustomerName"});
            this.cmbcolumnlist.Location = new System.Drawing.Point(140, 99);
            this.cmbcolumnlist.Name = "cmbcolumnlist";
            this.cmbcolumnlist.Size = new System.Drawing.Size(121, 21);
            this.cmbcolumnlist.TabIndex = 3;
            this.cmbcolumnlist.SelectedIndexChanged += new System.EventHandler(this.cmbcolumnlist_SelectedIndexChanged);
            // 
            // btnshow
            // 
            this.btnshow.Location = new System.Drawing.Point(359, 42);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(75, 23);
            this.btnshow.TabIndex = 4;
            this.btnshow.Text = "Show";
            this.btnshow.UseVisualStyleBackColor = true;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // grdcustomers
            // 
            this.grdcustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdcustomers.Location = new System.Drawing.Point(58, 146);
            this.grdcustomers.Name = "grdcustomers";
            this.grdcustomers.Size = new System.Drawing.Size(697, 274);
            this.grdcustomers.TabIndex = 5;
            this.grdcustomers.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdcustomers_CellContentClick);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grdcustomers);
            this.Controls.Add(this.btnshow);
            this.Controls.Add(this.cmbcolumnlist);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CustomerForm";
            this.Text = "CustomerForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdcustomers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.ComboBox cmbcolumnlist;
        private System.Windows.Forms.Button btnshow;
        private System.Windows.Forms.DataGridView grdcustomers;
    }
}

