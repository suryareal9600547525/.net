﻿CREATE TABLE [DLAB189752].[CustomerADOLab4] (
    [customerid]   INT             NOT NULL,
    [customername] VARCHAR (50)    NULL,
    [city]         VARCHAR (30)    NULL,
    [creditlimit]  NUMERIC (10, 2) NULL,
    PRIMARY KEY CLUSTERED ([customerid] ASC)
);


select * from [DLAB189752].[CustomerADOLab4] 

insert into  [DLAB189752].[CustomerADOLab4] values(1,'aaa','pune',15000)
insert into  [DLAB189752].[CustomerADOLab4] values(2,'abc','chennai',12000)
insert into  [DLAB189752].[CustomerADOLab4] values(3,'ccc','Mumbai',20000)
insert into  [DLAB189752].[CustomerADOLab4] values(4,'zzz','pune',12000)
insert into  [DLAB189752].[CustomerADOLab4] values(5,'mmm','bangalore',15000)