﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SupplierForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        DataSet ds;
        SqlDataAdapter da;
        private void Form1_Load(object sender, EventArgs e)
        {
           
            con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;User ID=sqluser;Password=sqluser");
            con.Open();
            ds = new DataSet();
            da = new SqlDataAdapter("select * from [DLAB189752].[SupplierADOLab4] ", con);
            da.Fill(ds, "cust");
            dataGridView1.DataSource = ds.Tables["cust"];
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            ds.Tables["cust"].DefaultView.Sort = comboBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            ds.Tables["cust"].DefaultView.RowFilter = "City like'" + textBox1.Text + "'";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            SqlCommand dr = new SqlCommand("update [DLAB189752].[SupplierADOLab4] set SupplierName=@sname,City=@scity,ContactNo=@snum,CreditBalance=@scb where SupplierId=@sid", con);
            dr.Parameters.AddWithValue("@sid", textBox2.Text);
            dr.Parameters.AddWithValue("@sname", textBox3.Text);
            dr.Parameters.AddWithValue("@scity", textBox4.Text);
            dr.Parameters.AddWithValue("@snum", textBox5.Text);
            dr.Parameters.AddWithValue("@scb", textBox6.Text);
            dr.ExecuteNonQuery();
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            ds = new DataSet();
            da = new SqlDataAdapter("select * from D_189782.Supplier", con);
            da.Fill(ds, "cust");
            dataGridView1.DataSource = ds.Tables["cust"];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
           
        }
    }
    
}
