﻿CREATE TABLE [DLAB189752].[SupplierADOLab4] (
    [SupplierId]    INT          NOT NULL,
    [SupplierName]  VARCHAR (50) NULL,
    [City]          VARCHAR (50) NULL,
    [ContactNo]     VARCHAR (50) NULL,
    [CreditBalance] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([SupplierId] ASC)
);


insert into [DLAB189752].[SupplierADOLab4] values(1,'xxx','pune',9876543210,15000)

insert into [DLAB189752].[SupplierADOLab4] values(2,'yyy','Mumbai',9871143210,18000)