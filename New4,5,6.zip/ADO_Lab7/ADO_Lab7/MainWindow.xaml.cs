﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ADO_Lab7
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter daprod;
        DataSet dsprod;
        SqlCommandBuilder cb;
        public MainWindow()
        {
            InitializeComponent();

            con = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_18Jul19_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser");
            con.Open();
            daprod = new SqlDataAdapter("select * from [DLAB189752].[NewProductADOLab6] ", con);
            cb = new SqlCommandBuilder(daprod);
            dsprod = new DataSet();
        }





        private void BtnSaveTodatabase_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                daprod.Update(dsprod.Tables["prod"]);
                MessageBox.Show("Changes Saved");

            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void BtnLoadFromXML_Click_1(object sender, RoutedEventArgs e)
        {
            dsprod.ReadXmlSchema("products.xsd");
            dsprod.ReadXml("products.xml", XmlReadMode.DiffGram);
            grdproducts.DataContext = dsprod.Tables["prod"].DefaultView;

        }

        private void BtnSaveToXML_Click(object sender, RoutedEventArgs e)
        {

            //Save Schema and Data into xml file
            dsprod.WriteXmlSchema("products.xsd");
            dsprod.WriteXml("products.xml", XmlWriteMode.DiffGram);
            MessageBox.Show("Data saved to disk");
        }

        private void BtnLoadFromDatabase_Click_1(object sender, RoutedEventArgs e)
        {
            daprod.Fill(dsprod, "prod");
            DataTable dt = dsprod.Tables["prod"];
            grdproducts.ItemsSource = dt.DefaultView;
            btnLoadFromDatabase.IsEnabled = false;

        }
    }
}