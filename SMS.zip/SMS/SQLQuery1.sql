﻿exec sp_help 's189820.Student'
select * from s189820.Student