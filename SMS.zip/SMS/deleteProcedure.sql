﻿CREATE PROCEDURE [s189820].[USP_DeleteBy]
	@rNo int

AS
	Delete from [s189820].[Student] where Rollno=@rNo
RETURN 0
