﻿CREATE PROCEDURE [s189820].[SelectAll]

AS
	select * from s189820.Student
RETURN 0
