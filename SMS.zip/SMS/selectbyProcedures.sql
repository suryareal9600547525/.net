﻿alter PROCEDURE [s189820].[USP_SelectBy]
	@rNo int
    
AS
	select * from s189820.Student  where rollNo=@rNo
RETURN 0

drop PROCEDURE [s189820].[USP_SelectBy]