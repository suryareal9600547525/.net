﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using SMS_BAL;
using SMS_Entities;
using SMS_Exceptions;

namespace SMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentBAL bal = null;
        public MainWindow()
        {       
            InitializeComponent();
            bal = new StudentBAL();
            Populate();
        }
        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txtFullName.Text == null | txtFullName.Text == string.Empty | txtFullName.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Full Name is Empty!" + Environment.NewLine);
            }
            if (txtDOB.Text == null | txtDOB.Text == string.Empty | txtDOB.Text.Length < 1)
            {
                isValid = false;
                sb.Append("DOB is Empty!" + Environment.NewLine);
            }
            if (txtMobNo.Text == null | txtMobNo.Text == string.Empty | txtMobNo.Text.Length < 1 && txtMobNo.Text.Length>11)
            {
                isValid = false;
                sb.Append("Mobile-No is Empty!" + Environment.NewLine);
            }
            if (txtEmail.Text == null | txtEmail.Text == string.Empty | txtEmail.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Email is Empty!" + Environment.NewLine);
            }
            //if (state == null || state == string.Empty)
            //{
            //    sts = false;
            //    sb.Append("State is Empty!" + Environment.NewLine);
            //}
            //if (gender == null || gender == string.Empty)
            //{
            //    isValid = false;
            //    sb.Append("Gender is Empty!" + Environment.NewLine);
            //}
            txtAddress.SelectAll();
            if (txtAddress.Selection.Text.Length <= 2)
            {
                isValid = false;
                sb.Append("Address is Empty!" + Environment.NewLine);
            }

            if (!isValid)
            {
                throw new SMSException(sb.ToString());
            }

            return isValid;
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string gender = string.Empty;
                if (rbMale.IsChecked == true)
                    gender = rbMale.Content.ToString();
                else if (rbFemale.IsChecked == true)
                    gender = rbFemale.Content.ToString();
                txtAddress.SelectAll();

                if (ValidateUI())
                {
                    Student student = new Student
                    {
                        FullName = txtFullName.Text,
                        DOB = (DateTime)txtDOB.SelectedDate,
                        MobileNo = txtMobNo.Text,
                        Email = txtEmail.Text,
                        State = ((ListBoxItem)lbState.SelectedItem).Content.ToString()
                    };

                    student.Address = txtAddress.Selection.Text;
                    student.Gender = gender;
                  
                    int rollNo=bal.Add(student);
                    MessageBox.Show("Record Instered Successfully ! and student roll number is:" + rollNo);
                    Populate();
                }
                else
                {
                    MessageBox.Show("Validation Error!");
                }
            }
            catch (SMSException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }
        private void Populate()
        {
            try
            {
                List<Student> studs = bal.GetAll();
                dgStudents.ItemsSource = studs;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

    }
}
