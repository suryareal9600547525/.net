﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

using SMS_Entities;

namespace SMS_DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);        // @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Amol_132419;Integrated Security=True"
        }
        public int Insert(Student student)
        {
            int rollNo;
            try
            {
                cmd = new SqlCommand("s189820.USP_InsertStudent", cn);                           //cmd = new SqlCommand("insert into Student values(@fullName,@gender,@dob,@mobNo,@email,@state,@add)", cn);
                SqlParameter rNo = new SqlParameter("@rollNo", System.Data.SqlDbType.Int);
                rNo.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(rNo);

                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@state", student.State);
                cmd.Parameters.AddWithValue("@add", student.Address);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                cmd.ExecuteNonQuery();
                rollNo = Convert.ToInt32(cmd.Parameters["@rollNo"].Value);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return rollNo;
        }


        public void Update(Student student)
        {
            try
            {
                cmd = new SqlCommand("s189820.USP_UpdateStudent", cn); //update s189820.Student set Name = @fullName, Gender = @gender, DOB = @dob, Mobile = @mobNo, Email = @email, Address = @add, State = @state where RollNo = @rollNo
                cmd.Parameters.AddWithValue("@rollNo", student.RollNo);
                cmd.Parameters.AddWithValue("@fullName", student.FullName);
                cmd.Parameters.AddWithValue("@gender", student.Gender);
                cmd.Parameters.AddWithValue("@dob", student.DOB);
                cmd.Parameters.AddWithValue("@mobNo", student.MobileNo);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@add", student.Address);
                cmd.Parameters.AddWithValue("@state", student.State);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public Student SelectBy(int rollNo)
        {
            Student student = new Student();
            try
            {
                cmd = new SqlCommand("s189820.USP_SelectBy", cn);            //select* from s189820.Student where rollNo = @rNo

                cmd.Parameters.AddWithValue("@rNo", rollNo);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.Read()) //
                {
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.State = dr[6].ToString();
                    student.Address = dr[7].ToString();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return student;
        }

        public List<Student> SelectAll()
        {
            List<Student> students = new List<Student>();
            try
            {
                cmd = new SqlCommand("s189820.SelectAll", cn);  //select* from s189820.Student
                cn.Open();
                dr = cmd.ExecuteReader();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                while (dr.Read()) //
                {
                    Student student = new Student();
                    student.RollNo = Convert.ToInt32(dr[0]);
                    student.FullName = dr[1].ToString();
                    student.Gender = dr[2].ToString();
                    student.DOB = Convert.ToDateTime(dr[3]);
                    student.MobileNo = dr[4].ToString();
                    student.Email = dr[5].ToString();
                    student.State = dr[6].ToString();
                    student.Address = dr[7].ToString();
                    students.Add(student);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return students;
        }
        public void DeleteBy(int rollno)
        {
            try
            {
                cmd = new SqlCommand("s189820.USP_DeleteBy", cn); //Delete from [s189820].[Student] where Rollno=@rNo
                cmd.Parameters.AddWithValue("@rNo", rollno);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

        }
    }
}


