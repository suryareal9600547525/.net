﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--drop PROCEDURE [s189820].[USP_DeleteBy]   

 --CREATE PROCEDURE [s189820].[USP_DeleteBy]

 CREATE PROCEDURE [s189820].[USP_DeleteBy]              
	@rNo int

AS
begin
	if(@rNo is null OR @rNo <0)
		Begin 
			Raiserror ('student id cannot be null or empty',1,1)
		end

		Else
		
			Begin
			if exists (select @rNo from [s189820].[Student] where RollNo = @rNo  ) 
			Begin
						delete from [s189820].[Student] where RollNo = @rNo 
			End
		
			Else
			Begin
					RaisError('Student ID not Exists',1,1)
			end
		end
	end


RETURN 0









