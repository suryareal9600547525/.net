﻿CREATE PROCEDURE [s189820].[USP_InsertStudent]
	@rollNo int out,
	@fullName varchar(30),
	@gender varchar(5),
	@dob date,
	@mobNo varchar(10),
	@email varchar(10),
	@state varchar(20),
	@add varchar(100)
AS
insert into s189820.Student values(@fullName,@gender,@dob,@mobNo,@email,@state,@add)
set @rollNo=SCOPE_IDENTITY()
RETURN 0
