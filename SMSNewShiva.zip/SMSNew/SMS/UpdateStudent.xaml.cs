﻿using SMS_BAL;
using SMS_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SMS
{
    /// <summary>
    /// Interaction logic for UpdateStudent.xaml
    /// </summary>
    public partial class UpdateStudent : Window
    {

        //try
        //{

        //}
        //catch(Exception ex1)
        //{
        //    MessageBox.Show(ex1.Message);
        //}

        StudentBAL bal = new StudentBAL();
        public UpdateStudent()
        {
            InitializeComponent();
            Populate();

        }

        private bool ValidateUI()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (txtRollNo.Text == null | txtRollNo.Text == string.Empty | txtRollNo.Text.Length < 1)
            {
                isValid = false;
                sb.Append("RollNo is Empty!" + Environment.NewLine);
            }
            if (txtFullName.Text == null | txtFullName.Text == string.Empty | txtFullName.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Full Name is Empty!" + Environment.NewLine);
            }
            if (txtDOB.Text == null | txtDOB.Text == string.Empty | txtDOB.Text.Length < 1)
            {
                isValid = false;
                sb.Append("DOB is Empty!" + Environment.NewLine);
            }
            if (txtMobNo.Text == null | txtMobNo.Text == string.Empty | txtMobNo.Text.Length < 1 && txtMobNo.Text.Length > 11)
            {
                isValid = false;
                sb.Append("Mobile-No is Empty!" + Environment.NewLine);
            }
            if (txtEmail.Text == null | txtEmail.Text == string.Empty | txtEmail.Text.Length < 1)
            {
                isValid = false;
                sb.Append("Email is Empty!" + Environment.NewLine);
            }
            //if (state == null || state == string.Empty)
            //{
            //    sts = false;
            //    sb.Append("State is Empty!" + Environment.NewLine);
            //}
            //if (gender == null || gender == string.Empty)
            //{
            //    isValid = false;
            //    sb.Append("Gender is Empty!" + Environment.NewLine);
            //}
            txtAddress.SelectAll();
            if (txtAddress.Selection.Text.Length <= 2)
            {
                isValid = false;
                sb.Append("Address is Empty!" + Environment.NewLine);
            }

            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }


        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int rollNo = int.Parse(txtRollNo.Text);
                Student student = bal.GetBy(rollNo);
                txtRollNo.Text = student.RollNo.ToString();
                txtFullName.Text = student.FullName;
                if( student.Gender == "Male")
                {
                    rbMale.IsChecked = true;
                }
                else if (student.Gender == "Female")
                {
                    rbFemale.IsChecked = true;
                }
                txtDOB.Text = student.DOB.ToString();
                txtMobNo.Text = student.MobileNo;
                txtEmail.Text = student.Email;
                foreach (ListBoxItem lbi in lbState.Items)
                {
                    if (lbi.Content.ToString() == student.State)
                        lbi.IsSelected = true;
                }
                txtAddress.Document.Blocks.Clear();
                txtAddress.Document.Blocks.Add(new Paragraph(new Run(student.Address)));
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }

            
        }

     

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateUI())
                {
                    Student student = new Student();

                    student.RollNo = Convert.ToInt32(txtRollNo.Text);
                    student.FullName = txtFullName.Text;
                    student.Gender = rbMale.IsChecked == true ? rbMale.Content.ToString() : rbFemale.Content.ToString();
                    student.DOB = Convert.ToDateTime(txtDOB.SelectedDate);
                    student.MobileNo = txtMobNo.Text;
                    student.Email = txtEmail.Text;
                    student.State = ((ListBoxItem)lbState.SelectedItem).Content.ToString();
                    txtAddress.SelectAll();
                    student.Address = txtAddress.Selection.Text;

                    bal.Modify(student);
                    MessageBox.Show("record updated successfully");
                    Populate();
                }
                else
                {
                    MessageBox.Show("Validation Error!");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                 bal.DeleteBy(Convert.ToInt32(txtRollNo.Text));
                    MessageBox.Show("deleted successfully");
                    Populate();
                }
               
     

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Populate()
        {
            try
            {
                List<Student> studs = bal.GetAll();
                dgStudents.ItemsSource = studs;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

    }
}
