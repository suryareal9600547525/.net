﻿CREATE PROCEDURE [dbo].[USP.InsertStudent1]
	@rollNo int out,
	@fullName varchar(30),
	@gender varchar(5),
	@dob date,
	@mobNo varchar(10),
	@email varchar(30),
	@state varchar(10),
	@add varchar(30)
AS
	insert into s189820.Student values(@fullName,@gender,@dob,@mobNo,@email,@state,@add)
	set @rollNo=SCOPE_IDENTITY()
RETURN 0
