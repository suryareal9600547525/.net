﻿
create PROCEDURE [s189820].[USP_InsertStudent]
	@rollNo int out,
	@fullName varchar(30),
	@gender varchar(5),
	@dob date,
	@mobNo varchar(10),
	@email varchar(10),
	@state varchar(20),
	@add varchar(100)
AS
BEGIN	
		
			IF EXISTS (SELECT @rollNo FROM s189820.Student WHERE @rollNo = @rollNo)
			BEGIN
				RAISERROR('student ID already exists', 1, 1)
			END
		ELSE
			Begin
insert into s189820.Student values(@fullName,@gender,@dob,@mobNo,@email,@state,@add)
set @rollNo=SCOPE_IDENTITY()
END
end
RETURN 0



--ALTER PROCEDURE [At189753].[USP_Insert_Student]

--	@Stu_Id int out,
--	@Stu_Name varchar(Max),
--	@Stu_Gender varchar(Max),
--	@Stu_DOB date,
--	@Stu_MobileNo varchar(Max),
--	@Stu_Email varchar(Max),
--	@Stu_Address varchar(Max),
--	@Stu_State varchar(Max)
--AS
--BEGIN	
		
--			IF EXISTS (SELECT @Stu_Id FROM At189753.Student WHERE @Stu_Id = @Stu_Id)
--			BEGIN
--				RAISERROR('student ID already exists', 1, 1)
--			END
--		ELSE
--			Begin
--				insert into At189753.Student values(@Stu_Name,@Stu_Gender,@Stu_DOB,@Stu_MobileNo,@Stu_Email,@Stu_Address,@Stu_State)
--				set @Stu_id = SCOPE_IDENTITY();
--			END
--end
--RETURN 0
