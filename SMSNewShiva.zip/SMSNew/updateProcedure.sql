﻿CREATE PROCEDURE [s189820].[USP_UpdateStudent]
 @rollNo int ,
	@fullName varchar(30),
	@gender varchar(5),
	@dob date,
	@mobNo varchar(10),
	@email varchar(10),
	@state varchar(20),
	@add varchar(100)
AS
   update s189820.Student set Name = @fullName, Gender = @gender, DOB = @dob, Mobile = @mobNo, Email = @email, Address = @add, State = @state where RollNo = @rollNo
RETURN 0
