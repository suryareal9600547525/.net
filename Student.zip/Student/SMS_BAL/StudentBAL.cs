﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_DAL;
using SMS_Entities;
using SMS_Exceptions;

namespace SMS_BAL
{
    public class StudentBAL
    {
        static StudentDAL dal = new StudentDAL();
        public static void Add(Students student)
        {
            try
            {


                dal.Insert(student);
            }
            catch(Exception)
            {
                throw;
            }
            }

        public static void Modify(Students student)
        {
            try
            {

                dal.Update(student);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        } 

    }
}
