﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entities;
using SMS_Exceptions;
using System.Data.SqlClient;

namespace SMS_DAL
{
    public class StudentDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudentDAL()
        {
            cn = new SqlConnection(@"Data Source = ndamssql\sqlilearn; Initial Catalog = Training_18Jul19_Pune; User ID = sqluser; Password = sqluser");
        }


        public void Insert(Students student)
        {
            try
            {

                cmd = new SqlCommand("insert into s189820.Student values(@sName,@sgender,@dob,@address,@email,@mobileno,@state)", cn);
                cmd.Parameters.AddWithValue("@sName", student.StudentFullName);
                cmd.Parameters.AddWithValue("@sgender", student.Gender);

                cmd.Parameters.AddWithValue("@dob", student.DOB);

                cmd.Parameters.AddWithValue("@address", student.CommunicationAddress);

                cmd.Parameters.AddWithValue("@email", student.EmailAddress);
                cmd.Parameters.AddWithValue("@mobileno", student.MobileNumber);

                cmd.Parameters.AddWithValue("@state", student.State);


                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch(Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State== System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public void Update(Students student)
        {
            try
            {

                cmd = new SqlCommand("update s189820.Student set Name=@sName,Gender=@sgender, DOB=@dob,Mobile=@mobileno,Email=@email,Address=@address,State=@state where Name=@sName", cn);
                //cmd.Parameters.AddWithValue("@rNo",student.RollNo);
                cmd.Parameters.AddWithValue("@sName", student.StudentFullName);
                cmd.Parameters.AddWithValue("@sgender", student.Gender);

                cmd.Parameters.AddWithValue("@dob", student.DOB);

                cmd.Parameters.AddWithValue("@address", student.CommunicationAddress);

                cmd.Parameters.AddWithValue("@mobileno", student.MobileNumber);
                cmd.Parameters.AddWithValue("@email", student.EmailAddress);
           

                cmd.Parameters.AddWithValue("@state", student.State);
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch (Exception ex )
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

    }
}

