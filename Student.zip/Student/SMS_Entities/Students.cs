﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entities
{
    public class Students
    {
        public int RollNo { get; set; }

        public string StudentFullName { get; set; }

        public string Gender { get; set; }

        public DateTime DOB { get; set; }

        public string MobileNumber { get; set; }

        public string EmailAddress { get; set; }

        public string CommunicationAddress { get; set; }

        public string State { get; set; }

    }

}
