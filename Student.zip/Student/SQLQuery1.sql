﻿create schema s189820
create table s189820.Student
(
	Rollno int primary key identity,
	Name varchar(30),
	Gender varchar(10),
	DOB datetime,
	Mobile varchar(12),
	Email varchar(30),
	Address varchar(50),
	State varchar(20)
);
select * from s189820.Student