﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS_Entities;
using SMS_Exceptions;
using SMS_BAL;

namespace Student
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();

        }


        private bool ValidateUI(string studentFullName, string mobileNumber, string emailAddress, string gender, string communicationAddress)  //, string dOB, string state
        {
            bool status = true;
            StringBuilder sb = new StringBuilder();
            if (studentFullName == string.Empty || studentFullName == null)   //studentFullName.Length < 0
            {
                status = false;
                sb.Append("StudentFullname is Empty" + Environment.NewLine);
            }
            //if (dOB == string.Empty || dOB == null)
            //{
            //    status = false;
            //    sb.Append("dOB is Empty" + Environment.NewLine);
            //}
            if (mobileNumber == string.Empty || mobileNumber == null)
            {
                status = false;
                sb.Append("mobileNumber is Empty" + Environment.NewLine);
            }
            if (emailAddress == string.Empty || emailAddress == null)
            {
                status = false;
                sb.Append("emailAddress is Empty" + Environment.NewLine);
            }
            //if (state == string.Empty || state == null)
            //{
            //    status = false;
            //    sb.Append("state is Empty" + Environment.NewLine);
            //}
            if (gender == string.Empty || gender == null)
            {
                status = false;
                sb.Append("gender is Empty" + Environment.NewLine);
            }
            if (communicationAddress == string.Empty || communicationAddress == null)
            {
                status = false;
                sb.Append("communicationAddress is Empty" + Environment.NewLine);
            }

            if (status == false)
                throw new StudentException(sb.ToString());
            else
                return status;
        }



        private void RadioButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string gender = string.Empty;
                if ((bool)rbmale.IsChecked)               //also we can use ==true for check
                    gender = rbmale.Content.ToString();
                else
                      if ((bool)rbfemale.IsChecked)
                    gender = rbfemale.Content.ToString();

                txtAddress.SelectAll();


                if (ValidateUI(txtname.Text,  txtMoNo.Text, txtMail.Text, gender, txtAddress.Selection.Text)) //txtDOB.SelectedDate.ToString(),((ComboBoxItem)cb_state.SelectedItem).Content.ToString(), 
                {
                    Students student = new Students
                    {
                        StudentFullName = txtname.Text,
                        DOB = (DateTime)txtDOB.SelectedDate,
                        MobileNumber = txtMoNo.Text,
                        EmailAddress = txtMail.Text,
                        State = ((ComboBoxItem)cb_state.SelectedItem).Content.ToString()

                    };

                    student.Gender = gender;
                    student.CommunicationAddress = txtAddress.Selection.Text;


                    StudentBAL.Add(student);
                    MessageBox.Show("record inserted successfully");
                }
                else
                {
                    MessageBox.Show("Validation Error");
                }
            }
            catch (StudentException ex1)
            {
                MessageBox.Show(ex1.Message);

            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }
    }
}



