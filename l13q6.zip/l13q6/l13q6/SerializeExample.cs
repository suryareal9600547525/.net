﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;



namespace l13q6
{
    public class SerializeExample
    {
        public static void Main(string[] args)
        {
            FileStream stream = new FileStream(@"C:\m1 assignment\sss.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            
            Student s = new Student(101, "Anushree","Lucknow","BCA");

            formatter.Serialize(stream, s);
            Console.WriteLine("101, Anushree, Lucknow, BCA");
            stream.Close();
            
            Console.ReadLine();
        }
    }
}
