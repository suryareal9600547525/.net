﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDataAccessLayer;
using EmployeeEntities;
using EmployeeExceptions;
using System.Text.RegularExpressions;

namespace EmployeeBusinessLayer
{
    public class EmployeeBAL
    {
        public static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            if (!(Convert.ToString(employee.KinID).Length == 14))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "KIN ID Must Be 14 Digits");
                if (employee.Name == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Employee Name");
                }
                
                if (employee.DateOfBirth > DateTime.Today )
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid DateOfBirth (Correct Form is MM/DD/YYYY) ");
                }

                if (employee.DateOfJoining > DateTime.Today )
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid DateOfJoining (Correct Form is MM/DD/YYYY) ");
                }
                if (!Regex.Match(employee.EmailID, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$").Success)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid EmailID(Requires @, .com , validname)");
                }
                if (employee.Address == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Employee Address");
                }
                if (employee.Role == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Give appropriate Role");
                }
                if (employee.Project == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Project Could Not Be Find");
                }
                if (employee.Department == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Department");
                }
                if (validEmployee == false)
                    throw new EmployeeException(sb.ToString());
                
            }
            return validEmployee;
        }
        public static bool AddEmployeeBL(Employee newEmployeeDetails)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmployeeDetails))
                {
                    EmployeeDAL doctorDAL = new EmployeeDAL();
                    employeeAdded = doctorDAL.AddEmployeeDAL(newEmployeeDetails);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeAdded;
        }
        public static bool UpdateEmployeeBL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(updateEmployee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeUpdated = employeeDAL.UpdateEmployeeDAL(updateEmployee);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeUpdated;
        }
        public static Employee SearchEmployeeBL(double searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                searchEmployee = employeeDAL.SearchEmployeeDAL(searchEmployeeID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee;

        }

        public static Employee SearchEmployeeNameBL(string searchEmployeeName)
        {
            Employee searchEmployee1 = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                searchEmployee1 = employeeDAL.SearchEmployeeNameDAL(searchEmployeeName);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee1;

        }

        public static Employee SearchEmployeeMailBL(string searchEmployeeMail)
        {
            Employee searchEmployee2 = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                searchEmployee2 = employeeDAL.SearchEmployeeMailDAL(searchEmployeeMail);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee2;

        }
        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> employeeList = null;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                employeeList = employeeDAL.GetAllEmployeeDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }

        public static bool  DeleteEmployeeBL(double deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeID > 0)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeeDAL(deleteEmployeeID);
                }
                else
                {
                    throw new EmployeeException("Invalid Employee Kin ID");
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }

        public static bool DeleteEmployeeNameBL(string deleteEmployeeName)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeName != string.Empty)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeeNameDAL(deleteEmployeeName);
                    
                }
                else
                {
                    throw new EmployeeException("Invalid Employee Name");
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }

        public static bool DeleteEmployeeMailBL(string deleteEmployeeMail)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeMail != string.Empty)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeeMailDAL(deleteEmployeeMail);
                }
                else
                {
                    throw new EmployeeException("Invalid Employee MailID");
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }

    }
}








