﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntities;
using EmployeeExceptions;

namespace EmployeeDataAccessLayer
{
    public class EmployeeDAL
    {
        public static List<Employee> employeeList = new List<Employee>();
        public bool AddEmployeeDAL(Employee newEmployeeDetails)
        {
            bool employeeAdded = false;
            try
            {
                employeeList.Add(newEmployeeDetails);
                employeeAdded = true;
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeAdded;

        }
        //List
        public List<Employee> GetAllEmployeeDAL()
        {
            return employeeList;
        }
        //
        public bool UpdateEmployeeDAL(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    if (employeeList[i].KinID == updateEmployee.KinID)
                    {
                        updateEmployee.Name = employeeList[i].Name;
                        updateEmployee.DateOfBirth = employeeList[i].DateOfBirth;
                        updateEmployee.EmailID = employeeList[i].EmailID;
                        updateEmployee.Address = employeeList[i].Address;
                        updateEmployee.Role = employeeList[i].Role;
                        updateEmployee.Project = employeeList[i].Project;
                        updateEmployee.Department = employeeList[i].Department;

                        employeeUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeUpdated;
        }
        //
        public Employee SearchEmployeeDAL(double searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                    searchEmployee = employeeList.Find(employee => employee.KinID == searchEmployeeID);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return searchEmployee;
        }

        public Employee SearchEmployeeNameDAL(string searchEmployeeName)
        {
            Employee searchEmployee = null;
            try
            {
                searchEmployee = employeeList.Find(employee => employee.Name == searchEmployeeName);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return searchEmployee;
        }

        public Employee SearchEmployeeMailDAL(string searchEmployeeMail)
        {
            Employee searchEmployee = null;
            try
            {
                searchEmployee = employeeList.Find(employee => employee.EmailID == searchEmployeeMail);
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return searchEmployee;
        }
        //


        public bool DeleteEmployeeDAL(double deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                Employee deleteEmployee = employeeList.Find(employee => employee.KinID == deleteEmployeeID);

                if (deleteEmployee != null)
                {
                    Console.WriteLine("Are you sure to delete!! (y/n)");
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        employeeList.Remove(deleteEmployee);
                        employeeDeleted = true;
                    }
                    else
                        Console.WriteLine("You aborted ");
                }
            }
            catch (Exception ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeDeleted;

        }

        public bool DeleteEmployeeNameDAL(string deleteEmployeeName)
        {
            bool employeeDeleted = false;
            try
            {
                Employee deleteEmployee = employeeList.Find(employee => employee.Name == deleteEmployeeName);

                if (deleteEmployee != null)
                {
                    Console.WriteLine("Are you sure to delete!! (y/n)");
                    string ch= Console.ReadLine();
                    if (ch == "y")
                    {
                        employeeList.Remove(deleteEmployee);
                        employeeDeleted = true;
                    }
                    else
                        Console.WriteLine("You aborted ");

                }
            }
            catch (Exception ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeDeleted;

        }
        
         public bool DeleteEmployeeMailDAL(string deleteEmployeeMail)
        {
            bool employeeDeleted = false;
            try
            {
                Employee deleteEmployee = employeeList.Find(employee => employee.EmailID == deleteEmployeeMail);

                if (deleteEmployee != null)
                {
                    Console.WriteLine("Are you sure to delete!! (y/n)");
                    string ch = Console.ReadLine();
                    if (ch == "y")
                    {
                        employeeList.Remove(deleteEmployee);
                        employeeDeleted = true;
                    }

                    else
                        Console.WriteLine("You aborted ");

                }
            }
            catch (Exception ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeDeleted;

        }

    }
}
