﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeEntities
{
    public class Employee
    {
        public double KinID { get; set; }

        public string Name { get; set; }

        public DateTime DateOfBirth { get; set; }

        public DateTime DateOfJoining { get; set; }

        public string EmailID { get; set; }

        public string Address { get; set; }

        public string Role { get; set; }

        public string Project { get; set; }

        public string Department { get; set; }

        


        }
    }

