﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeBusinessLayer;
using EmployeeEntities;
using EmployeeExceptions;

namespace EmployeeManagementSystem
{
    class Program
    {
        EmployeeBAL objEmployee = new EmployeeBAL();
        static void Main(string[] args)
        {
            int choice;
            do
            {
                MainMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.Clear();
                        AddEmployee();
                        break;
                    case 2:
                        Console.Clear();
                        UpdateEmployee();
                        break;

                    case 3:
                        Console.Clear();
                        Search();
                        break;
                    case 4:
                        Console.Clear();
                        ListAllEmployee();
                       break;

                    case 5:
                        Console.Clear();
                        Delete();
                       break;

                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }
            } while (choice != -1);
        }

        private static void MainMenu()
        {
            Console.WriteLine("\n--------***--------Employee Management System--------***--------");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Update Employee");
            Console.WriteLine("3. Search Employee");
            Console.WriteLine("4. List All Employee");
            Console.WriteLine("5. Delete Employee");


        }

        private static void AddEmployee()
        {
            try
            {
                Employee newEmployeeDetails = new Employee();
                Console.WriteLine("Adding a New Employee");
                Console.WriteLine("Enter Employee KinID :");
                newEmployeeDetails.KinID = Convert.ToDouble(Console.ReadLine());
                //EmployeeBAL.ValidateEmployee(newEmployeeDetails);
                Console.WriteLine("Enter Employee Name :");
                newEmployeeDetails.Name = Console.ReadLine();
                Console.WriteLine("Enter DateOfBirth:");
                newEmployeeDetails.DateOfBirth = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter DateOfJoining:");
                newEmployeeDetails.DateOfJoining = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter EmailID :");
                newEmployeeDetails.EmailID = Console.ReadLine();
                Console.WriteLine("Enter Address :");
                newEmployeeDetails.Address = Console.ReadLine();
                Console.WriteLine("Enter Role :");
                newEmployeeDetails.Role= Roles();
                //newEmployeeDetails.Role = Console.ReadLine();
                Console.WriteLine("Enter Project :");
                newEmployeeDetails.Project = Projects();
                //newEmployeeDetails.Project = Console.ReadLine();
                Console.WriteLine("Enter Department :");
                newEmployeeDetails.Department = Departments();
                //newEmployeeDetails.Department = Console.ReadLine();



                bool employeeAdded = EmployeeBAL.AddEmployeeBL(newEmployeeDetails);
                if (employeeAdded)
                    Console.WriteLine("New Employee Added");
                else
                    Console.WriteLine("New Employee not Added");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateEmployee()
        {
            try
            {
                ListAllEmployee();
                double updateEmployeeID;
                //double searchEmployeeID;
                Console.WriteLine("Updating Employee Records");
                Console.WriteLine("Enter Employee KinID to Update Details:");
                updateEmployeeID = Convert.ToDouble(Console.ReadLine());
                Employee searchEmployee = EmployeeBAL.SearchEmployeeBL(updateEmployeeID);
                Employee updatedEmployee = EmployeeBAL.SearchEmployeeBL(updateEmployeeID);


                if (searchEmployee != null)
                {
                    Console.WriteLine("Employee KinID        :" + searchEmployee.KinID);
                    Console.WriteLine("Employee Name         :" + searchEmployee.Name);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfBirth);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfJoining);
                    Console.WriteLine("Employee EmailID      :" + searchEmployee.EmailID);
                    Console.WriteLine("Employee Address      :" + searchEmployee.Address);
                    Console.WriteLine("Employee Role         :" + searchEmployee.Role);
                    Console.WriteLine("Employee Project      :" + searchEmployee.Project);
                    Console.WriteLine("Employee Department   :" + searchEmployee.Department);
                }

                    if (updatedEmployee != null)
                {
                    Console.WriteLine("Update Employee Name :");
                    updatedEmployee.Name = Console.ReadLine();
                    Console.WriteLine("Update Date of birth  :");
                    updatedEmployee.DateOfBirth = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Update Email ID  :");
                    updatedEmployee.EmailID = Console.ReadLine();
                    Console.WriteLine("Update Address :");
                    updatedEmployee.Address = Console.ReadLine();
                    Console.WriteLine("Update Role Name :");
                    updatedEmployee.Role = Roles();
                    Console.WriteLine("Update Project Name :");
                    updatedEmployee.Project = Projects();
                    Console.WriteLine("Update Department Name :");
                    updatedEmployee.Department = Departments();


                    bool employeeUpdated = EmployeeBAL.UpdateEmployeeBL(updatedEmployee);
                    if (employeeUpdated)
                        Console.WriteLine("Employee Details Updated");
                    else
                        Console.WriteLine("Employee Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchEmployeeByID()
        {
            try
            {
                double searchEmployeeID;
                Console.WriteLine("Searching a Employee using KIN-ID");
                Console.Write("Enter Employee KinID to Search : ");
                searchEmployeeID = Convert.ToDouble(Console.ReadLine());
                Employee searchEmployee = EmployeeBAL.SearchEmployeeBL(searchEmployeeID);
                if (searchEmployee != null)
                {
                    Console.WriteLine("Employee KinID        :" + searchEmployee.KinID);
                    Console.WriteLine("Employee Name         :" + searchEmployee.Name);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfBirth);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfJoining);
                    Console.WriteLine("Employee EmailID      :" + searchEmployee.EmailID);
                    Console.WriteLine("Employee Address      :" + searchEmployee.Address);
                    Console.WriteLine("Employee Role         :" + searchEmployee.Role);
                    Console.WriteLine("Employee Project      :" + searchEmployee.Project);
                    Console.WriteLine("Employee Department   :" + searchEmployee.Department);
                    //    Console.WriteLine("********************************************************************************************************************");
                    //    Console.WriteLine("EmployeeID\t\tEmployeeName\tEmployeeDateOfBirth\t\tEmployeeEmailID\t\tEmployeeAddress\tEmployeeRole\tEmployeeProject\tEmployeeDepartment");
                    //    Console.WriteLine("*********************************************************************************************************************");
                    //    Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", searchEmployee.KinID, searchEmployee.Name, searchEmployee.DateOfBirth, searchEmployee.EmailID, searchEmployee.Address, searchEmployee.Role, searchEmployee.Project, searchEmployee.Department);
                    //    Console.WriteLine("**********************************************************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchEmployeeByName()
        {
            try
            {
                List<string> EmpName = new List<string>();

                string searchEmployeeName;
                Console.WriteLine("Searching a Employee using Name");
                Console.Write("Enter Employee Name to Search : ");
                searchEmployeeName = Convert.ToString(Console.ReadLine());
                Employee searchEmployee = EmployeeBAL.SearchEmployeeNameBL(searchEmployeeName);
                if (searchEmployee != null)
                {
            Console.WriteLine("Employee KinID        :" + searchEmployee.KinID);
            Console.WriteLine("Employee Name         :" + searchEmployee.Name);
            Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfBirth);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfJoining);
                    Console.WriteLine("Employee EmailID      :" + searchEmployee.EmailID);
            Console.WriteLine("Employee Address      :" + searchEmployee.Address);
            Console.WriteLine("Employee Role         :" + searchEmployee.Role);
            Console.WriteLine("Employee Project      :" + searchEmployee.Project);
            Console.WriteLine("Employee Department   :" + searchEmployee.Department);
            //Console.WriteLine("********************************************************************************************************************");
            //Console.WriteLine("EmployeeID\tEmployeeName\tEmployeeDateOfBirth\t\tEmployeeEmailID\t\tEmployeeAddress\t\tEmployeeRole\tEmployeeProject\tEmployeeDepartment");
            //Console.WriteLine("*********************************************************************************************************************");
            //Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", searchEmployee.KinID, searchEmployee.Name, searchEmployee.DateOfBirth, searchEmployee.EmailID, searchEmployee.Address, searchEmployee.Role, searchEmployee.Project, searchEmployee.Department);
            //Console.WriteLine("**********************************************************************************************************************");
        }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SearchEmployeeByMail()
        {
            try
            {
                string searchEmployeeMail;
                Console.WriteLine("Searching a Employee using EMailId");
                Console.WriteLine("Enter Employee Mail to Search:");
                searchEmployeeMail = Convert.ToString(Console.ReadLine());
                Employee searchEmployee = EmployeeBAL.SearchEmployeeMailBL(searchEmployeeMail);
                if (searchEmployee != null)
                {
            Console.WriteLine("Employee KinID        :"+searchEmployee.KinID);
            Console.WriteLine("Employee Name         :" + searchEmployee.Name);
            Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfBirth);
                    Console.WriteLine("Employee DateOfBirth  :" + searchEmployee.DateOfJoining);
                    Console.WriteLine("Employee EmailID      :" + searchEmployee.EmailID);
            Console.WriteLine("Employee Address      :" + searchEmployee.Address);
            Console.WriteLine("Employee Role         :" + searchEmployee.Role);
            Console.WriteLine("Employee Project      :" + searchEmployee.Project);
            Console.WriteLine("Employee Department   :" + searchEmployee.Department);
            //Console.WriteLine("********************************************************************************************************************");
            //Console.WriteLine("EmployeeID\t\tEmployeeName\tEmployeeDateOfBirth\t\tEmployeeEmailID\t\tEmployeeAddress\tEmployeeRole\tEmployeeProject\tEmployeeDepartment");
            //Console.WriteLine("*********************************************************************************************************************");
            //Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", searchEmployee.KinID, searchEmployee.Name, searchEmployee.DateOfBirth, searchEmployee.EmailID, searchEmployee.Address, searchEmployee.Role, searchEmployee.Project, searchEmployee.Department);
            //Console.WriteLine("**********************************************************************************************************************");
        }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Search()
        {
            Console.WriteLine("1-search by ID");
            Console.WriteLine("2-search by Name");
            Console.WriteLine("3-search by Email");
            int choice;
            Console.WriteLine("choose any one");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    SearchEmployeeByID();
                    break;
                case 2:
                    SearchEmployeeByName();
                    break;
                case 3:
                    SearchEmployeeByMail();
                    break;
            }
        }

        public static string Roles()
        {
            int c;
            string srole = null;
            List<string> Lrole = new List<string> { "HR", "Manager", "Developer", "Software Associate", "Team Leader" };
            for (int i = 0; i < Lrole.Count; i++)
            {
                Console.WriteLine((i + 1) + " - " + Lrole[i]);
            }
            Console.WriteLine("choose any one");
            c = Convert.ToInt32(Console.ReadLine());
            switch (c)
            {
                case 1:
                    srole = Lrole[0];
                    break;
                case 2:
                    srole = Lrole[1];
                    break;
                case 3:
                    srole = Lrole[2];
                    break;
                case 4:
                    srole = Lrole[3];
                    break;
                case 5:
                    srole = Lrole[4];
                    break;
            }
            return srole;
        }
        ////
        //Console.WriteLine("Enter 1 for hr :");
        //Console.WriteLine("Enter 2 for manager :");
        //Console.WriteLine("Enter 3 for developer :");
        //int c;
        //c = Convert.ToInt32(Console.ReadLine());
        //Employee obj1 = new Employee();
        //switch (c)
        //{
        //    case 1:
        //        srole = "HR";
        //        break;
        //    case 2:
        //        srole = "Manager";
        //        break;
        //    case 3:
        //        srole = "Developer";
        //        break;
        //}
        //return srole;
        public static string Projects()
        {
            int c;
            string sproject = null;
            List<string> Lproject = new List<string> { ".Net", "Python", "Java", "Cloud", "IOT" };
            for (int i = 0; i < Lproject.Count; i++)
            {
                Console.WriteLine((i + 1) + " - " + Lproject[i]);
            }
            Console.WriteLine("choose any one");
            c = Convert.ToInt32(Console.ReadLine());
            switch (c)
            {
                case 1:
                    sproject = Lproject[0];
                    break;
                case 2:
                    sproject = Lproject[1];
                    break;
                case 3:
                    sproject = Lproject[2];
                    break;
                case 4:
                    sproject = Lproject[3];
                    break;
                case 5:
                    sproject = Lproject[4];
                    break;
            }
            return sproject;
        }

        public static string Departments()
        {
            int c;
            string sdepartment = null;
            List<string> Ldepartment = new List<string> { "IT", "NON-IT", "Services", "Finance", "BusinessUnit" };
            for (int i = 0; i < Ldepartment.Count; i++)
            {
                Console.WriteLine((i + 1) + " - " + Ldepartment[i]);
            }
            Console.WriteLine("choose any one");
            c = Convert.ToInt32(Console.ReadLine());

            //
            //for (int i = 0; i < Ldepartment.Count; i++)
            //{
            //    if(c==(i+1))
            //        sdepartment= Ldepartment[i]
            //}
                //
                switch (c)
            {
                case 1:
                    sdepartment = Ldepartment[0];
                    break;
                case 2:
                    sdepartment = Ldepartment[1];
                    break;
                case 3:
                    sdepartment = Ldepartment[2];
                    break;
                case 4:
                    sdepartment = Ldepartment[3];
                    break;
                case 5:
                    sdepartment = Ldepartment[4];
                    break;
            }
            return sdepartment;
        }

        //List
        private static void ListAllEmployee()
        {
            try
            {
                List<Employee> employeeList = EmployeeBAL.GetAllEmployeeBL();
                if (employeeList != null)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    Console.WriteLine("EmployeeID\tEmployeeName\tEmployeeDateOfBirth\tEmployeeDateOfJoining\tEmployeeEmailID\t EmployeeAddress\tEmployeeRole\tEmployeeProject\tEmployeeDepartment");
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    foreach (Employee employee in employeeList)
                    {
                        Console.WriteLine("{0}\t{1}\t\t{2}\t\t{3}\t{4}\t\t\t{5}\t\t{6}\t\t{7}\t{8}", employee.KinID, employee.Name, employee.DateOfBirth.ToShortDateString(),employee.DateOfJoining, employee.EmailID, employee.Address, employee.Role, employee.Project, employee.Department);

                    }
                    Console.WriteLine("*************************************************************************************************************************************************************************************");
                }

                else
                {
                    Console.WriteLine("No Employee Details Available");
                }
                }

            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
   
        private static void Delete()
        {
            Console.WriteLine("1-Delete by ID");
            Console.WriteLine("2-Delete by Name");
            Console.WriteLine("3-Delete by Email");
            int choice;
            Console.WriteLine("choose any one");
            choice = Convert.ToInt32(Console.ReadLine());
            
            switch (choice)
            {
                case 1:
                    DeleteEmployeeByID();
                    break;
                case 2:
                    DeleteEmployeeByName();
                    break;
                case 3:
                    DeleteEmployeeByMail();
                    break;
            }
        }

        private static void DeleteEmployeeByID()
        { 
            
        try
            {
                double deleteEmployeeID;
                Console.WriteLine("Enter EmployeeID to Delete:");
                deleteEmployeeID = Convert.ToDouble(Console.ReadLine());
                Employee deleteEmployee = EmployeeBAL.SearchEmployeeBL(deleteEmployeeID);
                if (deleteEmployee != null)
                {
                    bool employeedeleted = EmployeeBAL.DeleteEmployeeBL(deleteEmployeeID);
                    if (employeedeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeleteEmployeeByName()
        {

            try
            {
                string deleteEmployeeName;
                Console.WriteLine("Enter EmployeeName to Delete:");
                deleteEmployeeName = Console.ReadLine();
                Employee deleteEmployee = EmployeeBAL.SearchEmployeeNameBL(deleteEmployeeName);
                if (deleteEmployee != null)
                {
                    bool employeedeleted = EmployeeBAL.DeleteEmployeeNameBL(deleteEmployeeName);
                    if (employeedeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeleteEmployeeByMail()
        {

            try
            {
                string deleteEmployeeMail;
                Console.WriteLine("Enter EmployeeMailID to Delete:");
                deleteEmployeeMail = Console.ReadLine();
                Employee deleteEmployee = EmployeeBAL.SearchEmployeeMailBL(deleteEmployeeMail);
                if (deleteEmployee != null)
                {
                    bool employeedeleted = EmployeeBAL.DeleteEmployeeMailBL(deleteEmployeeMail);
                    if (employeedeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //public static void CheckOccur() {
        //    string name;
        //    Console.WriteLine("Enter the Name:");
        //    name =Console.ReadLine();

    }
    }
