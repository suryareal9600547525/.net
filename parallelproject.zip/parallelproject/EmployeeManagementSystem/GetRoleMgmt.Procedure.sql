﻿CREATE PROCEDURE [s189820].[GetRolesMgmt]
	
AS
begin
	SELECT * from s189820.RoleMgmt
	end

