﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpMgmtDataAccessLayer;
using EmpMgmtEntities;
using EmpMgmtExceptions;
using System.Text.RegularExpressions;
using System.Data;

namespace EmpMgmtBusinessLayer
{
    public class EmployeeBAL
    {
        public static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
           if((Convert.ToString(employee.EmployeeId)==null))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invakid Employee ID");
            }
                if (employee.Name == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Employee Name");
                }
            if (!(Convert.ToString(employee.KinID).Length == 14))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "KIN ID Must Be 14 Digits");
                if (employee.DOB > DateTime.Today)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid DateOfBirth (Correct Form is MM/DD/YYYY) ");
                }
                if (!Regex.Match(employee.MailID, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$").Success)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid EmailID(Requires @, .com , validname)");
                }
                if (employee.Address == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Employee Address");
                }
                if ((Convert.ToString(employee.DepartmentID)==null))
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Invalid Department");
                }
                if ((Convert.ToString(employee.ProjectID) == null))
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Project Could Not Be Find");
                }

                if ((Convert.ToString(employee.RolesID) == null))
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Give appropriate Role");
                }
               
                if (validEmployee == false)
                    throw new EmpException(sb.ToString());

            }
            return validEmployee;
        }
        public static bool InsertEmployeeBL(Employee employee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(employee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeAdded = employeeDAL.InsertEmployeeDAL(employee);
                    return employeeAdded;
                }
            }
            catch (EmpException ex)

            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeAdded;
        }

        public static bool UpdateEmployeeBL(Employee employee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(employee))
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeUpdated = employeeDAL.UpdateEmployeeDAL(employee);
                    return employeeUpdated;
                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int employeeId)
        {
            bool employeeDeleted = false;
            try
            {
                if (employeeId > 0)
                {
                    EmployeeDAL employeeDAL = new EmployeeDAL();
                    employeeDeleted = employeeDAL.DeleteEmployeeDAL(employeeId);
                }
                else
                {
                    throw new EmpException("Employee Id must be 4 digits and cannot be empty.");
                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeDeleted;
        }

        public static Employee SearchEmployeeIDBL(int id)
        {
            EmployeeDAL objemp = new EmployeeDAL();
            Employee employee = null;
            try
            {
                if (id >= 0)
                {
                    employee = objemp.SearchEmployeeIdDAL(id);
                }
                else
                {
                    throw new EmpException("Employee Id is invalid");
                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        public static Employee SearchEmployeeNameBL(string name)
        {
            EmployeeDAL employeeDAL = new EmployeeDAL();
            Employee employee = null;
            try
            {
                if (name != string.Empty)
                {
                   
                    employee = employeeDAL.SearchEmployeeNameDAL(name);
                }
                else
                {
                    throw new EmpException("Employee Name is invalid.");
                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        public static Employee SearchEmployeeMailBL(string mailId)
        {
            EmployeeDAL employeeDAL = new EmployeeDAL();
            Employee employee = null;
            try
            {
                if (mailId !=string.Empty)
                {
                   
                    employee = employeeDAL.SearchEmployeeMailDAL(mailId);
                }
                else
                {
                    throw new EmpException("Employee MailID must be Valid.");
                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> employeeList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                employeeList = employeeDAL.GetAllEmployeesDAL();
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }

        public static DataTable GetDepartmentBL()
        {
            DataTable departmentList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                departmentList = employeeDAL.GetDepartmentsDAL();
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return departmentList;
        }

        public static DataTable GetProjectBL()
        {
            DataTable projectList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                projectList = employeeDAL.GetProjectDAL();
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return projectList;
        }

        public static DataTable GetRolesBL()
        {
            DataTable rolesList;
            try
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                rolesList = employeeDAL.GetRoleDAL();
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rolesList;
        }

    }
}
