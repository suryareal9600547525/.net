﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmpMgmtEntities;
using EmpMgmtExceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace EmpMgmtDataAccessLayer
{
    public class EmployeeDAL
    {
        SqlConnection objCon = null;

        public EmployeeDAL()
        {
            objCon = new SqlConnection(
                  ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);

        }

        public bool InsertEmployeeDAL(Employee objEmployee)
        {
            bool employeeAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[InsertEmployeeMgmt]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@empID", objEmployee.EmployeeId);
                SqlParameter objSqlParam_Name = new SqlParameter("@name", objEmployee.Name);
                SqlParameter objSqlParam_KinID = new SqlParameter("@kinID", objEmployee.KinID);
                SqlParameter objSqlParam_MailID = new SqlParameter("@mailID", objEmployee.MailID);
                SqlParameter objSqlParam_PhnNo = new SqlParameter("@phnNo", objEmployee.PhoneNo);
                SqlParameter objSqlParam_DoB = new SqlParameter("@dob", objEmployee.DOB);
                SqlParameter objSqlParam_DoJ = new SqlParameter("@doj", objEmployee.DOJ);
                SqlParameter objSqlParam_Address = new SqlParameter("@address", objEmployee.Address);
                SqlParameter objSqlParam_DepartmentID = new SqlParameter("@departmentID", objEmployee.DepartmentID);
                SqlParameter objSqlParam_ProjectID = new SqlParameter("@projectID", objEmployee.ProjectID);
                SqlParameter objSqlParam_RoleID = new SqlParameter("@rolesID", objEmployee.RolesID);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_KinID);
                objCom.Parameters.Add(objSqlParam_MailID);
                objCom.Parameters.Add(objSqlParam_PhnNo);
                objCom.Parameters.Add(objSqlParam_DoB);
                objCom.Parameters.Add(objSqlParam_DoJ);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_DepartmentID);
                objCom.Parameters.Add(objSqlParam_ProjectID);
                objCom.Parameters.Add(objSqlParam_RoleID);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new EmpException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeAdded;
        }

        public bool UpdateEmployeeDAL(Employee objEmployee)
        {
            bool employeeUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[UpdateEmployeeMgmtID]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_EmpId = new SqlParameter("@empID", objEmployee.EmployeeId);
                SqlParameter objSqlParam_Name = new SqlParameter("@name", objEmployee.Name);
                SqlParameter objSqlParam_KinID = new SqlParameter("@kinID", objEmployee.KinID);
                SqlParameter objSqlParam_MailID = new SqlParameter("@mailID", objEmployee.MailID);
                SqlParameter objSqlParam_PhnNo = new SqlParameter("@phnNo", objEmployee.PhoneNo);
                SqlParameter objSqlParam_DoB = new SqlParameter("@dob", objEmployee.DOB);
                SqlParameter objSqlParam_DoJ = new SqlParameter("@doj", objEmployee.DOJ);
                SqlParameter objSqlParam_Address = new SqlParameter("@address", objEmployee.Address);
                SqlParameter objSqlParam_DepartmentID = new SqlParameter("@departmentID", objEmployee.DepartmentID);
                SqlParameter objSqlParam_ProjectID = new SqlParameter("@projectID", objEmployee.ProjectID);
                SqlParameter objSqlParam_RoleID = new SqlParameter("@rolesID", objEmployee.RolesID);
                //
                objCom.Parameters.Add(objSqlParam_EmpId);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_KinID);
                objCom.Parameters.Add(objSqlParam_MailID);
                objCom.Parameters.Add(objSqlParam_PhnNo);
                objCom.Parameters.Add(objSqlParam_DoB);
                objCom.Parameters.Add(objSqlParam_DoJ);
                objCom.Parameters.Add(objSqlParam_Address);
                objCom.Parameters.Add(objSqlParam_DepartmentID);
                objCom.Parameters.Add(objSqlParam_ProjectID);
                objCom.Parameters.Add(objSqlParam_RoleID);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new EmpException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeUpdated;
        }

        public bool DeleteEmployeeDAL(int id)
        {
            bool employeeDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[DeleteEmployeeMgmt]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_EmpId = new SqlParameter("@empID", id);
                //
                objCom.Parameters.Add(objSqlParam_EmpId);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new EmpException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeDeleted;
        }

        public Employee SearchEmployeeIdDAL(int id)
        {
            Employee objEmployee = new Employee();
           
            SqlCommand objCmd = null;
            SqlDataReader dr = null;

            

            try
            {
              
                objCmd = new SqlCommand("[s189820].[SearchEmployeeMgmtID]", objCon);
                objCmd.CommandType = CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("@empID", id);
               
                objCon.Open();
                dr = objCmd.ExecuteReader();
                while (dr.Read()) //
                {
                    objEmployee.EmployeeId = Convert.ToInt32(dr[0]);
                    objEmployee.Name = dr[1].ToString();
                    objEmployee.KinID = dr[2].ToString();
                    objEmployee.MailID= dr[3].ToString();
                    objEmployee.PhoneNo= dr[4].ToString();
                    objEmployee.DOB = Convert.ToDateTime(dr[5]);
                    objEmployee.DOJ = Convert.ToDateTime(dr[6]);
                    objEmployee.Address= dr[7].ToString();
                    objEmployee.DepartmentID = Convert.ToInt32(dr[8]);
                    objEmployee.ProjectID = Convert.ToInt32(dr[9]);
                    objEmployee.RolesID= Convert.ToInt32(dr[10]);

                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                objCon.Close();
            }
            return objEmployee;
       
        }


        //SearchByName
        public Employee SearchEmployeeNameDAL(string name)
        {
            Employee objEmployee = new Employee();

            SqlCommand objCmd = null;
            SqlDataReader dr = null;   

            try
            {

                objCmd = new SqlCommand("[s189820].[SearchEmployeeMgmtName]", objCon);
                objCmd.CommandType = System.Data.CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("@name", name);

                objCon.Open();
                dr = objCmd.ExecuteReader();
                while (dr.Read()) //
                {
                    objEmployee.EmployeeId = Convert.ToInt32(dr[0]);
                    objEmployee.Name = dr[1].ToString();
                    objEmployee.KinID = dr[2].ToString();
                    objEmployee.MailID = dr[3].ToString();
                    objEmployee.PhoneNo = dr[4].ToString();
                    objEmployee.DOB = Convert.ToDateTime(dr[5]);
                    objEmployee.DOJ = Convert.ToDateTime(dr[6]);
                    objEmployee.Address = dr[7].ToString();
                    objEmployee.DepartmentID = Convert.ToInt32(dr[8]);
                    objEmployee.ProjectID = Convert.ToInt32(dr[9]);
                    objEmployee.RolesID = Convert.ToInt32(dr[10]);

                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                objCon.Close();
            }
            return objEmployee;

        }




        //SearchBymail2
        public Employee SearchEmployeeMailDAL(string mailId)
        {
            Employee objEmployee = new Employee();

            SqlCommand objCmd = null;
            SqlDataReader dr = null;

            try
            {

                objCmd = new SqlCommand("s189820.SearchEmployeeMgmtMailID", objCon);
                objCmd.CommandType = System.Data.CommandType.StoredProcedure;
                objCmd.Parameters.AddWithValue("@mailID", mailId);

                objCon.Open();
                dr = objCmd.ExecuteReader();
                while (dr.Read()) //
                {
                    objEmployee.EmployeeId = Convert.ToInt32(dr[0]);
                    objEmployee.Name = dr[1].ToString();
                    objEmployee.KinID = dr[2].ToString();
                    objEmployee.MailID = dr[3].ToString();
                    objEmployee.PhoneNo = dr[4].ToString();
                    objEmployee.DOB = Convert.ToDateTime(dr[5]);
                    objEmployee.DOJ = Convert.ToDateTime(dr[6]);
                    objEmployee.Address = dr[7].ToString();
                    objEmployee.DepartmentID = Convert.ToInt32(dr[8]);
                    objEmployee.ProjectID = Convert.ToInt32(dr[9]);
                    objEmployee.RolesID = Convert.ToInt32(dr[10]);

                }
            }
            catch (EmpException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                objCon.Close();
            }
            return objEmployee;

        }



        public List<Employee> GetAllEmployeesDAL()
        {
            List<Employee> objEmployees = new List<Employee>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[ListEmployeeMgmt]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Employee objEmployee = new Employee();
                    objEmployee.EmployeeId = Convert.ToInt32(objDR[0]);
                    objEmployee.Name = objDR[1] as string;
                    objEmployee.KinID = objDR[2] as string;
                    objEmployee.MailID = objDR[3] as string;
                    objEmployee.PhoneNo = objDR[4] as string;
                    objEmployee.DOB = Convert.ToDateTime(objDR[5]);
                    objEmployee.DOJ = Convert.ToDateTime(objDR[6]);
                    objEmployee.Address = objDR[7] as string;

                    objEmployee.DepartmentID = Convert.ToInt32(objDR[8]);
                    objEmployee.ProjectID = Convert.ToInt32(objDR[9]);
                    objEmployee.RolesID = Convert.ToInt32(objDR[10]);
                    objEmployees.Add(objEmployee);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new EmpException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployees;
        }

        /////GetDepartmentDAL
        public DataTable GetDepartmentsDAL()
        {
            DataTable departmentList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[GetDepartmentEmpMgmt]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                departmentList = new DataTable();
                departmentList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmpException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return departmentList;
        }

        //GetProject
        public DataTable GetProjectDAL()
        {
            DataTable projectList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[GetProjectEmpMgmt]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                projectList = new DataTable();
                projectList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmpException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return projectList;
        }
        //


        //GetRole
        public DataTable GetRoleDAL()
        {
            DataTable roleList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["EmpMgmtConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[s189820].[USP_GetEmpIDFromRole]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                roleList = new DataTable();
                roleList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmpException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return roleList;
        }





    }
}