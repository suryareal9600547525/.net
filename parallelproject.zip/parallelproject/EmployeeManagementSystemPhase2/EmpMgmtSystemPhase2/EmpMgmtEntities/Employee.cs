﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpMgmtEntities
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        public string Name { get; set; }

        public string KinID { get; set; }

        public string MailID { get; set; }

        public string PhoneNo { get; set; }

        public DateTime DOB { get; set; }

        public DateTime DOJ { get; set; }

        public string Address { get; set; }

        public int DepartmentID { get; set; }

        public int ProjectID { get; set; }

        public int RolesID { get; set; }
    }
}
