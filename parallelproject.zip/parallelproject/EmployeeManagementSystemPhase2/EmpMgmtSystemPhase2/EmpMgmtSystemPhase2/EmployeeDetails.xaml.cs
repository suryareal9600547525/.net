﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmpMgmtEntities;
using EmpMgmtExceptions;
using EmpMgmtBusinessLayer;
using System.Data;

namespace EmpMgmtSystemPhase2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeBAL bal = new EmployeeBAL();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            InsertEmployee();
        }

        private void btnUpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            UpdateEmployee();
        }

        private void btnDeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            DeleteEmployee();
        }

        private void btnGetEmployees_Click(object sender, RoutedEventArgs e)
        {
            GetEmployees();
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        
        private void btnSearchEmployeeID_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployeeID();
        }

        private void btnSearchEmployeeName_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployeeName();
        }

        private void btnSearchEmployeeMail_Click(object sender, RoutedEventArgs e)
        {
            SearchEmployeeMail();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetDepartment();
            GetProject();
            GetRoles();
       
        }

        private void InsertEmployee()
        {
            try
            {
                int id;
                string name;
                string kinID;
                string mailID;
                string phnNo;
                DateTime doB;
                DateTime doJ;
                string address;
                int departmentID;
                int projectID;
                int rolesID;


          
                //
                bool employeeAdded;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                kinID = txtkin.Text;
                mailID = txtmail.Text;
                phnNo = txtphn.Text;
                doB = Convert.ToDateTime(dptxtdob.SelectedDate);
                doJ = Convert.ToDateTime(dptxtdoj.SelectedDate);
                address = txtadd.Text;
                departmentID =Convert.ToInt32(cmbdept.SelectedValue);
                projectID = Convert.ToInt32(cmbproject.SelectedValue);
                rolesID = Convert.ToInt32(cmbroles.SelectedValue);
                //
                Employee objEmployee = new Employee
                {
                    EmployeeId = id,
                    Name = name,
                    KinID=kinID,
                    MailID=mailID,
                    PhoneNo=phnNo,
                    DOB=doB,
                    DOJ=doJ,
                    Address=address,
                    DepartmentID=departmentID,
                    ProjectID=projectID,
                    RolesID=rolesID
               
                };
                employeeAdded = EmployeeBAL.InsertEmployeeBL(objEmployee);
                if (employeeAdded == true)
                {
                    MessageBox.Show("Employee record added successfully.");
                    GetEmployees();
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be added.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void UpdateEmployee()
        {
            try
            {
                int id;
                string name;
                string kinID;
                string mailID;
                string phnNo;
                DateTime doB;
                DateTime doJ;
                string address;
                int departmentID;
                int projectID;
                int rolesID;

                //
                bool employeeUpdated;
                //
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                kinID = txtkin.Text;
                mailID = txtmail.Text;
                phnNo = txtphn.Text;
                doB = Convert.ToDateTime(dptxtdob.SelectedDate.ToString());
                doJ = Convert.ToDateTime(dptxtdoj.SelectedDate.ToString());
                address = txtadd.Text;
                departmentID = Convert.ToInt32(cmbdept.SelectedValue);
                projectID = Convert.ToInt32(cmbproject.SelectedValue);
                rolesID = Convert.ToInt32(cmbroles.SelectedValue);
                //
                Employee objEmployee = new Employee
                {
                    EmployeeId = id,
                    Name = name,
                    KinID = kinID,
                    MailID = mailID,
                    PhoneNo = phnNo,
                    DOB = doB,
                    DOJ = doJ,
                    Address = address,
                    DepartmentID = departmentID,
                    ProjectID = projectID,
                    RolesID = rolesID
                };
                employeeUpdated = EmployeeBAL.UpdateEmployeeBL(objEmployee);
                if (employeeUpdated == true)
                {
                    MessageBox.Show("Employee record updated successfully.");
                    GetEmployees();
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be updated.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DeleteEmployee()
        {
            try
            {
                int id;
                //
                bool employeeDeleted;
                //
                id = Convert.ToInt32(txtId.Text);
                //
                employeeDeleted = EmployeeBAL.DeleteEmployeeBL(id);
                if (employeeDeleted == true)
                {
                    MessageBox.Show("Employee record deleted successfully.");
                    GetEmployees();
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be deleted.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SearchEmployeeID()
        {
            try
            {
                int id;
                //
                Employee objEmployee;
                //
                id =Convert.ToInt32(txtId.Text);
                //
                objEmployee = EmployeeBAL.SearchEmployeeIDBL(id);
                if (objEmployee != null)
                {

                    txtName.Text = objEmployee.Name;
                    txtkin.Text = objEmployee.KinID;
                    txtmail.Text = objEmployee.MailID;
                    txtphn.Text = objEmployee.PhoneNo;
                    dptxtdob.SelectedDate = objEmployee.DOB;
                    dptxtdoj.SelectedDate = objEmployee.DOJ;
                    txtadd.Text = objEmployee.Address;
                    cmbdept.SelectedValue = objEmployee.DepartmentID;
                    cmbproject.SelectedValue = objEmployee.ProjectID;
                    cmbroles.SelectedValue = objEmployee.RolesID;
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception )
            {
                MessageBox.Show("Enter Valid Emp ID");
            }
        }
      
        private void SearchEmployeeName()
        {
            try
            {
                string name;
                //
                Employee objEmployee;
                //
                name =txtName.Text;
                //
                objEmployee = EmployeeBAL.SearchEmployeeNameBL(name);
                if (objEmployee != null)
                {
                    txtId.Text = objEmployee.EmployeeId.ToString();
                  
                    txtkin.Text = objEmployee.KinID;
                    txtmail.Text = objEmployee.MailID;
                    txtphn.Text = objEmployee.PhoneNo;
                    dptxtdob.SelectedDate = objEmployee.DOB;
                    dptxtdoj.SelectedDate = objEmployee.DOJ;
                    txtadd.Text = objEmployee.Address;
                    cmbdept.SelectedValue = objEmployee.DepartmentID;
                    cmbproject.SelectedValue = objEmployee.ProjectID;
                    cmbroles.SelectedValue = objEmployee.RolesID;
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchEmployeeMail()
        {
            try
            {
                string mailId;
                //
                Employee objEmployee;
                //
                mailId = txtmail.Text;
                //
                objEmployee = EmployeeBAL.SearchEmployeeMailBL(mailId);
                if (objEmployee != null)
                {
                    txtId.Text = objEmployee.EmployeeId.ToString();

                    txtName.Text = objEmployee.Name;
                    txtkin.Text = objEmployee.KinID;
                    
                    txtphn.Text = objEmployee.PhoneNo;
                    dptxtdob.SelectedDate = objEmployee.DOB;
                    dptxtdoj.SelectedDate = objEmployee.DOJ;
                    txtadd.Text = objEmployee.Address;
                    cmbdept.SelectedValue = objEmployee.DepartmentID;
                    cmbproject.SelectedValue = objEmployee.ProjectID;
                    cmbroles.SelectedValue = objEmployee.RolesID;
                }
                else
                {
                    MessageBox.Show("Employee record couldn't be found.");
                }
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void GetEmployees()
        {
            try
            {
                List<Employee> objEmployees = EmployeeBAL.GetAllEmployeeBL();
                if (objEmployees != null)
                {
                    dgEmployees.ItemsSource = objEmployees;
                }
                else
                {
                    MessageBox.Show("No records available.");
                }
            }
            catch (EmpException ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void GetDepartment()
        {
            try
            {
                DataTable departmentList = EmployeeBAL.GetDepartmentBL();
                cmbdept.ItemsSource = departmentList.DefaultView;
                cmbdept.DisplayMemberPath = departmentList.Columns[1].ColumnName;
                cmbdept.SelectedValuePath = departmentList.Columns[0].ColumnName;
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void GetProject()
        {
            try
            {
                DataTable projectList = EmployeeBAL.GetProjectBL();
                cmbproject.ItemsSource = projectList.DefaultView;
                cmbproject.DisplayMemberPath = projectList.Columns[1].ColumnName;
                cmbproject.SelectedValuePath = projectList.Columns[0].ColumnName;
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetRoles()
        {
            try
            {
                DataTable roleList = EmployeeBAL.GetRolesBL();
                cmbroles.ItemsSource = roleList.DefaultView;
                cmbroles.DisplayMemberPath = roleList.Columns[1].ColumnName;
                cmbroles.SelectedValuePath = roleList.Columns[0].ColumnName;
            }
            catch (EmpException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Clear()
        {
            txtId.Clear();
            txtName.Clear();
            txtkin.Clear();
            txtmail.Clear();
            txtphn.Clear();
            dptxtdob.SelectedDate = null;
            dptxtdoj.SelectedDate = null;
            txtadd.Clear();
            cmbdept.SelectedIndex = -1;
            cmbproject.SelectedIndex = -1;
            cmbroles.SelectedIndex = -1;
            
           
            dgEmployees.DataContext = null;
        }

     
    }
}
