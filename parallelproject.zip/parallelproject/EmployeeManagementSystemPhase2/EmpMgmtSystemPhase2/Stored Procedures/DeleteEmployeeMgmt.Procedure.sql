﻿CREATE PROCEDURE [s189820].[DeleteEmployeeMgmt]
	@empID int ,
	@name varchar(20),
	@kinID varchar(14),
	@mailID varchar(25),
	@phnNo varchar(11),
	@dob date,
	@doj date,
	@address varchar(150),
	@departmentID int,
	@projectID int,
	@rolesID int
	
AS
begin
	Delete from s189820.EmployeeMgmt where [Employee Id]=@empID
	end
