﻿CREATE PROCEDURE [s189820].[GetDepartmentEmpMgmt]
	@departmentID int ,
	@name varchar(20),
	@description varchar(150)
AS
begin
	SELECT * from s189820.DepartMentMgmt
end




