﻿CREATE PROCEDURE [s189820].[GetProjectEmpMgmt]
	@projectID int ,
	@name varchar(20),
	@description varchar(150),
	@departmentID int
AS
begin
	SELECT * from s189820.ProjectMgmt
	end


