﻿
CREATE PROCEDURE [s189820].[USP_GetEmpIDFromRole]
	@roleID int,
	@name varchar(20),
	@description varchar(150)
AS
begin
	SELECT * from [s189820].RoleMgmt;
end

--drop procedure [s189820].[USP_GetEmpIDFromRole];