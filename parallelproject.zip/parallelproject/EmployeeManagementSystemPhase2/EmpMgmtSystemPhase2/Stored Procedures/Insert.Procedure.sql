﻿CREATE PROCEDURE [s189820].[InsertEmployeeMgmt]
	@empID int ,
	@name varchar(20),
	@kinID varchar(14),
	@mailID varchar(25),
	@phnNo varchar(11),
	@dob date,
	@doj date,
	@address varchar(150),
	@departmentID int,
	@projectID int,
	@rolesID int
	
AS
begin
	insert into s189820.EmployeeMgmt values(@name,@kinID,@mailID,@phnNo,@dob,@doj,@address,@departmentID,@projectID,@rolesID);
	end
