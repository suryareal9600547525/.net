﻿CREATE PROCEDURE [s189820].[SearchEmployeeMgmtID]
	@empID int ,
	@name varchar (20) output,
	@kinID varchar(14) output,
	@mailID varchar(25) output,
	@phnNo varchar(11) output,
	@dob date output,
	@doj date output,
	@address varchar(150) output,
	@departmentID int output,
	@projectID int output,
	@rolesID int output
	
AS
begin
	select * from  s189820.EmployeeMgmt where [Employee Id]=@empID
	end

