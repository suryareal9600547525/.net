﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace File_Demo
{
    class Program
    {

        static void Main(string[] args)
        {
            //CreateFileWith_FileStream();
            //WriteFileWith_StreamWriter();
            //ReadFileWith_StreamReader();
            //CreateFile_UsingFileClass();
            //MoveFile_UsingFileClass();
            //CreateFile_UsingFileInfoClass();

            //MoveFile_UsingFileInfoClass();
            CreateDirectory_UsingDirectoryClass();
            //CreateDirectory_UsingDirectoryInfoClass();
            Console.ReadKey();
        }
        static void CreateFileWith_FileStream()
        {
            FileStream objFS = new FileStream(@"D:\ForfileIO\DemoFile.txt", FileMode.Create, FileAccess.Write, FileShare.Read);
            objFS.Close();
        }
        static void ReadFileWith_StreamReader()
        {
            FileStream objFS = new FileStream(@"D:\ForfileIO\DemoFile.txt", FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            Console.WriteLine("data from file.");
            string strDataFromFile = objSR.ReadLine();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("data from file_" + strDataFromFile);

        }
        static void WriteFileWith_StreamWriter()
        {
            FileStream objFS = new FileStream(@"D:\ForfileIO\DemoFile.txt", FileMode.Append, FileAccess.Write, FileShare.Read);
            StreamWriter objSW = new StreamWriter(objFS);
            Console.WriteLine("enter the data.");
            objSW.WriteLine(Console.ReadLine());
            objSW.Flush();
            objSW.Close();
            objFS.Close();

        }
        static void CreateFile_UsingFileClass()
        {
            string strFilePath = @"D:\ForfileIO\NewFile_I.txt";
            if (!File.Exists(strFilePath))
            {
                FileStream objFS = File.Create(strFilePath);
                if (objFS != null)
                {
                    Console.WriteLine("file  created succcessfully.");
                }
            }
        }
        static void MoveFile_UsingFileClass()
        {
            string strFilePath = @"D:\ForfileIO\NewFile_2.txt";
            string strFileDestinationPath = @"D:\ForfileIO\DestinationFolder\File_I.txt";
            if (File.Exists(strFilePath))
            {
                File.Move(strFilePath, strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))
                {
                    Console.WriteLine("file  Moved succcessfully.");
                }
                else
                {
                    Console.WriteLine("file could not be moved.");
                }


            }
        }
        static void CreateFile_UsingFileInfoClass()
        {
            string strFilePath = @"D:\ForfileIO\NewFile_2.txt";
            FileInfo objFI = new FileInfo(strFilePath);
            if (!objFI.Exists)
            {
                FileStream objFS = objFI.Create();
                if (objFS != null)
                {
                    Console.WriteLine("file  created succcessfully.");
                }
                else
                {
                    Console.WriteLine("File not created.");
                }
            }
        }

        static void MoveFile_UsingFileInfoClass()
        {
            string strFilePath = @"D:\ForfileIO\NewFile_2.txt";
            string strFileDestinationPath = @"D:\ForfileIO\DestinationFolder\File_2.txt";
            FileInfo objFI = new FileInfo(strFilePath);
            if (objFI.Exists)
            {
                objFI.MoveTo(strFileDestinationPath);
                if (File.Exists(strFileDestinationPath))

                {
                    Console.WriteLine("file  moved succcessfully.");
                }
                else
                {
                    Console.WriteLine("File not moved .");
                }
            }

        }
        static void CreateDirectory_UsingDirectoryClass()

        {
            string strDirectoryPath = @"D:\ForfileIO\NewDirectory1";
            if (!Directory.Exists(strDirectoryPath))
            {
                Directory.CreateDirectory(strDirectoryPath);
                if (Directory.Exists(strDirectoryPath))
                {
                    Console.WriteLine("Directory created successfully. ");
                }
                else
                {
                    Console.WriteLine("Directory could not be created");
                }

            }
        }


        static void CreateDirectory_UsingDirectoryInfoClass()

        {
            string strDirectoryPath = @"D:\ForfileIO\NewDirectory_II";
            DirectoryInfo objDI = new DirectoryInfo(strDirectoryPath);
            if (!objDI.Exists)
            {
                objDI.Create();
                if (!objDI.Exists)
                {
                    Console.WriteLine("directory created");
                }
                else
                {
                    Console.WriteLine("directory not created");
                }
            }
        }
        static void GetFiles_FromDirectory()
        {
            string strDirectorypath = @"D:\ForfileIO\NewDirectory";
            if (Directory.Exists(strDirectorypath))

            {
                string[] strFiles = Directory.GetFiles(strDirectorypath);
                Console.WriteLine("----List of Files----");

                foreach (string strfile in strFiles)
                {
                    string strFilename = Path.GetFileName(strfile);
                    Console.WriteLine(strFilename);
                    string strFileNameWithoutExt = Path.GetFileNameWithoutExtension(strfile);
                    Console.WriteLine(strFileNameWithoutExt);

                    
                }
            }

        }
    }
}
