﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LAB12_Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the Name of the File with Extension : ");
                string fileName = Console.ReadLine();
                ReadFileWith_StreamReader(fileName);
                 
            }
            catch(Exception e)
            {
                Console.WriteLine("Dose not Find File....");
            }
        }
        static void ReadFileWith_StreamReader(string fileName)
        {
            FileStream objFS = new FileStream(@"C:\ForFileIO\"+fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader objSR = new StreamReader(objFS);
            string strDataFromFile = objSR.ReadLine();
            objSR.Close();
            objFS.Close();
            Console.WriteLine("Data from File :" + strDataFromFile);
        }
         
    }
}
