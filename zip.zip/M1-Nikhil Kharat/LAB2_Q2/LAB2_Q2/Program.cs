﻿using System;

namespace LAB2_Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] numbers = new int[5, 6];
            Console.WriteLine("--------- Enter Numbers of Two Dimentional Array ---------");
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write("Enter value for Row "+i+" and Column "+j+":");
                    numbers[i, j] = Convert.ToInt32(Console.ReadLine());

                }
                Console.WriteLine("\n");

            }

            Console.WriteLine("--------- List of Numbers from Two Dimentional Array ---------");
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i, j]);
                    Console.Write("\t");

                }
                Console.WriteLine("");
            }
            Console.Read();
        }
    }
}
