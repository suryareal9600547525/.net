﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2_Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] Cities = new string[3];
            for(int i = 0; i < Cities.Length; i++)
            {
                Console.WriteLine("Enter the Name of City :");
                Cities[i] = Console.ReadLine();
            }
            Console.WriteLine("  ----- Name of Cities -----");
            foreach (string str in Cities)
            {
                Console.WriteLine(str);
                 
            }
            Console.Read();
        }
    }
}
