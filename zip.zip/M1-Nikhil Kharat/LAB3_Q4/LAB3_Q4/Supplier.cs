﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_Q4
{
    public class Supplier
    {
        int supplierID;
        string supplierName;
        string city;
        string phoneNo;
        string email;
          
        internal void AcceptDetails()
        {
            Console.WriteLine("Enter the Supplier ID :");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the supplierName :");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter the city :");
            city = Console.ReadLine();
            Console.WriteLine("Enter the phoneNo :");
            phoneNo = Console.ReadLine();
            Console.WriteLine("Enter the email :");
            email = Console.ReadLine();

        }
        internal void DisplayDetails()
        {
            Console.WriteLine("  Supplier ID :"+ supplierID);
            
            Console.WriteLine("  supplierName :"+ supplierName);
            
            Console.WriteLine("  city :"+ city);
            
            Console.WriteLine("  phoneNo :"+ phoneNo);
            
            Console.WriteLine("  email :"+ email);
             
        }
    }
}
