﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_Q1
{
    class ContractEmployee :Employee
    {
        //int perks;
        public int Perks { get; set; }

        public override double GetSalary()
        {
            Console.WriteLine("Enter Perks:");
            Perks = Convert.ToInt32(Console.ReadLine());
            double result;
            result = salary + Perks;
            return result;
        }
    }
}
