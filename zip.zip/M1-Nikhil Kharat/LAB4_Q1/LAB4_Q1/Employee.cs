﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_Q1
{
    abstract class Employee
    {
       
        public int Employeeid { get; set; }
        public string address { get; set; }
        public string employeename { get; set; }
        public string city { get; set; }
        public string department { get; set; }
        public double salary { get; set; }
        public abstract double GetSalary();

        static void Main(string[] args)
        {
            ContractEmployee obj = new ContractEmployee();
            PermanentEmployee obj1 = new PermanentEmployee();
            Console.WriteLine("Enter 1 to Contract Employee and 2 to Permanent Employee 3 to Exit.");
            int  c = Convert.ToInt32(Console.ReadLine());
            switch (c)
            {
                case 1:
                    Console.WriteLine("======Contract Employee=====");
                    obj.GetData();
                    double sal=obj.GetSalary();
                    Console.WriteLine("Salary of Contract Employee is :"+ sal);

                    break;
                case 2:
                    Console.WriteLine("======Permanent Employee=====");
                    obj1.GetData();
                    double sal1 = obj1.GetSalary();
                    Console.WriteLine("Salary of Permanent Employee is :" + sal1);
                    break;
                case 3:
                    Environment.Exit(0);
                    break;
                default:
                    break;
            }
            Console.Read();
           
        }
         void GetData()
        {
            Console.WriteLine("Enter Employee Id :");
            Employeeid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name :");
             employeename = Console.ReadLine();
            Console.WriteLine("Enter Employee Address :");
             address = Console.ReadLine();
            Console.WriteLine("Enter Employee City :");
             city = Console.ReadLine();
            Console.WriteLine("Enter Employee Department :");
             department = Console.ReadLine();

            Console.WriteLine("Enter Employee Salary :");
            salary = Convert.ToDouble(Console.ReadLine());
            
        }
    }
}
