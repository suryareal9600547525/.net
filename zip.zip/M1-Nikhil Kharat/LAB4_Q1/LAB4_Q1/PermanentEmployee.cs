﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB4_Q1
{
    class PermanentEmployee: Employee
    {
        
        public int NoOfLeaves { get; set; }
        public int ProvidendFund  { get; set;}
        public override double GetSalary()
        {
            Console.WriteLine("Enter No of Leave :");
            NoOfLeaves = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Providend Fund :");
            ProvidendFund = Convert.ToInt32(Console.ReadLine());
            double result;
             result = salary - ProvidendFund;
            return result;
        }
    }
}
