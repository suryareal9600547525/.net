﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Q1
{
    public struct Structure
    {
        public int number;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Structure objstruct;
            objstruct.number = 3;
            int choice;
            Console.WriteLine("Enter 1 for square & 2 for cube.");
            choice = Convert.ToInt32(Console.ReadLine());
            switch(choice)
            {
                case 1:
                    square(objstruct.number);
                    break;
                case 2:
                    cube(objstruct.number);
                    break;
                default:
                    Console.WriteLine("Enter Right Choice.");
                    break;

            }

        }
        static void cube(int n)
        {
            Console.WriteLine("Cube of " + n + " is " + (n * n * n));
        }
        static void square(int n)
        {
            Console.WriteLine("Cube of " + n + " is " + (n * n));
        }
    }
}
