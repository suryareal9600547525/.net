﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employee
    {
        int EmployeeID;
        string EmployeeName;
        string Address;
        string City;
        string Department;
        double Salary;

        public int Employeeid
        {
            get
            {
                return EmployeeID;
            }
            set
            {
                EmployeeID = value;
            }
        }
        public string address
        {
            get
            {
                return Address;
            }
            set
            {
                Address = value;
            }
        }
        public string employeename
        {
            get
            {
                return EmployeeName;
            }
            set
            {
                EmployeeName = value;
            }
        }
        public string city
        {
            get
            {
                return City;
            }
            set
            {
                City = value;
            }
        }
        public string department
        {
            get
            {
                return Department;
            }
            set
            {
                Department = value;
            }
        }
        public double salary
        {
            get
            {
                return Salary;
            }
            set
            {
                Salary = value;
            }
        }

    }
}
