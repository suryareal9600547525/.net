﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeLib.Employee[] objEmployee = new EmployeeLib.Employee[2];
            Console.WriteLine("----- Enter the Employees Details ------");
             

            for(int i=0;i<objEmployee.Length;i++)
            {
                objEmployee[i] = new EmployeeLib.Employee(); 

                Console.WriteLine("Enter Employee Id :");
                objEmployee[i].Employeeid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Employee Name :");
                objEmployee[i].employeename =Console.ReadLine();
                Console.WriteLine("Enter Employee Address :");
                objEmployee[i].address = Console.ReadLine();
                Console.WriteLine("Enter Employee City :");
                objEmployee[i].city = Console.ReadLine();
                Console.WriteLine("Enter Employee Department :");
                objEmployee[i].department =Console.ReadLine();

                Console.WriteLine("Enter Employee Salary :");
                objEmployee[i].salary = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("----- Enter details of "+(i+2)+" Employee -----");
            }
            Console.WriteLine("========= Employee Details ==========");
            for (int i = 0; i < objEmployee.Length; i++)
            {
                Console.WriteLine("-----  Details of " + (i + 1) + " Employee -----");
                Console.WriteLine("Employee Name is :"+objEmployee[i].employeename);
                Console.WriteLine("Employee Salary is :"+objEmployee[i].salary);
                
            }
        }
    }
}
