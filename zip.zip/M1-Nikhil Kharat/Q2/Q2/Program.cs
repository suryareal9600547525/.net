﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\t\t------------Calculator Application--------------");
            char choice;
            do
            {
                Console.WriteLine("Press 1 for Addition, Press 2 for Subtraction, Press 3 for Multiplication, Press 4 for Division.");
                int operation, num1;
                    double num2, result;
                operation = Convert.ToInt32(Console.ReadLine());
                CalculatorLib.Calculator objCalculator = new CalculatorLib.Calculator();
                switch (operation)
                {
                    case 1:
                        //Addition
                        Console.WriteLine("Enter first number:");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter second number:");
                        num2 = Convert.ToDouble(Console.ReadLine());
                        result = objCalculator.Addition(num1, num2);
                        Console.WriteLine("Addition of two numbers is: " + result);
                        break;
                    case 2:
                        //Subtraction
                        Console.WriteLine("Enter first number:");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter second number:");
                        num2 = Convert.ToDouble(Console.ReadLine());
                        result = objCalculator.Subtraction(num1, num2);
                        Console.WriteLine("Subtraction of two numbers is: " + result);
                        break;
                    case 3:
                        //Multiplication
                        Console.WriteLine("Enter first number:");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter second number:");
                        num2 = Convert.ToDouble(Console.ReadLine());
                        result = objCalculator.Multiplication(num1, num2);
                        Console.WriteLine("Multiplication of two numbers is: " + result);
                        break;
                    case 4:
                        //Division
                        Console.WriteLine("Enter first number:");
                        num1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter second number:");
                        num2 = Convert.ToDouble(Console.ReadLine());
                        result = objCalculator.Division(num1, num2);
                        Console.WriteLine("Division of two numbers is: " + result);
                        break;
                    default:
                        //Logic to handle wrong choice
                        Console.WriteLine("Enter correct choice");
                        break;
                }
                Console.WriteLine("Do you want to continue? Press 'y' to continue");
                choice = Convert.ToChar(Console.ReadLine());

            }
            while (choice == 'y');
        }
    }
    
}
