﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int rollNumber;
            string studentName;
            byte age;
            char gender;
            DateTime dateOfBirth;
            string address;
            float percentage;

            Console.WriteLine("========== Enter Students Details ===========\n");
            Console.WriteLine("Enter the Roll Number: ");
            rollNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student Name: ");
            studentName =  Console.ReadLine();
            Console.WriteLine("Enter Age: ");
            age = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Enter Gender: ");
            gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter Date of Birth: ");
            dateOfBirth = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Address: ");
            address = Console.ReadLine();
            Console.WriteLine("Enter Percentage: ");
            percentage = float.Parse(Console.ReadLine());

            //Printing the Data
            Console.WriteLine("========== Students Details ===========\n");
            Console.WriteLine("Roll Number: "+rollNumber);
            Console.WriteLine("Student Name: "+studentName);
            Console.WriteLine("Age: "+age);
            Console.WriteLine("Gender: "+gender);
            Console.WriteLine("Date of Birth: "+dateOfBirth);
            Console.WriteLine("Address: "+address);
            Console.WriteLine("Percentage: "+percentage);

        }
    }
}
